<template>
  <Modal ref="modal" @onOk="submit" :onCancel="close" width="40%" :title="title">
    <el-form ref="form" :model="query" :rules="rules" label-position="right" label-width="120px">
      <el-row :gutter="5" v-for="(items,ind) in fields" :key="ind">
        <el-col :span="12" v-for="(item, index) in items" :key="index">
          <el-form-item :label="item.label" :prop="item.prop">
            <Input v-if="item.type=='text'" width="100%" v-model.trim="query[item.prop]" :readonly="!isAdd&&item.noEdit" :placeHolder="item.placeholder" />
            <Select v-else-if="item.type=='select'" width="100%" :enum="item.enum" :readonly="!isAdd&&item.noEdit" v-model="query[item.prop]"/>
            <Select v-else-if="item.type=='textarea'" width="100%" :readonly="!isAdd&&item.noEdit" v-model="query[item.prop]"/>
          </el-form-item>
        </el-col>
      </el-row>
    </el-form>
  </Modal>
</template>
<script>
/**
 * 投放平台信息
 * 
 * generated at 2021-1-13 9:37:32 AM
 */

import editPageMixin from "./../../../edit-page-mixin";
export default {
 mixins:[editPageMixin],
  data() {
    return {
      description:'投放平台信息',
      pkName:'platNo',
      apiPrefix:'plat-agent/plat',
      fields:[
	[
		{
			prop: "platName",
			label: "平台名称",
			type: "text"
		},
		{
			prop: "platCode",
			label: "平台代码",
			type: "text"
		},
		{
			prop: "adLoginUrl",
			label: "投放登录地址",
			type: "text"
		}
	],
	[
		{
			prop: "reportUrl",
			label: "回码上报地址",
			type: "text"
		},
		{
			prop: "opLoginUrl",
			label: "开放平台登录地址",
			type: "text"
		}
	]
],
      rules: {
	platName: [
		{
			required: true,
			message: "请输入平台名称",
			trigger: "blur"
		}
	],
	platCode: [
		{
			required: true,
			message: "请输入平台代码",
			trigger: "blur"
		}
	]
},
      query:{
	platName: null,
	platCode: null,
	adLoginUrl: null,
	reportUrl: null,
	opLoginUrl: null,
	platNo: null
},
    }
  },
}
</script>