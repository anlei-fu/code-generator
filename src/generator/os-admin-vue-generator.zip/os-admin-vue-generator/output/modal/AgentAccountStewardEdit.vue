<template>
  <Modal ref="modal" @onOk="submit" :onCancel="close" width="40%" :title="title">
    <el-form ref="form" :model="query" :rules="rules" label-position="right" label-width="120px">
      <el-row :gutter="5" v-for="(items,ind) in fields" :key="ind">
        <el-col :span="12" v-for="(item, index) in items" :key="index">
          <el-form-item :label="item.label" :prop="item.prop">
            <Input v-if="item.type=='text'" width="100%" v-model.trim="query[item.prop]" :readonly="!isAdd&&item.noEdit" :placeHolder="item.placeholder" />
            <Select v-else-if="item.type=='select'" width="100%" :enum="item.enum" :readonly="!isAdd&&item.noEdit" v-model="query[item.prop]"/>
            <Select v-else-if="item.type=='textarea'" width="100%" :readonly="!isAdd&&item.noEdit" v-model="query[item.prop]"/>
          </el-form-item>
        </el-col>
      </el-row>
    </el-form>
  </Modal>
</template>
<script>
/**
 * 代理商管家账号
 * 
 * generated at 2021-1-13 9:37:32 AM
 */
import { numberValidator } from "./../../../../../util/Validators";
import editPageMixin from "./../../../edit-page-mixin";
export default {
 mixins:[editPageMixin],
  data() {
    return {
      description:'代理商管家账号',
      pkName:'stewardId',
      apiPrefix:'plat-agent/agent-account-steward',
      fields:[
	[
		{
			prop: "accountId",
			label: "登录账号ID",
			type: "text"
		},
		{
			prop: "appUid",
			label: "授权APP",
			type: "text"
		},
		{
			prop: "stewardNo",
			label: "管家编码",
			type: "text"
		}
	],
	[
		{
			prop: "stewardName",
			label: "管家名称",
			type: "text"
		},
		{
			prop: "cashBalance",
			label: "现金余额",
			type: "text"
		}
	],
	[
		{
			prop: "validBalance",
			label: "账面余额",
			type: "text"
		},
		{
			prop: "accessToken",
			label: "访问令牌",
			type: "text"
		}
	],
	[
		{
			prop: "refreshToken",
			label: "刷新令牌",
			type: "text"
		},
		{
			prop: "status",
			label: "状态",
			type: "select",
			enum: "status"
		}
	]
],
      rules: {
	accountId: [
		{
			required: true,
			message: "请输入登录账号ID",
			trigger: "blur"
		},
		{
			validator: numberValidator,
			message: "请输入合法数字",
			trigger: "blur"
		}
	],
	appUid: [
		{
			required: true,
			message: "请输入授权APP",
			trigger: "blur"
		},
		{
			validator: numberValidator,
			message: "请输入合法数字",
			trigger: "blur"
		}
	],
	stewardNo: [
		{
			required: true,
			message: "请输入管家编码",
			trigger: "blur"
		}
	],
	stewardName: [
		{
			required: true,
			message: "请输入管家名称",
			trigger: "blur"
		}
	],
	cashBalance: [
		{
			required: true,
			message: "请输入现金余额",
			trigger: "blur"
		},
		{
			validator: numberValidator,
			message: "请输入合法数字",
			trigger: "blur"
		}
	],
	validBalance: [
		{
			required: true,
			message: "请输入账面余额",
			trigger: "blur"
		},
		{
			validator: numberValidator,
			message: "请输入合法数字",
			trigger: "blur"
		}
	],
	status: [
		{
			required: true,
			message: "请选择状态",
			trigger: "blur"
		}
	]
},
      query:{
	accountId: null,
	appUid: null,
	stewardNo: null,
	stewardName: null,
	cashBalance: null,
	validBalance: null,
	accessToken: null,
	refreshToken: null,
	status: null,
	stewardId: null
},
    }
  },
}
</script>