<template>
  <Modal ref="modal" @onOk="submit" :onCancel="close" width="40%" :title="title">
    <el-form ref="form" :model="query" :rules="rules" label-position="right" label-width="120px">
      <el-row :gutter="5" v-for="(items,ind) in fields" :key="ind">
        <el-col :span="12" v-for="(item, index) in items" :key="index">
          <el-form-item :label="item.label" :prop="item.prop">
            <Input v-if="item.type=='text'" width="100%" v-model.trim="query[item.prop]" :readonly="!isAdd&&item.noEdit" :placeHolder="item.placeholder" />
            <Select v-else-if="item.type=='select'" width="100%" :enum="item.enum" :readonly="!isAdd&&item.noEdit" v-model="query[item.prop]"/>
            <Select v-else-if="item.type=='textarea'" width="100%" :readonly="!isAdd&&item.noEdit" v-model="query[item.prop]"/>
          </el-form-item>
        </el-col>
      </el-row>
    </el-form>
  </Modal>
</template>
<script>
/**
 * 终端页埋点跟踪
 * 
 * generated at 2021-1-13 9:37:32 AM
 */

import editPageMixin from "./../../../edit-page-mixin";
export default {
 mixins:[editPageMixin],
  data() {
    return {
      description:'终端页埋点跟踪',
      pkName:'recordId',
      apiPrefix:'term/page-track',
      fields:[
	[
		{
			prop: "pageId",
			label: "",
			type: "select",
			enum: "pageId"
		},
		{
			prop: "eventId",
			label: "",
			type: "text"
		},
		{
			prop: "termNo",
			label: "",
			type: "select",
			enum: "termNo"
		}
	],
	[
		{
			prop: "eventKey",
			label: "",
			type: "text"
		},
		{
			prop: "eventValue",
			label: "",
			type: "text"
		}
	]
],
      rules: {
	pageId: [
		{
			required: true,
			message: "请选择",
			trigger: "blur"
		}
	],
	eventId: [
		{
			required: true,
			message: "请输入",
			trigger: "blur"
		}
	],
	termNo: [
		{
			required: true,
			message: "请选择",
			trigger: "blur"
		}
	],
	eventKey: [
		{
			required: true,
			message: "请输入",
			trigger: "blur"
		}
	],
	eventValue: [
		{
			required: true,
			message: "请输入",
			trigger: "blur"
		}
	]
},
      query:{
	pageId: null,
	eventId: null,
	termNo: null,
	eventKey: null,
	eventValue: null,
	recordId: null
},
    }
  },
}
</script>