<template>
  <Modal ref="modal" @onOk="submit" :onCancel="close" width="40%" :title="title">
    <el-form ref="form" :model="query" :rules="rules" label-position="right" label-width="120px">
      <el-row :gutter="5" v-for="(items,ind) in fields" :key="ind">
        <el-col :span="12" v-for="(item, index) in items" :key="index">
          <el-form-item :label="item.label" :prop="item.prop">
            <Input v-if="item.type=='text'" width="100%" v-model.trim="query[item.prop]" :readonly="!isAdd&&item.noEdit" :placeHolder="item.placeholder" />
            <Select v-else-if="item.type=='select'" width="100%" :enum="item.enum" :readonly="!isAdd&&item.noEdit" v-model="query[item.prop]"/>
            <Select v-else-if="item.type=='textarea'" width="100%" :readonly="!isAdd&&item.noEdit" v-model="query[item.prop]"/>
          </el-form-item>
        </el-col>
      </el-row>
    </el-form>
  </Modal>
</template>
<script>
/**
 * 系统产品类型表
 * 
 * generated at 2021-1-13 9:37:32 AM
 */
import { numberValidator } from "./../../../../../util/Validators";
import editPageMixin from "./../../../edit-page-mixin";
export default {
 mixins:[editPageMixin],
  data() {
    return {
      description:'系统产品类型表',
      pkName:'recordId',
      apiPrefix:'',
      fields:[
	[
		{
			prop: "typeValue",
			label: "类型值",
			type: "text"
		},
		{
			prop: "typeName",
			label: "类型名称",
			type: "text"
		},
		{
			prop: "stepType",
			label: "步骤类型",
			type: "select",
			enum: "stepType"
		}
	],
	[
		{
			prop: "businessType",
			label: "业务类型编号",
			type: "select",
			enum: "businessType"
		},
		{
			prop: "remark",
			label: "备注",
			type: "textarea"
		}
	],
	[
		{
			prop: "status",
			label: "状态",
			type: "select",
			enum: "status"
		}
	]
],
      rules: {
	typeValue: [
		{
			required: true,
			message: "请输入类型值",
			trigger: "blur"
		},
		{
			validator: numberValidator,
			message: "请输入合法数字",
			trigger: "blur"
		}
	],
	typeName: [
		{
			required: true,
			message: "请输入类型名称",
			trigger: "blur"
		}
	],
	businessType: [
		{
			required: true,
			message: "请选择业务类型编号",
			trigger: "blur"
		}
	],
	status: [
		{
			required: true,
			message: "请选择状态",
			trigger: "blur"
		}
	]
},
      query:{
	typeValue: null,
	typeName: null,
	stepType: null,
	businessType: null,
	remark: null,
	status: null,
	recordId: null
},
    }
  },
}
</script>