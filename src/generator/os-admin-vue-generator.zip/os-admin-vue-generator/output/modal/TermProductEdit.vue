<template>
  <Modal ref="modal" @onOk="submit" :onCancel="close" width="40%" :title="title">
    <el-form ref="form" :model="query" :rules="rules" label-position="right" label-width="120px">
      <el-row :gutter="5" v-for="(items,ind) in fields" :key="ind">
        <el-col :span="12" v-for="(item, index) in items" :key="index">
          <el-form-item :label="item.label" :prop="item.prop">
            <Input v-if="item.type=='text'" width="100%" v-model.trim="query[item.prop]" :readonly="!isAdd&&item.noEdit" :placeHolder="item.placeholder" />
            <Select v-else-if="item.type=='select'" width="100%" :enum="item.enum" :readonly="!isAdd&&item.noEdit" v-model="query[item.prop]"/>
            <Select v-else-if="item.type=='textarea'" width="100%" :readonly="!isAdd&&item.noEdit" v-model="query[item.prop]"/>
          </el-form-item>
        </el-col>
      </el-row>
    </el-form>
  </Modal>
</template>
<script>
/**
 * 终端产品信息
 * 
 * generated at 2021-1-13 9:37:32 AM
 */
import { numberValidator } from "./../../../../../util/Validators";
import editPageMixin from "./../../../edit-page-mixin";
export default {
 mixins:[editPageMixin],
  data() {
    return {
      description:'终端产品信息',
      pkName:'recordId',
      apiPrefix:'term/product',
      fields:[
	[
		{
			prop: "termNo",
			label: "终端编号",
			type: "select",
			enum: "termNo"
		},
		{
			prop: "productNo",
			label: "产品编号",
			type: "select",
			enum: "productNo"
		},
		{
			prop: "payPrice",
			label: "支付价格",
			type: "text"
		}
	],
	[
		{
			prop: "status",
			label: "状态",
			type: "select",
			enum: "status"
		},
		{
			prop: "extend1",
			label: "扩展字段1",
			type: "text"
		}
	],
	[
		{
			prop: "extend2",
			label: "扩展字段2",
			type: "text"
		},
		{
			prop: "extend3",
			label: "扩展字段3",
			type: "text"
		}
	]
],
      rules: {
	termNo: [
		{
			required: true,
			message: "请选择终端编号",
			trigger: "blur"
		}
	],
	productNo: [
		{
			required: true,
			message: "请选择产品编号",
			trigger: "blur"
		}
	],
	payPrice: [
		{
			required: true,
			message: "请输入支付价格",
			trigger: "blur"
		},
		{
			validator: numberValidator,
			message: "请输入合法数字",
			trigger: "blur"
		}
	],
	status: [
		{
			required: true,
			message: "请选择状态",
			trigger: "blur"
		}
	]
},
      query:{
	termNo: null,
	productNo: null,
	payPrice: null,
	status: null,
	extend1: null,
	extend2: null,
	extend3: null,
	recordId: null
},
    }
  },
}
</script>