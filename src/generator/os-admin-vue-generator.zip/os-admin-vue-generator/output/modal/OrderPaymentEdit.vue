<template>
  <Modal ref="modal" @onOk="submit" :onCancel="close" width="40%" :title="title">
    <el-form ref="form" :model="query" :rules="rules" label-position="right" label-width="120px">
      <el-row :gutter="5" v-for="(items,ind) in fields" :key="ind">
        <el-col :span="12" v-for="(item, index) in items" :key="index">
          <el-form-item :label="item.label" :prop="item.prop">
            <Input v-if="item.type=='text'" width="100%" v-model.trim="query[item.prop]" :readonly="!isAdd&&item.noEdit" :placeHolder="item.placeholder" />
            <Select v-else-if="item.type=='select'" width="100%" :enum="item.enum" :readonly="!isAdd&&item.noEdit" v-model="query[item.prop]"/>
            <Select v-else-if="item.type=='textarea'" width="100%" :readonly="!isAdd&&item.noEdit" v-model="query[item.prop]"/>
          </el-form-item>
        </el-col>
      </el-row>
    </el-form>
  </Modal>
</template>
<script>
/**
 * 订单支付记录表
 * 
 * generated at 2021-1-13 9:37:32 AM
 */
import { numberValidator } from "./../../../../../util/Validators";
import editPageMixin from "./../../../edit-page-mixin";
export default {
 mixins:[editPageMixin],
  data() {
    return {
      description:'订单支付记录表',
      pkName:'orderNo',
      apiPrefix:'',
      fields:[
	[
		{
			prop: "accountId",
			label: "支付账号编号",
			type: "text"
		},
		{
			prop: "payPrice",
			label: "支付价格",
			type: "text"
		},
		{
			prop: "serviceRate",
			label: "手续费率",
			type: "text"
		}
	],
	[
		{
			prop: "serviceFee",
			label: "手续费",
			type: "text"
		},
		{
			prop: "payStatus",
			label: "支付状态",
			type: "select",
			enum: "payStatus"
		}
	],
	[
		{
			prop: "tradeSeq",
			label: "支付平台流水",
			type: "text"
		},
		{
			prop: "tradeMsg",
			label: "支付平台消息",
			type: "textarea"
		}
	]
],
      rules: {
	accountId: [
		{
			required: true,
			message: "请输入支付账号编号",
			trigger: "blur"
		},
		{
			validator: numberValidator,
			message: "请输入合法数字",
			trigger: "blur"
		}
	],
	payPrice: [
		{
			required: true,
			message: "请输入支付价格",
			trigger: "blur"
		},
		{
			validator: numberValidator,
			message: "请输入合法数字",
			trigger: "blur"
		}
	],
	serviceRate: [
		{
			required: true,
			message: "请输入手续费率",
			trigger: "blur"
		},
		{
			validator: numberValidator,
			message: "请输入合法数字",
			trigger: "blur"
		}
	],
	serviceFee: [
		{
			required: true,
			message: "请输入手续费",
			trigger: "blur"
		},
		{
			validator: numberValidator,
			message: "请输入合法数字",
			trigger: "blur"
		}
	],
	payStatus: [
		{
			required: true,
			message: "请选择支付状态",
			trigger: "blur"
		}
	]
},
      query:{
	accountId: null,
	payPrice: null,
	serviceRate: null,
	serviceFee: null,
	payStatus: null,
	tradeSeq: null,
	tradeMsg: null,
	orderNo: null
},
    }
  },
}
</script>