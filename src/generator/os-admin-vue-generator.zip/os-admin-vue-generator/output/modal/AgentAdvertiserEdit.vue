<template>
  <Modal ref="modal" @onOk="submit" :onCancel="close" width="40%" :title="title">
    <el-form ref="form" :model="query" :rules="rules" label-position="right" label-width="120px">
      <el-row :gutter="5" v-for="(items,ind) in fields" :key="ind">
        <el-col :span="12" v-for="(item, index) in items" :key="index">
          <el-form-item :label="item.label" :prop="item.prop">
            <Input v-if="item.type=='text'" width="100%" v-model.trim="query[item.prop]" :readonly="!isAdd&&item.noEdit" :placeHolder="item.placeholder" />
            <Select v-else-if="item.type=='select'" width="100%" :enum="item.enum" :readonly="!isAdd&&item.noEdit" v-model="query[item.prop]"/>
            <Select v-else-if="item.type=='textarea'" width="100%" :readonly="!isAdd&&item.noEdit" v-model="query[item.prop]"/>
          </el-form-item>
        </el-col>
      </el-row>
    </el-form>
  </Modal>
</template>
<script>
/**
 * 代理商广告主(广告账户)
 * 
 * generated at 2021-1-13 9:37:32 AM
 */
import { numberValidator } from "./../../../../../util/Validators";
import editPageMixin from "./../../../edit-page-mixin";
export default {
 mixins:[editPageMixin],
  data() {
    return {
      description:'代理商广告主(广告账户)',
      pkName:'advertiserUid',
      apiPrefix:'advertiser/advertiser',
      fields:[
	[
		{
			prop: "accountId",
			label: "账号编号",
			type: "text"
		},
		{
			prop: "stewardId",
			label: "管家账号",
			type: "select",
			enum: "stewardId"
		},
		{
			prop: "advertiserId",
			label: "广告主编码",
			type: "text"
		}
	],
	[
		{
			prop: "businessType",
			label: "业务类型",
			type: "select",
			enum: "businessType"
		},
		{
			prop: "productType",
			label: "产品类型",
			type: "select",
			enum: "productType"
		}
	],
	[
		{
			prop: "cashBalance",
			label: "现金余额",
			type: "text"
		},
		{
			prop: "validBalance",
			label: "账面余额",
			type: "text"
		}
	],
	[
		{
			prop: "warnBalance",
			label: "告警余额",
			type: "text"
		},
		{
			prop: "status",
			label: "状态",
			type: "select",
			enum: "status"
		}
	],
	[
		{
			prop: "extend1",
			label: "扩展字段1",
			type: "text"
		},
		{
			prop: "extend2",
			label: "扩展字段2",
			type: "text"
		}
	],
	[
		{
			prop: "extend3",
			label: "扩展字段3",
			type: "text"
		},
		{
			prop: "extend4",
			label: "扩展字段4",
			type: "text"
		}
	],
	[
		{
			prop: "extend5",
			label: "扩展字段5",
			type: "text"
		}
	]
],
      rules: {
	accountId: [
		{
			required: true,
			message: "请输入账号编号",
			trigger: "blur"
		},
		{
			validator: numberValidator,
			message: "请输入合法数字",
			trigger: "blur"
		}
	],
	stewardId: [
		{
			required: true,
			message: "请选择管家账号",
			trigger: "blur"
		}
	],
	advertiserId: [
		{
			required: true,
			message: "请输入广告主编码",
			trigger: "blur"
		}
	],
	businessType: [
		{
			required: true,
			message: "请选择业务类型",
			trigger: "blur"
		}
	],
	productType: [
		{
			required: true,
			message: "请选择产品类型",
			trigger: "blur"
		}
	],
	cashBalance: [
		{
			required: true,
			message: "请输入现金余额",
			trigger: "blur"
		},
		{
			validator: numberValidator,
			message: "请输入合法数字",
			trigger: "blur"
		}
	],
	validBalance: [
		{
			required: true,
			message: "请输入账面余额",
			trigger: "blur"
		},
		{
			validator: numberValidator,
			message: "请输入合法数字",
			trigger: "blur"
		}
	],
	warnBalance: [
		{
			validator: numberValidator,
			message: "请输入合法数字",
			trigger: "blur"
		}
	]
},
      query:{
	accountId: null,
	stewardId: null,
	advertiserId: null,
	businessType: null,
	productType: null,
	cashBalance: null,
	validBalance: null,
	warnBalance: null,
	status: null,
	extend1: null,
	extend2: null,
	extend3: null,
	extend4: null,
	extend5: null,
	advertiserUid: null
},
    }
  },
}
</script>