<template>
  <Modal ref="modal" @onOk="submit" :onCancel="close" width="40%" :title="title">
    <el-form ref="form" :model="query" :rules="rules" label-position="right" label-width="120px">
      <el-row :gutter="5" v-for="(items,ind) in fields" :key="ind">
        <el-col :span="12" v-for="(item, index) in items" :key="index">
          <el-form-item :label="item.label" :prop="item.prop">
            <Input v-if="item.type=='text'" width="100%" v-model.trim="query[item.prop]" :readonly="!isAdd&&item.noEdit" :placeHolder="item.placeholder" />
            <Select v-else-if="item.type=='select'" width="100%" :enum="item.enum" :readonly="!isAdd&&item.noEdit" v-model="query[item.prop]"/>
            <Select v-else-if="item.type=='textarea'" width="100%" :readonly="!isAdd&&item.noEdit" v-model="query[item.prop]"/>
          </el-form-item>
        </el-col>
      </el-row>
    </el-form>
  </Modal>
</template>
<script>
/**
 * 下游渠道信息
 * 
 * generated at 2021-1-13 9:37:32 AM
 */
import { numberValidator } from "./../../../../../util/Validators";
import editPageMixin from "./../../../edit-page-mixin";
export default {
 mixins:[editPageMixin],
  data() {
    return {
      description:'下游渠道信息',
      pkName:'channelNo',
      apiPrefix:'',
      fields:[
	[
		{
			prop: "channelName",
			label: "渠道名称",
			type: "text"
		},
		{
			prop: "balance",
			label: "渠道余额",
			type: "text"
		},
		{
			prop: "syncFlag",
			label: "同步记账",
			type: "select",
			enum: "syncFlag"
		}
	],
	[
		{
			prop: "chargePerson",
			label: "负责人",
			type: "text"
		},
		{
			prop: "status",
			label: "状态",
			type: "select",
			enum: "status"
		}
	],
	[
		{
			prop: "remark",
			label: "备注",
			type: "textarea"
		}
	]
],
      rules: {
	channelName: [
		{
			required: true,
			message: "请输入渠道名称",
			trigger: "blur"
		}
	],
	balance: [
		{
			required: true,
			message: "请输入渠道余额",
			trigger: "blur"
		},
		{
			validator: numberValidator,
			message: "请输入合法数字",
			trigger: "blur"
		}
	],
	syncFlag: [
		{
			required: true,
			message: "请选择同步记账",
			trigger: "blur"
		}
	],
	status: [
		{
			required: true,
			message: "请选择状态",
			trigger: "blur"
		}
	]
},
      query:{
	channelName: null,
	balance: null,
	syncFlag: null,
	chargePerson: null,
	status: null,
	remark: null,
	channelNo: null
},
    }
  },
}
</script>