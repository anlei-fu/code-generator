<template>
  <Modal ref="modal" @onOk="submit" :onCancel="close" width="40%" :title="title">
    <el-form ref="form" :model="query" :rules="rules" label-position="right" label-width="120px">
      <el-row :gutter="5" v-for="(items,ind) in fields" :key="ind">
        <el-col :span="12" v-for="(item, index) in items" :key="index">
          <el-form-item :label="item.label" :prop="item.prop">
            <Input v-if="item.type=='text'" width="100%" v-model.trim="query[item.prop]" :readonly="!isAdd&&item.noEdit" :placeHolder="item.placeholder" />
            <Select v-else-if="item.type=='select'" width="100%" :enum="item.enum" :readonly="!isAdd&&item.noEdit" v-model="query[item.prop]"/>
            <Select v-else-if="item.type=='textarea'" width="100%" :readonly="!isAdd&&item.noEdit" v-model="query[item.prop]"/>
          </el-form-item>
        </el-col>
      </el-row>
    </el-form>
  </Modal>
</template>
<script>
/**
 * 上游资金变动表
 * 
 * generated at 2021-1-13 9:37:32 AM
 */
import { numberValidator } from "./../../../../../util/Validators";
import editPageMixin from "./../../../edit-page-mixin";
export default {
 mixins:[editPageMixin],
  data() {
    return {
      description:'上游资金变动表',
      pkName:'recordId',
      apiPrefix:'fund-change/up-fund-change',
      fields:[
	[
		{
			prop: "orderNo",
			label: "订单号",
			type: "text"
		},
		{
			prop: "deliveryId",
			label: "发货编号",
			type: "select",
			enum: "deliveryId"
		},
		{
			prop: "channelNo",
			label: "渠道编号",
			type: "select",
			enum: "channelNo"
		}
	],
	[
		{
			prop: "changeType",
			label: "变动类型",
			type: "select",
			enum: "changeType"
		},
		{
			prop: "changeMoney",
			label: "变动金额",
			type: "text"
		}
	],
	[
		{
			prop: "changeAfter",
			label: "变动前余额",
			type: "text"
		},
		{
			prop: "changeBefore",
			label: "变动后余额",
			type: "text"
		}
	],
	[
		{
			prop: "syncStatus",
			label: "同步状态",
			type: "select",
			enum: "syncStatus"
		},
		{
			prop: "batchNo",
			label: "同步批次",
			type: "text"
		}
	],
	[
		{
			prop: "syncTimes",
			label: "同步次数",
			type: "text"
		},
		{
			prop: "operator",
			label: "操作人",
			type: "text"
		}
	],
	[
		{
			prop: "reamark",
			label: "备注",
			type: "text"
		}
	]
],
      rules: {
	orderNo: [
		{
			required: true,
			message: "请输入订单号",
			trigger: "blur"
		}
	],
	deliveryId: [
		{
			required: true,
			message: "请选择发货编号",
			trigger: "blur"
		}
	],
	channelNo: [
		{
			required: true,
			message: "请选择渠道编号",
			trigger: "blur"
		}
	],
	changeType: [
		{
			required: true,
			message: "请选择变动类型",
			trigger: "blur"
		}
	],
	changeMoney: [
		{
			required: true,
			message: "请输入变动金额",
			trigger: "blur"
		},
		{
			validator: numberValidator,
			message: "请输入合法数字",
			trigger: "blur"
		}
	],
	changeAfter: [
		{
			required: true,
			message: "请输入变动前余额",
			trigger: "blur"
		},
		{
			validator: numberValidator,
			message: "请输入合法数字",
			trigger: "blur"
		}
	],
	changeBefore: [
		{
			required: true,
			message: "请输入变动后余额",
			trigger: "blur"
		},
		{
			validator: numberValidator,
			message: "请输入合法数字",
			trigger: "blur"
		}
	],
	batchNo: [
		{
			validator: numberValidator,
			message: "请输入合法数字",
			trigger: "blur"
		}
	],
	syncTimes: [
		{
			validator: numberValidator,
			message: "请输入合法数字",
			trigger: "blur"
		}
	]
},
      query:{
	orderNo: null,
	deliveryId: null,
	channelNo: null,
	changeType: null,
	changeMoney: null,
	changeAfter: null,
	changeBefore: null,
	syncStatus: null,
	batchNo: null,
	syncTimes: null,
	operator: null,
	reamark: null,
	recordId: null
},
    }
  },
}
</script>