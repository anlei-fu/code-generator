<template>
  <Modal ref="modal" @onOk="submit" :onCancel="close" width="40%" :title="title">
    <el-form ref="form" :model="query" :rules="rules" label-position="right" label-width="120px">
      <el-row :gutter="5" v-for="(items,ind) in fields" :key="ind">
        <el-col :span="12" v-for="(item, index) in items" :key="index">
          <el-form-item :label="item.label" :prop="item.prop">
            <Input v-if="item.type=='text'" width="100%" v-model.trim="query[item.prop]" :readonly="!isAdd&&item.noEdit" :placeHolder="item.placeholder" />
            <Select v-else-if="item.type=='select'" width="100%" :enum="item.enum" :readonly="!isAdd&&item.noEdit" v-model="query[item.prop]"/>
            <Select v-else-if="item.type=='textarea'" width="100%" :readonly="!isAdd&&item.noEdit" v-model="query[item.prop]"/>
          </el-form-item>
        </el-col>
      </el-row>
    </el-form>
  </Modal>
</template>
<script>
/**
 * 流程信息
 * 
 * generated at 2021-1-13 9:37:32 AM
 */

import editPageMixin from "./../../../edit-page-mixin";
export default {
 mixins:[editPageMixin],
  data() {
    return {
      description:'流程信息',
      pkName:'flowId',
      apiPrefix:'',
      fields:[
	[
		{
			prop: "flowName",
			label: "流程名称",
			type: "text"
		},
		{
			prop: "flowType",
			label: "流程类型",
			type: "select",
			enum: "flowType"
		},
		{
			prop: "status",
			label: "状态",
			type: "select",
			enum: "status"
		}
	],
	[
		{
			prop: "remark",
			label: "备注",
			type: "textarea"
		}
	]
],
      rules: {
	flowName: [
		{
			required: true,
			message: "请输入流程名称",
			trigger: "blur"
		}
	],
	flowType: [
		{
			required: true,
			message: "请选择流程类型",
			trigger: "blur"
		}
	],
	status: [
		{
			required: true,
			message: "请选择状态",
			trigger: "blur"
		}
	]
},
      query:{
	flowName: null,
	flowType: null,
	status: null,
	remark: null,
	flowId: null
},
    }
  },
}
</script>