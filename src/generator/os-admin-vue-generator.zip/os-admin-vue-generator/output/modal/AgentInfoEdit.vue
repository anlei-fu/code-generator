<template>
  <Modal ref="modal" @onOk="submit" :onCancel="close" width="40%" :title="title">
    <el-form ref="form" :model="query" :rules="rules" label-position="right" label-width="120px">
      <el-row :gutter="5" v-for="(items,ind) in fields" :key="ind">
        <el-col :span="12" v-for="(item, index) in items" :key="index">
          <el-form-item :label="item.label" :prop="item.prop">
            <Input v-if="item.type=='text'" width="100%" v-model.trim="query[item.prop]" :readonly="!isAdd&&item.noEdit" :placeHolder="item.placeholder" />
            <Select v-else-if="item.type=='select'" width="100%" :enum="item.enum" :readonly="!isAdd&&item.noEdit" v-model="query[item.prop]"/>
            <Select v-else-if="item.type=='textarea'" width="100%" :readonly="!isAdd&&item.noEdit" v-model="query[item.prop]"/>
          </el-form-item>
        </el-col>
      </el-row>
    </el-form>
  </Modal>
</template>
<script>
/**
 * 代理商信息表
 * 
 * generated at 2021-1-13 9:37:32 AM
 */
import { numberValidator } from "./../../../../../util/Validators";
import editPageMixin from "./../../../edit-page-mixin";
export default {
 mixins:[editPageMixin],
  data() {
    return {
      description:'代理商信息表',
      pkName:'agentNo',
      apiPrefix:'plat-agent/agent',
      fields:[
	[
		{
			prop: "agentName",
			label: "代理商名称",
			type: "text"
		},
		{
			prop: "agentType",
			label: "代理商类型",
			type: "select",
			enum: "agentType"
		},
		{
			prop: "carrierLicense",
			label: "运营商资质",
			type: "select",
			enum: "carrierLicense"
		}
	],
	[
		{
			prop: "agentBalanc",
			label: "代理商余额",
			type: "text"
		},
		{
			prop: "fcBalance",
			label: "记账余额",
			type: "text"
		}
	],
	[
		{
			prop: "cashBalance",
			label: "现金余额",
			type: "text"
		},
		{
			prop: "validBalance",
			label: "账面余额",
			type: "text"
		}
	],
	[
		{
			prop: "syncFlag",
			label: "记账同步",
			type: "select",
			enum: "syncFlag"
		},
		{
			prop: "status",
			label: "状态",
			type: "select",
			enum: "status"
		}
	],
	[
		{
			prop: "remark",
			label: "备注",
			type: "textarea"
		}
	]
],
      rules: {
	agentName: [
		{
			required: true,
			message: "请输入代理商名称",
			trigger: "blur"
		}
	],
	agentType: [
		{
			required: true,
			message: "请选择代理商类型",
			trigger: "blur"
		}
	],
	carrierLicense: [
		{
			required: true,
			message: "请选择运营商资质",
			trigger: "blur"
		}
	],
	agentBalanc: [
		{
			required: true,
			message: "请输入代理商余额",
			trigger: "blur"
		},
		{
			validator: numberValidator,
			message: "请输入合法数字",
			trigger: "blur"
		}
	],
	fcBalance: [
		{
			required: true,
			message: "请输入记账余额",
			trigger: "blur"
		},
		{
			validator: numberValidator,
			message: "请输入合法数字",
			trigger: "blur"
		}
	],
	cashBalance: [
		{
			required: true,
			message: "请输入现金余额",
			trigger: "blur"
		},
		{
			validator: numberValidator,
			message: "请输入合法数字",
			trigger: "blur"
		}
	],
	validBalance: [
		{
			required: true,
			message: "请输入账面余额",
			trigger: "blur"
		},
		{
			validator: numberValidator,
			message: "请输入合法数字",
			trigger: "blur"
		}
	],
	syncFlag: [
		{
			required: true,
			message: "请选择记账同步",
			trigger: "blur"
		}
	],
	status: [
		{
			required: true,
			message: "请选择状态",
			trigger: "blur"
		}
	]
},
      query:{
	agentName: null,
	agentType: null,
	carrierLicense: null,
	agentBalanc: null,
	fcBalance: null,
	cashBalance: null,
	validBalance: null,
	syncFlag: null,
	status: null,
	remark: null,
	agentNo: null
},
    }
  },
}
</script>