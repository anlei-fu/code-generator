<template>
  <Modal ref="modal" @onOk="submit" :onCancel="close" width="40%" :title="title">
    <el-form ref="form" :model="query" :rules="rules" label-position="right" label-width="120px">
      <el-row :gutter="5" v-for="(items,ind) in fields" :key="ind">
        <el-col :span="12" v-for="(item, index) in items" :key="index">
          <el-form-item :label="item.label" :prop="item.prop">
            <Input v-if="item.type=='text'" width="100%" v-model.trim="query[item.prop]" :readonly="!isAdd&&item.noEdit" :placeHolder="item.placeholder" />
            <Select v-else-if="item.type=='select'" width="100%" :enum="item.enum" :readonly="!isAdd&&item.noEdit" v-model="query[item.prop]"/>
            <Select v-else-if="item.type=='textarea'" width="100%" :readonly="!isAdd&&item.noEdit" v-model="query[item.prop]"/>
          </el-form-item>
        </el-col>
      </el-row>
    </el-form>
  </Modal>
</template>
<script>
/**
 * 发货记录表
 * 
 * generated at 2021-1-13 9:37:32 AM
 */
import { numberValidator } from "./../../../../../util/Validators";
import editPageMixin from "./../../../edit-page-mixin";
export default {
 mixins:[editPageMixin],
  data() {
    return {
      description:'发货记录表',
      pkName:'deliveryId',
      apiPrefix:'',
      fields:[
	[
		{
			prop: "orderNo",
			label: "订单号",
			type: "text"
		},
		{
			prop: "termNo",
			label: "终端编号",
			type: "select",
			enum: "termNo"
		},
		{
			prop: "termProductNo",
			label: "终端产品",
			type: "select",
			enum: "termProductNo"
		}
	],
	[
		{
			prop: "termPrice",
			label: "终端价格",
			type: "text"
		},
		{
			prop: "accountNo",
			label: "办理账号",
			type: "text"
		}
	],
	[
		{
			prop: "upChannelNo",
			label: "上游渠道",
			type: "select",
			enum: "upChannelNo"
		},
		{
			prop: "upProductNo",
			label: "上游产品",
			type: "select",
			enum: "upProductNo"
		}
	],
	[
		{
			prop: "upPrice",
			label: "上游价格",
			type: "text"
		},
		{
			prop: "upOrderNo",
			label: "上游订单号",
			type: "text"
		}
	],
	[
		{
			prop: "deliveryStatus",
			label: "发货状态",
			type: "select",
			enum: "deliveryStatus"
		},
		{
			prop: "manualStatus",
			label: "人工状态",
			type: "select",
			enum: "manualStatus"
		}
	],
	[
		{
			prop: "resultMsg",
			label: "上游结果",
			type: "textarea"
		},
		{
			prop: "execBatchNo",
			label: "下次执行批次",
			type: "text"
		}
	],
	[
		{
			prop: "execTimes",
			label: "执行次数",
			type: "text"
		},
		{
			prop: "serviceCode",
			label: "服务编码",
			type: "text"
		}
	],
	[
		{
			prop: "serverIp",
			label: "服务器IP",
			type: "text"
		}
	]
],
      rules: {
	orderNo: [
		{
			required: true,
			message: "请输入订单号",
			trigger: "blur"
		}
	],
	termNo: [
		{
			required: true,
			message: "请选择终端编号",
			trigger: "blur"
		}
	],
	termProductNo: [
		{
			required: true,
			message: "请选择终端产品",
			trigger: "blur"
		}
	],
	termPrice: [
		{
			required: true,
			message: "请输入终端价格",
			trigger: "blur"
		},
		{
			validator: numberValidator,
			message: "请输入合法数字",
			trigger: "blur"
		}
	],
	accountNo: [
		{
			required: true,
			message: "请输入办理账号",
			trigger: "blur"
		}
	],
	upChannelNo: [
		{
			required: true,
			message: "请选择上游渠道",
			trigger: "blur"
		}
	],
	upProductNo: [
		{
			required: true,
			message: "请选择上游产品",
			trigger: "blur"
		}
	],
	upPrice: [
		{
			required: true,
			message: "请输入上游价格",
			trigger: "blur"
		},
		{
			validator: numberValidator,
			message: "请输入合法数字",
			trigger: "blur"
		}
	],
	deliveryStatus: [
		{
			required: true,
			message: "请选择发货状态",
			trigger: "blur"
		}
	],
	manualStatus: [
		{
			required: true,
			message: "请选择人工状态",
			trigger: "blur"
		}
	],
	execBatchNo: [
		{
			validator: numberValidator,
			message: "请输入合法数字",
			trigger: "blur"
		}
	],
	execTimes: [
		{
			required: true,
			message: "请输入执行次数",
			trigger: "blur"
		},
		{
			validator: numberValidator,
			message: "请输入合法数字",
			trigger: "blur"
		}
	],
	serviceCode: [
		{
			required: true,
			message: "请输入服务编码",
			trigger: "blur"
		}
	]
},
      query:{
	orderNo: null,
	termNo: null,
	termProductNo: null,
	termPrice: null,
	accountNo: null,
	upChannelNo: null,
	upProductNo: null,
	upPrice: null,
	upOrderNo: null,
	deliveryStatus: null,
	manualStatus: null,
	resultMsg: null,
	execBatchNo: null,
	execTimes: null,
	serviceCode: null,
	serverIp: null,
	deliveryId: null
},
    }
  },
}
</script>