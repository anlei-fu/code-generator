<template>
  <Modal ref="modal" @onOk="submit" :onCancel="close" width="40%" :title="title">
    <el-form ref="form" :model="query" :rules="rules" label-position="right" label-width="120px">
      <el-row :gutter="5" v-for="(items,ind) in fields" :key="ind">
        <el-col :span="12" v-for="(item, index) in items" :key="index">
          <el-form-item :label="item.label" :prop="item.prop">
            <Input v-if="item.type=='text'" width="100%" v-model.trim="query[item.prop]" :readonly="!isAdd&&item.noEdit" :placeHolder="item.placeholder" />
            <Select v-else-if="item.type=='select'" width="100%" :enum="item.enum" :readonly="!isAdd&&item.noEdit" v-model="query[item.prop]"/>
            <Select v-else-if="item.type=='textarea'" width="100%" :readonly="!isAdd&&item.noEdit" v-model="query[item.prop]"/>
          </el-form-item>
        </el-col>
      </el-row>
    </el-form>
  </Modal>
</template>
<script>
/**
 * 广告主转化
 * 
 * generated at 2021-1-13 9:37:32 AM
 */
import { numberValidator } from "./../../../../../util/Validators";
import editPageMixin from "./../../../edit-page-mixin";
export default {
 mixins:[editPageMixin],
  data() {
    return {
      description:'广告主转化',
      pkName:'convertId',
      apiPrefix:'advertiser/advertiser-convert',
      fields:[
	[
		{
			prop: "convertUid",
			label: "转化编号",
			type: "select",
			enum: "convertUid"
		},
		{
			prop: "advertiserUid",
			label: "广告主编号",
			type: "text"
		},
		{
			prop: "convertName",
			label: "转化名称",
			type: "text"
		}
	],
	[
		{
			prop: "pageId",
			label: "落地页编号",
			type: "select",
			enum: "pageId"
		},
		{
			prop: "reportType",
			label: "回码类型",
			type: "select",
			enum: "reportType"
		}
	],
	[
		{
			prop: "reportPoint",
			label: "回码点",
			type: "text"
		},
		{
			prop: "activeStatus",
			label: "激活状态",
			type: "select",
			enum: "activeStatus"
		}
	],
	[
		{
			prop: "activeArgs",
			label: "激活参数",
			type: "text"
		}
	]
],
      rules: {
	convertUid: [
		{
			required: true,
			message: "请选择转化编号",
			trigger: "blur"
		}
	],
	advertiserUid: [
		{
			required: true,
			message: "请输入广告主编号",
			trigger: "blur"
		},
		{
			validator: numberValidator,
			message: "请输入合法数字",
			trigger: "blur"
		}
	],
	convertName: [
		{
			required: true,
			message: "请输入转化名称",
			trigger: "blur"
		}
	],
	pageId: [
		{
			required: true,
			message: "请选择落地页编号",
			trigger: "blur"
		}
	],
	reportType: [
		{
			required: true,
			message: "请选择回码类型",
			trigger: "blur"
		}
	],
	reportPoint: [
		{
			required: true,
			message: "请输入回码点",
			trigger: "blur"
		},
		{
			validator: numberValidator,
			message: "请输入合法数字",
			trigger: "blur"
		}
	],
	activeStatus: [
		{
			required: true,
			message: "请选择激活状态",
			trigger: "blur"
		}
	]
},
      query:{
	convertUid: null,
	advertiserUid: null,
	convertName: null,
	pageId: null,
	reportType: null,
	reportPoint: null,
	activeStatus: null,
	activeArgs: null,
	convertId: null
},
    }
  },
}
</script>