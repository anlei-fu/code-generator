<template>
  <Modal ref="modal" @onOk="submit" :onCancel="close" width="40%" :title="title">
    <el-form ref="form" :model="query" :rules="rules" label-position="right" label-width="120px">
      <el-row :gutter="5" v-for="(items,ind) in fields" :key="ind">
        <el-col :span="12" v-for="(item, index) in items" :key="index">
          <el-form-item :label="item.label" :prop="item.prop">
            <Input v-if="item.type=='text'" width="100%" v-model.trim="query[item.prop]" :readonly="!isAdd&&item.noEdit" :placeHolder="item.placeholder" />
            <Select v-else-if="item.type=='select'" width="100%" :enum="item.enum" :readonly="!isAdd&&item.noEdit" v-model="query[item.prop]"/>
            <Select v-else-if="item.type=='textarea'" width="100%" :readonly="!isAdd&&item.noEdit" v-model="query[item.prop]"/>
          </el-form-item>
        </el-col>
      </el-row>
    </el-form>
  </Modal>
</template>
<script>
/**
 * 系统地市表(地级)
 * 
 * generated at 2021-1-13 9:37:32 AM
 */

import editPageMixin from "./../../../edit-page-mixin";
export default {
 mixins:[editPageMixin],
  data() {
    return {
      description:'系统地市表(地级)',
      pkName:'cityCode',
      apiPrefix:'',
      fields:[
	[
		{
			prop: "cityNo",
			label: "地市编码",
			type: "text"
		},
		{
			prop: "cityName",
			label: "地市名称",
			type: "text"
		},
		{
			prop: "provinceNo",
			label: "省份编码",
			type: "text"
		}
	]
],
      rules: {
	cityNo: [
		{
			required: true,
			message: "请输入地市编码",
			trigger: "blur"
		}
	],
	cityName: [
		{
			required: true,
			message: "请输入地市名称",
			trigger: "blur"
		}
	],
	provinceNo: [
		{
			required: true,
			message: "请输入省份编码",
			trigger: "blur"
		}
	]
},
      query:{
	cityNo: null,
	cityName: null,
	provinceNo: null,
	cityCode: null
},
    }
  },
}
</script>