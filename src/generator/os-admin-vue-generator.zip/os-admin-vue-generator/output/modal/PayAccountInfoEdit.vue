<template>
  <Modal ref="modal" @onOk="submit" :onCancel="close" width="40%" :title="title">
    <el-form ref="form" :model="query" :rules="rules" label-position="right" label-width="120px">
      <el-row :gutter="5" v-for="(items,ind) in fields" :key="ind">
        <el-col :span="12" v-for="(item, index) in items" :key="index">
          <el-form-item :label="item.label" :prop="item.prop">
            <Input v-if="item.type=='text'" width="100%" v-model.trim="query[item.prop]" :readonly="!isAdd&&item.noEdit" :placeHolder="item.placeholder" />
            <Select v-else-if="item.type=='select'" width="100%" :enum="item.enum" :readonly="!isAdd&&item.noEdit" v-model="query[item.prop]"/>
            <Select v-else-if="item.type=='textarea'" width="100%" :readonly="!isAdd&&item.noEdit" v-model="query[item.prop]"/>
          </el-form-item>
        </el-col>
      </el-row>
    </el-form>
  </Modal>
</template>
<script>
/**
 * 支付账号表
 * 
 * generated at 2021-1-13 9:37:32 AM
 */
import { numberValidator } from "./../../../../../util/Validators";
import editPageMixin from "./../../../edit-page-mixin";
export default {
 mixins:[editPageMixin],
  data() {
    return {
      description:'支付账号表',
      pkName:'accountId',
      apiPrefix:'pay/account',
      fields:[
	[
		{
			prop: "accountName",
			label: "账号名称",
			type: "text"
		},
		{
			prop: "accountType",
			label: "账号类型",
			type: "text"
		},
		{
			prop: "merchantId",
			label: "商户编号",
			type: "text"
		}
	],
	[
		{
			prop: "signKey",
			label: "签名KEY",
			type: "text"
		},
		{
			prop: "certPath",
			label: "证书路径",
			type: "text"
		}
	],
	[
		{
			prop: "certPwd",
			label: "证书密钥",
			type: "text"
		},
		{
			prop: "publicKey",
			label: "加密公钥",
			type: "text"
		}
	],
	[
		{
			prop: "privateKey",
			label: "解密/验签私钥",
			type: "text"
		},
		{
			prop: "balance",
			label: "账户余额",
			type: "text"
		}
	],
	[
		{
			prop: "authRedirectUrl",
			label: "API授权跳转地址",
			type: "text"
		},
		{
			prop: "payRedirectUrl",
			label: "支付完成跳转地址",
			type: "text"
		}
	],
	[
		{
			prop: "payCallbackUrl",
			label: "支付结果回调地址",
			type: "text"
		},
		{
			prop: "refundCallbackUrl",
			label: "退款回调地址",
			type: "text"
		}
	],
	[
		{
			prop: "status",
			label: "状态",
			type: "select",
			enum: "status"
		},
		{
			prop: "remark",
			label: "备注",
			type: "textarea"
		}
	],
	[
		{
			prop: "crateUser",
			label: "创建人",
			type: "text"
		},
		{
			prop: "appId",
			label: "",
			type: "text"
		}
	],
	[
		{
			prop: "appSecret",
			label: "",
			type: "text"
		}
	]
],
      rules: {
	accountName: [
		{
			required: true,
			message: "请输入账号名称",
			trigger: "blur"
		}
	],
	accountType: [
		{
			required: true,
			message: "请输入账号类型",
			trigger: "blur"
		},
		{
			validator: numberValidator,
			message: "请输入合法数字",
			trigger: "blur"
		}
	],
	balance: [
		{
			required: true,
			message: "请输入账户余额",
			trigger: "blur"
		},
		{
			validator: numberValidator,
			message: "请输入合法数字",
			trigger: "blur"
		}
	],
	status: [
		{
			required: true,
			message: "请选择状态",
			trigger: "blur"
		}
	]
},
      query:{
	accountName: null,
	accountType: null,
	merchantId: null,
	signKey: null,
	certPath: null,
	certPwd: null,
	publicKey: null,
	privateKey: null,
	balance: null,
	authRedirectUrl: null,
	payRedirectUrl: null,
	payCallbackUrl: null,
	refundCallbackUrl: null,
	status: null,
	remark: null,
	crateUser: null,
	appId: null,
	appSecret: null,
	accountId: null
},
    }
  },
}
</script>