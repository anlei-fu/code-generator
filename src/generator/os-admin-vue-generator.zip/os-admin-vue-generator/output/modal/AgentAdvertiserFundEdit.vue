<template>
  <Modal ref="modal" @onOk="submit" :onCancel="close" width="40%" :title="title">
    <el-form ref="form" :model="query" :rules="rules" label-position="right" label-width="120px">
      <el-row :gutter="5" v-for="(items,ind) in fields" :key="ind">
        <el-col :span="12" v-for="(item, index) in items" :key="index">
          <el-form-item :label="item.label" :prop="item.prop">
            <Input v-if="item.type=='text'" width="100%" v-model.trim="query[item.prop]" :readonly="!isAdd&&item.noEdit" :placeHolder="item.placeholder" />
            <Select v-else-if="item.type=='select'" width="100%" :enum="item.enum" :readonly="!isAdd&&item.noEdit" v-model="query[item.prop]"/>
            <Select v-else-if="item.type=='textarea'" width="100%" :readonly="!isAdd&&item.noEdit" v-model="query[item.prop]"/>
          </el-form-item>
        </el-col>
      </el-row>
    </el-form>
  </Modal>
</template>
<script>
/**
 * 广告主资金流水
 * 
 * generated at 2021-1-13 9:37:32 AM
 */
import { numberValidator } from "./../../../../../util/Validators";
import editPageMixin from "./../../../edit-page-mixin";
export default {
 mixins:[editPageMixin],
  data() {
    return {
      description:'广告主资金流水',
      pkName:'recordId',
      apiPrefix:'advertiser/advertiser-fund',
      fields:[
	[
		{
			prop: "advertiserUid",
			label: "广告主编号",
			type: "text"
		},
		{
			prop: "dayBalance",
			label: "日终结余",
			type: "text"
		},
		{
			prop: "cashCost",
			label: "现金支出",
			type: "text"
		}
	],
	[
		{
			prop: "totalCost",
			label: "总支出",
			type: "text"
		},
		{
			prop: "totalFrozen",
			label: "冻结",
			type: "text"
		}
	],
	[
		{
			prop: "totalIncome",
			label: "总存入",
			type: "text"
		},
		{
			prop: "rewardCost",
			label: "赠款支出",
			type: "text"
		}
	],
	[
		{
			prop: "returnCost",
			label: "返货支出",
			type: "text"
		},
		{
			prop: "totalTransferIn",
			label: "总转入",
			type: "text"
		}
	],
	[
		{
			prop: "totalTransferOut",
			label: "总转出",
			type: "text"
		},
		{
			prop: "syncStatus",
			label: "同步状态",
			type: "select",
			enum: "syncStatus"
		}
	],
	[
		{
			prop: "syncMsg",
			label: "同步结果",
			type: "textarea"
		}
	]
],
      rules: {
	advertiserUid: [
		{
			required: true,
			message: "请输入广告主编号",
			trigger: "blur"
		},
		{
			validator: numberValidator,
			message: "请输入合法数字",
			trigger: "blur"
		}
	],
	dayBalance: [
		{
			validator: numberValidator,
			message: "请输入合法数字",
			trigger: "blur"
		}
	],
	cashCost: [
		{
			validator: numberValidator,
			message: "请输入合法数字",
			trigger: "blur"
		}
	],
	totalCost: [
		{
			validator: numberValidator,
			message: "请输入合法数字",
			trigger: "blur"
		}
	],
	totalFrozen: [
		{
			validator: numberValidator,
			message: "请输入合法数字",
			trigger: "blur"
		}
	],
	totalIncome: [
		{
			validator: numberValidator,
			message: "请输入合法数字",
			trigger: "blur"
		}
	],
	rewardCost: [
		{
			validator: numberValidator,
			message: "请输入合法数字",
			trigger: "blur"
		}
	],
	returnCost: [
		{
			validator: numberValidator,
			message: "请输入合法数字",
			trigger: "blur"
		}
	],
	totalTransferIn: [
		{
			validator: numberValidator,
			message: "请输入合法数字",
			trigger: "blur"
		}
	],
	totalTransferOut: [
		{
			validator: numberValidator,
			message: "请输入合法数字",
			trigger: "blur"
		}
	],
	syncStatus: [
		{
			required: true,
			message: "请选择同步状态",
			trigger: "blur"
		}
	]
},
      query:{
	advertiserUid: null,
	dayBalance: null,
	cashCost: null,
	totalCost: null,
	totalFrozen: null,
	totalIncome: null,
	rewardCost: null,
	returnCost: null,
	totalTransferIn: null,
	totalTransferOut: null,
	syncStatus: null,
	syncMsg: null,
	recordId: null
},
    }
  },
}
</script>