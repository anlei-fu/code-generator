<template>
  <Modal ref="modal" @onOk="submit" :onCancel="close" width="40%" :title="title">
    <el-form ref="form" :model="query" :rules="rules" label-position="right" label-width="120px">
      <el-row :gutter="5" v-for="(items,ind) in fields" :key="ind">
        <el-col :span="12" v-for="(item, index) in items" :key="index">
          <el-form-item :label="item.label" :prop="item.prop">
            <Input v-if="item.type=='text'" width="100%" v-model.trim="query[item.prop]" :readonly="!isAdd&&item.noEdit" :placeHolder="item.placeholder" />
            <Select v-else-if="item.type=='select'" width="100%" :enum="item.enum" :readonly="!isAdd&&item.noEdit" v-model="query[item.prop]"/>
            <Select v-else-if="item.type=='textarea'" width="100%" :readonly="!isAdd&&item.noEdit" v-model="query[item.prop]"/>
          </el-form-item>
        </el-col>
      </el-row>
    </el-form>
  </Modal>
</template>
<script>
/**
 * 订单主表
 * 
 * generated at 2021-1-13 9:37:32 AM
 */
import { numberValidator } from "./../../../../../util/Validators";
import editPageMixin from "./../../../edit-page-mixin";
export default {
 mixins:[editPageMixin],
  data() {
    return {
      description:'订单主表',
      pkName:'orderNo',
      apiPrefix:'',
      fields:[
	[
		{
			prop: "termNo",
			label: "终端编号",
			type: "select",
			enum: "termNo"
		},
		{
			prop: "termProductNo",
			label: "终端产品编号",
			type: "select",
			enum: "termProductNo"
		},
		{
			prop: "platNo",
			label: "平台编号",
			type: "select",
			enum: "platNo"
		}
	],
	[
		{
			prop: "agentNo",
			label: "代理商编号",
			type: "select",
			enum: "agentNo"
		},
		{
			prop: "accountId",
			label: "投放账户编号",
			type: "text"
		}
	],
	[
		{
			prop: "advertiserUid",
			label: "广告主编号",
			type: "text"
		},
		{
			prop: "pageId",
			label: "落地页编号",
			type: "select",
			enum: "pageId"
		}
	],
	[
		{
			prop: "convertUid",
			label: "转化编号",
			type: "select",
			enum: "convertUid"
		},
		{
			prop: "businessType",
			label: "业务类型",
			type: "select",
			enum: "businessType"
		}
	],
	[
		{
			prop: "productType",
			label: "产品类型",
			type: "select",
			enum: "productType"
		},
		{
			prop: "carrierNo",
			label: "运营商编码",
			type: "text"
		}
	],
	[
		{
			prop: "provinceNo",
			label: "省份编码",
			type: "text"
		},
		{
			prop: "cityNo",
			label: "地市编码",
			type: "text"
		}
	],
	[
		{
			prop: "accountNo",
			label: "办理账号",
			type: "text"
		},
		{
			prop: "faceFee",
			label: "订单面值",
			type: "text"
		}
	],
	[
		{
			prop: "costPrice",
			label: "订单成本",
			type: "text"
		},
		{
			prop: "orderStatus",
			label: "订单状态",
			type: "select",
			enum: "orderStatus"
		}
	],
	[
		{
			prop: "resultMsg",
			label: "订单结果",
			type: "textarea"
		},
		{
			prop: "manualStatus",
			label: "人工状态",
			type: "select",
			enum: "manualStatus"
		}
	],
	[
		{
			prop: "userIp",
			label: "用户IP",
			type: "text"
		},
		{
			prop: "serverIp",
			label: "服务器IP",
			type: "text"
		}
	],
	[
		{
			prop: "execBatchNo",
			label: "下次执行批次",
			type: "text"
		},
		{
			prop: "execTimes",
			label: "执行次数",
			type: "text"
		}
	],
	[
		{
			prop: "userParams",
			label: "用户参数",
			type: "text"
		},
		{
			prop: "extend1",
			label: "扩展字段1",
			type: "text"
		}
	],
	[
		{
			prop: "extend2",
			label: "扩展字段2",
			type: "text"
		},
		{
			prop: "extend3",
			label: "扩展字段3",
			type: "text"
		}
	],
	[
		{
			prop: "extend4",
			label: "扩展字段4",
			type: "text"
		},
		{
			prop: "extend5",
			label: "扩展字段5",
			type: "text"
		}
	],
	[
		{
			prop: "platParams",
			label: "平台参数",
			type: "text"
		}
	]
],
      rules: {
	termNo: [
		{
			required: true,
			message: "请选择终端编号",
			trigger: "blur"
		}
	],
	termProductNo: [
		{
			required: true,
			message: "请选择终端产品编号",
			trigger: "blur"
		}
	],
	platNo: [
		{
			required: true,
			message: "请选择平台编号",
			trigger: "blur"
		}
	],
	agentNo: [
		{
			required: true,
			message: "请选择代理商编号",
			trigger: "blur"
		}
	],
	accountId: [
		{
			required: true,
			message: "请输入投放账户编号",
			trigger: "blur"
		},
		{
			validator: numberValidator,
			message: "请输入合法数字",
			trigger: "blur"
		}
	],
	advertiserUid: [
		{
			required: true,
			message: "请输入广告主编号",
			trigger: "blur"
		},
		{
			validator: numberValidator,
			message: "请输入合法数字",
			trigger: "blur"
		}
	],
	pageId: [
		{
			required: true,
			message: "请选择落地页编号",
			trigger: "blur"
		}
	],
	businessType: [
		{
			required: true,
			message: "请选择业务类型",
			trigger: "blur"
		}
	],
	productType: [
		{
			required: true,
			message: "请选择产品类型",
			trigger: "blur"
		}
	],
	carrierNo: [
		{
			required: true,
			message: "请输入运营商编码",
			trigger: "blur"
		}
	],
	provinceNo: [
		{
			required: true,
			message: "请输入省份编码",
			trigger: "blur"
		}
	],
	cityNo: [
		{
			required: true,
			message: "请输入地市编码",
			trigger: "blur"
		}
	],
	accountNo: [
		{
			required: true,
			message: "请输入办理账号",
			trigger: "blur"
		}
	],
	faceFee: [
		{
			required: true,
			message: "请输入订单面值",
			trigger: "blur"
		},
		{
			validator: numberValidator,
			message: "请输入合法数字",
			trigger: "blur"
		}
	],
	costPrice: [
		{
			required: true,
			message: "请输入订单成本",
			trigger: "blur"
		},
		{
			validator: numberValidator,
			message: "请输入合法数字",
			trigger: "blur"
		}
	],
	orderStatus: [
		{
			required: true,
			message: "请选择订单状态",
			trigger: "blur"
		}
	],
	manualStatus: [
		{
			required: true,
			message: "请选择人工状态",
			trigger: "blur"
		}
	],
	userIp: [
		{
			required: true,
			message: "请输入用户IP",
			trigger: "blur"
		}
	],
	serverIp: [
		{
			required: true,
			message: "请输入服务器IP",
			trigger: "blur"
		}
	],
	execBatchNo: [
		{
			validator: numberValidator,
			message: "请输入合法数字",
			trigger: "blur"
		}
	],
	execTimes: [
		{
			validator: numberValidator,
			message: "请输入合法数字",
			trigger: "blur"
		}
	]
},
      query:{
	termNo: null,
	termProductNo: null,
	platNo: null,
	agentNo: null,
	accountId: null,
	advertiserUid: null,
	pageId: null,
	convertUid: null,
	businessType: null,
	productType: null,
	carrierNo: null,
	provinceNo: null,
	cityNo: null,
	accountNo: null,
	faceFee: null,
	costPrice: null,
	orderStatus: null,
	resultMsg: null,
	manualStatus: null,
	userIp: null,
	serverIp: null,
	execBatchNo: null,
	execTimes: null,
	userParams: null,
	extend1: null,
	extend2: null,
	extend3: null,
	extend4: null,
	extend5: null,
	platParams: null,
	orderNo: null
},
    }
  },
}
</script>