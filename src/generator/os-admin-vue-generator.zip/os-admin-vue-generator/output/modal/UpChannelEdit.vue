<template>
  <Modal ref="modal" @onOk="submit" :onCancel="close" width="40%" :title="title">
    <el-form ref="form" :model="query" :rules="rules" label-position="right" label-width="120px">
      <el-row :gutter="5" v-for="(items,ind) in fields" :key="ind">
        <el-col :span="12" v-for="(item, index) in items" :key="index">
          <el-form-item :label="item.label" :prop="item.prop">
            <Input v-if="item.type=='text'" width="100%" v-model.trim="query[item.prop]" :readonly="!isAdd&&item.noEdit" :placeHolder="item.placeholder" />
            <Select v-else-if="item.type=='select'" width="100%" :enum="item.enum" :readonly="!isAdd&&item.noEdit" v-model="query[item.prop]"/>
            <Select v-else-if="item.type=='textarea'" width="100%" :readonly="!isAdd&&item.noEdit" v-model="query[item.prop]"/>
          </el-form-item>
        </el-col>
      </el-row>
    </el-form>
  </Modal>
</template>
<script>
/**
 * 上游渠道信息
 * 
 * generated at 2021-1-13 9:37:32 AM
 */
import { numberValidator } from "./../../../../../util/Validators";
import editPageMixin from "./../../../edit-page-mixin";
export default {
 mixins:[editPageMixin],
  data() {
    return {
      description:'上游渠道信息',
      pkName:'channelNo',
      apiPrefix:'',
      fields:[
	[
		{
			prop: "channelName",
			label: "渠道名称",
			type: "text"
		},
		{
			prop: "apiUid",
			label: "接口UID",
			type: "text"
		},
		{
			prop: "apiSecret",
			label: "接口SECRET",
			type: "text"
		}
	],
	[
		{
			prop: "notifyUrl",
			label: "通知地址",
			type: "text"
		},
		{
			prop: "loginUid",
			label: "后台账号",
			type: "text"
		}
	],
	[
		{
			prop: "loginPwd",
			label: "后台密码",
			type: "text"
		},
		{
			prop: "balance",
			label: "渠道余额",
			type: "text"
		}
	],
	[
		{
			prop: "canQuery",
			label: "支持查询",
			type: "text"
		},
		{
			prop: "queryDelay",
			label: "首次查询延迟",
			type: "text"
		}
	],
	[
		{
			prop: "queryIntvl",
			label: "查询间隔",
			type: "text"
		},
		{
			prop: "queryMaxTimes",
			label: "最大查询次数",
			type: "text"
		}
	],
	[
		{
			prop: "syncFlag",
			label: "同步记账",
			type: "select",
			enum: "syncFlag"
		},
		{
			prop: "principal",
			label: "负责人",
			type: "text"
		}
	],
	[
		{
			prop: "status",
			label: "状态",
			type: "select",
			enum: "status"
		},
		{
			prop: "remark",
			label: "备注",
			type: "textarea"
		}
	],
	[
		{
			prop: "channelCode",
			label: "渠道编码",
			type: "text"
		}
	]
],
      rules: {
	channelName: [
		{
			required: true,
			message: "请输入渠道名称",
			trigger: "blur"
		}
	],
	balance: [
		{
			required: true,
			message: "请输入渠道余额",
			trigger: "blur"
		},
		{
			validator: numberValidator,
			message: "请输入合法数字",
			trigger: "blur"
		}
	],
	canQuery: [
		{
			required: true,
			message: "请输入支持查询",
			trigger: "blur"
		},
		{
			validator: numberValidator,
			message: "请输入合法数字",
			trigger: "blur"
		}
	],
	queryDelay: [
		{
			validator: numberValidator,
			message: "请输入合法数字",
			trigger: "blur"
		}
	],
	queryIntvl: [
		{
			required: true,
			message: "请输入查询间隔",
			trigger: "blur"
		},
		{
			validator: numberValidator,
			message: "请输入合法数字",
			trigger: "blur"
		}
	],
	queryMaxTimes: [
		{
			required: true,
			message: "请输入最大查询次数",
			trigger: "blur"
		},
		{
			validator: numberValidator,
			message: "请输入合法数字",
			trigger: "blur"
		}
	],
	syncFlag: [
		{
			required: true,
			message: "请选择同步记账",
			trigger: "blur"
		}
	],
	status: [
		{
			required: true,
			message: "请选择状态",
			trigger: "blur"
		}
	]
},
      query:{
	channelName: null,
	apiUid: null,
	apiSecret: null,
	notifyUrl: null,
	loginUid: null,
	loginPwd: null,
	balance: null,
	canQuery: null,
	queryDelay: null,
	queryIntvl: null,
	queryMaxTimes: null,
	syncFlag: null,
	principal: null,
	status: null,
	remark: null,
	channelCode: null,
	channelNo: null
},
    }
  },
}
</script>