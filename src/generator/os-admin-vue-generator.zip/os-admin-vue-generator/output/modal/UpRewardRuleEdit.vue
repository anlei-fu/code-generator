<template>
  <Modal ref="modal" @onOk="submit" :onCancel="close" width="40%" :title="title">
    <el-form ref="form" :model="query" :rules="rules" label-position="right" label-width="120px">
      <el-row :gutter="5" v-for="(items,ind) in fields" :key="ind">
        <el-col :span="12" v-for="(item, index) in items" :key="index">
          <el-form-item :label="item.label" :prop="item.prop">
            <Input v-if="item.type=='text'" width="100%" v-model.trim="query[item.prop]" :readonly="!isAdd&&item.noEdit" :placeHolder="item.placeholder" />
            <Select v-else-if="item.type=='select'" width="100%" :enum="item.enum" :readonly="!isAdd&&item.noEdit" v-model="query[item.prop]"/>
            <Select v-else-if="item.type=='textarea'" width="100%" :readonly="!isAdd&&item.noEdit" v-model="query[item.prop]"/>
          </el-form-item>
        </el-col>
      </el-row>
    </el-form>
  </Modal>
</template>
<script>
/**
 * 上游返佣规则
 * 
 * generated at 2021-1-13 9:37:32 AM
 */
import { numberValidator } from "./../../../../../util/Validators";
import editPageMixin from "./../../../edit-page-mixin";
export default {
 mixins:[editPageMixin],
  data() {
    return {
      description:'上游返佣规则',
      pkName:'ruleId',
      apiPrefix:'fund-change/reward-rule',
      fields:[
	[
		{
			prop: "productNo",
			label: "产品编码",
			type: "select",
			enum: "productNo"
		},
		{
			prop: "rewardType",
			label: "佣金类型",
			type: "select",
			enum: "rewardType"
		},
		{
			prop: "rewardTimes",
			label: "返佣次数",
			type: "text"
		}
	],
	[
		{
			prop: "firstMonth",
			label: "首返月份",
			type: "text"
		},
		{
			prop: "ruleDetail",
			label: "规则详情",
			type: "textarea"
		}
	],
	[
		{
			prop: "syncFlag",
			label: "同步标识",
			type: "select",
			enum: "syncFlag"
		},
		{
			prop: "status",
			label: "状态",
			type: "select",
			enum: "status"
		}
	]
],
      rules: {
	productNo: [
		{
			required: true,
			message: "请选择产品编码",
			trigger: "blur"
		}
	],
	rewardType: [
		{
			required: true,
			message: "请选择佣金类型",
			trigger: "blur"
		}
	],
	rewardTimes: [
		{
			required: true,
			message: "请输入返佣次数",
			trigger: "blur"
		},
		{
			validator: numberValidator,
			message: "请输入合法数字",
			trigger: "blur"
		}
	],
	firstMonth: [
		{
			required: true,
			message: "请输入首返月份",
			trigger: "blur"
		},
		{
			validator: numberValidator,
			message: "请输入合法数字",
			trigger: "blur"
		}
	],
	ruleDetail: [
		{
			required: true,
			message: "请输入规则详情",
			trigger: "blur"
		}
	],
	syncFlag: [
		{
			required: true,
			message: "请选择同步标识",
			trigger: "blur"
		}
	],
	status: [
		{
			required: true,
			message: "请选择状态",
			trigger: "blur"
		}
	]
},
      query:{
	productNo: null,
	rewardType: null,
	rewardTimes: null,
	firstMonth: null,
	ruleDetail: null,
	syncFlag: null,
	status: null,
	ruleId: null
},
    }
  },
}
</script>