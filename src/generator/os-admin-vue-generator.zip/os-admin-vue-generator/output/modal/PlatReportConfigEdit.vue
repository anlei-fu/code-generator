<template>
  <Modal ref="modal" @onOk="submit" :onCancel="close" width="40%" :title="title">
    <el-form ref="form" :model="query" :rules="rules" label-position="right" label-width="120px">
      <el-row :gutter="5" v-for="(items,ind) in fields" :key="ind">
        <el-col :span="12" v-for="(item, index) in items" :key="index">
          <el-form-item :label="item.label" :prop="item.prop">
            <Input v-if="item.type=='text'" v-model.trim="query[item.prop]" :readonly="!isAdd&&item.noEdit" :placeHolder="item.placeholder" />
            <Select v-else-if="item.type=='select'" :key="item.selectKey" :readonly="!isAdd&&item.noEdit" v-model="query[item.prop]"/>
            <Select v-else-if="item.type=='textarea'" :readonly="!isAdd&&item.noEdit" v-model="query[item.prop]"/>
          </el-form-item>
        </el-col>
      </el-row>
    </el-form>
  </Modal>
</template>
<script>
/**
 * 平台上报配置
 * 
 * generated at 2021-1-8 9:36:49 AM
 */
import editPageMixin from "./../../../edit-page-mixin";
export default {
 mixins:[editPageMixin],
  data() {
    return {
      description:'平台上报配置',
      pkName:'recordId',
      apiPrefix:'plat-report-config',
      fields:[
	[
		{
			prop: "channelNo",
			label: "渠道编号",
			type: "select",
			enum: "channelNo"
		},
		{
			prop: "productNo",
			label: "产品编号",
			type: "select",
			enum: "productNo"
		},
		{
			prop: "platNo",
			label: "平台编号",
			type: "select",
			enum: "platNo"
		}
	],
	[
		{
			prop: "accountId",
			label: "账号编号",
			type: "select",
			enum: "accountId"
		},
		{
			prop: "keyWord",
			label: "关键字",
			type: "text"
		}
	],
	[
		{
			prop: "reportRate",
			label: "上报率",
			type: "text"
		},
		{
			prop: "reportCount",
			label: "上报计数",
			type: "text"
		}
	],
	[
		{
			prop: "reportTotal",
			label: "上报总数",
			type: "text"
		},
		{
			prop: "status",
			label: "状态",
			type: "select",
			enum: "status"
		}
	],
	[
		{
			prop: "remark",
			label: "备注",
			type: "textarea"
		}
	]
],
      rules: {
	channelNo: [
		{
			required: true,
			message: "请选择渠道编号",
			trigger: "blur"
		}
	],
	productNo: [
		{
			required: true,
			message: "请选择产品编号",
			trigger: "blur"
		}
	],
	platNo: [
		{
			required: true,
			message: "请选择平台编号",
			trigger: "blur"
		}
	],
	accountId: [
		{
			required: true,
			message: "请选择账号编号",
			trigger: "blur"
		}
	],
	reportRate: [
		{
			number: true,
			message: "请输入合法数字",
			trigger: "blur"
		}
	],
	reportCount: [
		{
			number: true,
			message: "请输入合法数字",
			trigger: "blur"
		}
	],
	reportTotal: [
		{
			number: true,
			message: "请输入合法数字",
			trigger: "blur"
		}
	],
	status: [
		{
			required: true,
			message: "请选择状态",
			trigger: "blur"
		}
	]
},
      query:{
	channelNo: null,
	productNo: null,
	platNo: null,
	accountId: null,
	keyWord: null,
	reportRate: null,
	reportCount: null,
	reportTotal: null,
	status: null,
	remark: null
},
    }
  },
}
</script>