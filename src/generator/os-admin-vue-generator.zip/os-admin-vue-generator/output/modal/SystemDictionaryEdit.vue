<template>
  <Modal ref="modal" @onOk="submit" :onCancel="close" width="40%" :title="title">
    <el-form ref="form" :model="query" :rules="rules" label-position="right" label-width="120px">
      <el-row :gutter="5" v-for="(items,ind) in fields" :key="ind">
        <el-col :span="12" v-for="(item, index) in items" :key="index">
          <el-form-item :label="item.label" :prop="item.prop">
            <Input v-if="item.type=='text'" width="100%" v-model.trim="query[item.prop]" :readonly="!isAdd&&item.noEdit" :placeHolder="item.placeholder" />
            <Select v-else-if="item.type=='select'" width="100%" :enum="item.enum" :readonly="!isAdd&&item.noEdit" v-model="query[item.prop]"/>
            <Select v-else-if="item.type=='textarea'" width="100%" :readonly="!isAdd&&item.noEdit" v-model="query[item.prop]"/>
          </el-form-item>
        </el-col>
      </el-row>
    </el-form>
  </Modal>
</template>
<script>
/**
 * 系统字典
 * 
 * generated at 2021-1-13 9:37:32 AM
 */
import { numberValidator } from "./../../../../../util/Validators";
import editPageMixin from "./../../../edit-page-mixin";
export default {
 mixins:[editPageMixin],
  data() {
    return {
      description:'系统字典',
      pkName:'recordId',
      apiPrefix:'',
      fields:[
	[
		{
			prop: "dictType",
			label: "字典类型",
			type: "select",
			enum: "dictType"
		},
		{
			prop: "dictValue",
			label: "字典值",
			type: "text"
		},
		{
			prop: "dictDesc",
			label: "字典说明",
			type: "text"
		}
	],
	[
		{
			prop: "sortNum",
			label: "排序编号",
			type: "text"
		}
	]
],
      rules: {
	dictType: [
		{
			required: true,
			message: "请选择字典类型",
			trigger: "blur"
		}
	],
	dictValue: [
		{
			required: true,
			message: "请输入字典值",
			trigger: "blur"
		}
	],
	dictDesc: [
		{
			required: true,
			message: "请输入字典说明",
			trigger: "blur"
		}
	],
	sortNum: [
		{
			required: true,
			message: "请输入排序编号",
			trigger: "blur"
		},
		{
			validator: numberValidator,
			message: "请输入合法数字",
			trigger: "blur"
		}
	]
},
      query:{
	dictType: null,
	dictValue: null,
	dictDesc: null,
	sortNum: null,
	recordId: null
},
    }
  },
}
</script>