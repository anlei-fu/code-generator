<template>
  <Modal ref="modal" @onOk="submit" :onCancel="close" width="40%" :title="title">
    <el-form ref="form" :model="query" :rules="rules" label-position="right" label-width="120px">
      <el-row :gutter="5" v-for="(items,ind) in fields" :key="ind">
        <el-col :span="12" v-for="(item, index) in items" :key="index">
          <el-form-item :label="item.label" :prop="item.prop">
            <Input v-if="item.type=='text'" width="100%" v-model.trim="query[item.prop]" :readonly="!isAdd&&item.noEdit" :placeHolder="item.placeholder" />
            <Select v-else-if="item.type=='select'" width="100%" :enum="item.enum" :readonly="!isAdd&&item.noEdit" v-model="query[item.prop]"/>
            <Select v-else-if="item.type=='textarea'" width="100%" :readonly="!isAdd&&item.noEdit" v-model="query[item.prop]"/>
          </el-form-item>
        </el-col>
      </el-row>
    </el-form>
  </Modal>
</template>
<script>
/**
 * 订单查询记录
 * 
 * generated at 2021-1-13 9:37:32 AM
 */

import editPageMixin from "./../../../edit-page-mixin";
export default {
 mixins:[editPageMixin],
  data() {
    return {
      description:'订单查询记录',
      pkName:'createTime',
      apiPrefix:'',
      fields:[
	[
		{
			prop: "queryStatus",
			label: "",
			type: "select",
			enum: "queryStatus"
		},
		{
			prop: "queryBatchId",
			label: "",
			type: "select",
			enum: "queryBatchId"
		},
		{
			prop: "deliveryId",
			label: "",
			type: "select",
			enum: "deliveryId"
		}
	],
	[
		{
			prop: "orderNo",
			label: "",
			type: "text"
		},
		{
			prop: "serverIp",
			label: "",
			type: "text"
		}
	],
	[
		{
			prop: "serviceCode",
			label: "",
			type: "text"
		},
		{
			prop: "resultMsg",
			label: "",
			type: "textarea"
		}
	]
],
      rules: {
	queryStatus: [
		{
			required: true,
			message: "请选择",
			trigger: "blur"
		}
	],
	deliveryId: [
		{
			required: true,
			message: "请选择",
			trigger: "blur"
		}
	],
	orderNo: [
		{
			required: true,
			message: "请输入",
			trigger: "blur"
		}
	],
	serviceCode: [
		{
			required: true,
			message: "请输入",
			trigger: "blur"
		}
	]
},
      query:{
	queryStatus: null,
	queryBatchId: null,
	deliveryId: null,
	orderNo: null,
	serverIp: null,
	serviceCode: null,
	resultMsg: null,
	createTime: null
},
    }
  },
}
</script>