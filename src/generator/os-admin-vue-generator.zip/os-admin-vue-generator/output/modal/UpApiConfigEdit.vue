<template>
  <Modal ref="modal" @onOk="submit" :onCancel="close" width="40%" :title="title">
    <el-form ref="form" :model="query" :rules="rules" label-position="right" label-width="120px">
      <el-row :gutter="5" v-for="(items,ind) in fields" :key="ind">
        <el-col :span="12" v-for="(item, index) in items" :key="index">
          <el-form-item :label="item.label" :prop="item.prop">
            <Input v-if="item.type=='text'" width="100%" v-model.trim="query[item.prop]" :readonly="!isAdd&&item.noEdit" :placeHolder="item.placeholder" />
            <Select v-else-if="item.type=='select'" width="100%" :enum="item.enum" :readonly="!isAdd&&item.noEdit" v-model="query[item.prop]"/>
            <Select v-else-if="item.type=='textarea'" width="100%" :readonly="!isAdd&&item.noEdit" v-model="query[item.prop]"/>
          </el-form-item>
        </el-col>
      </el-row>
    </el-form>
  </Modal>
</template>
<script>
/**
 * 上游接口配置
 * 
 * generated at 2021-1-13 9:37:32 AM
 */

import editPageMixin from "./../../../edit-page-mixin";
export default {
 mixins:[editPageMixin],
  data() {
    return {
      description:'上游接口配置',
      pkName:'recordId',
      apiPrefix:'',
      fields:[
	[
		{
			prop: "channelNo",
			label: "渠道编号",
			type: "select",
			enum: "channelNo"
		},
		{
			prop: "businessType",
			label: "业务类型",
			type: "select",
			enum: "businessType"
		},
		{
			prop: "productType",
			label: "产品类型",
			type: "select",
			enum: "productType"
		}
	],
	[
		{
			prop: "apiType",
			label: "接口类型",
			type: "select",
			enum: "apiType"
		},
		{
			prop: "carrierNo",
			label: "运营商编码",
			type: "text"
		}
	],
	[
		{
			prop: "provinceNo",
			label: "省份编码",
			type: "text"
		},
		{
			prop: "cityNo",
			label: "地市编码",
			type: "text"
		}
	],
	[
		{
			prop: "serviceCode",
			label: "服务编码",
			type: "text"
		},
		{
			prop: "apiUrl",
			label: "接口地址",
			type: "text"
		}
	],
	[
		{
			prop: "status",
			label: "状态",
			type: "select",
			enum: "status"
		}
	]
],
      rules: {
	channelNo: [
		{
			required: true,
			message: "请选择渠道编号",
			trigger: "blur"
		}
	],
	businessType: [
		{
			required: true,
			message: "请选择业务类型",
			trigger: "blur"
		}
	],
	productType: [
		{
			required: true,
			message: "请选择产品类型",
			trigger: "blur"
		}
	],
	apiType: [
		{
			required: true,
			message: "请选择接口类型",
			trigger: "blur"
		}
	],
	carrierNo: [
		{
			required: true,
			message: "请输入运营商编码",
			trigger: "blur"
		}
	],
	provinceNo: [
		{
			required: true,
			message: "请输入省份编码",
			trigger: "blur"
		}
	],
	cityNo: [
		{
			required: true,
			message: "请输入地市编码",
			trigger: "blur"
		}
	],
	serviceCode: [
		{
			required: true,
			message: "请输入服务编码",
			trigger: "blur"
		}
	],
	apiUrl: [
		{
			required: true,
			message: "请输入接口地址",
			trigger: "blur"
		}
	],
	status: [
		{
			required: true,
			message: "请选择状态",
			trigger: "blur"
		}
	]
},
      query:{
	channelNo: null,
	businessType: null,
	productType: null,
	apiType: null,
	carrierNo: null,
	provinceNo: null,
	cityNo: null,
	serviceCode: null,
	apiUrl: null,
	status: null,
	recordId: null
},
    }
  },
}
</script>