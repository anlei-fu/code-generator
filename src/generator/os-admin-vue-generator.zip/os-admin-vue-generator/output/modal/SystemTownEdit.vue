<template>
  <Modal ref="modal" @onOk="submit" :onCancel="close" width="40%" :title="title">
    <el-form ref="form" :model="query" :rules="rules" label-position="right" label-width="120px">
      <el-row :gutter="5" v-for="(items,ind) in fields" :key="ind">
        <el-col :span="12" v-for="(item, index) in items" :key="index">
          <el-form-item :label="item.label" :prop="item.prop">
            <Input v-if="item.type=='text'" width="100%" v-model.trim="query[item.prop]" :readonly="!isAdd&&item.noEdit" :placeHolder="item.placeholder" />
            <Select v-else-if="item.type=='select'" width="100%" :enum="item.enum" :readonly="!isAdd&&item.noEdit" v-model="query[item.prop]"/>
            <Select v-else-if="item.type=='textarea'" width="100%" :readonly="!isAdd&&item.noEdit" v-model="query[item.prop]"/>
          </el-form-item>
        </el-col>
      </el-row>
    </el-form>
  </Modal>
</template>
<script>
/**
 * 系统乡镇街道表(乡级)
 * 
 * generated at 2021-1-13 9:37:32 AM
 */

import editPageMixin from "./../../../edit-page-mixin";
export default {
 mixins:[editPageMixin],
  data() {
    return {
      description:'系统乡镇街道表(乡级)',
      pkName:'townCode',
      apiPrefix:'',
      fields:[
	[
		{
			prop: "townNo",
			label: "乡镇街道编码",
			type: "text"
		},
		{
			prop: "townName",
			label: "乡镇街道名称",
			type: "text"
		},
		{
			prop: "areaNo",
			label: "区县编码",
			type: "text"
		}
	],
	[
		{
			prop: "cityNo",
			label: "地市编码",
			type: "text"
		},
		{
			prop: "provinceNo",
			label: "省份编码",
			type: "text"
		}
	]
],
      rules: {
	townNo: [
		{
			required: true,
			message: "请输入乡镇街道编码",
			trigger: "blur"
		}
	],
	townName: [
		{
			required: true,
			message: "请输入乡镇街道名称",
			trigger: "blur"
		}
	],
	areaNo: [
		{
			required: true,
			message: "请输入区县编码",
			trigger: "blur"
		}
	],
	cityNo: [
		{
			required: true,
			message: "请输入地市编码",
			trigger: "blur"
		}
	],
	provinceNo: [
		{
			required: true,
			message: "请输入省份编码",
			trigger: "blur"
		}
	]
},
      query:{
	townNo: null,
	townName: null,
	areaNo: null,
	cityNo: null,
	provinceNo: null,
	townCode: null
},
    }
  },
}
</script>