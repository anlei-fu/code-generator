<template>
  <Modal ref="modal" @onOk="submit" :onCancel="close" width="40%" :title="title">
    <el-form ref="form" :model="query" :rules="rules" label-position="right" label-width="120px">
      <el-row :gutter="5" v-for="(items,ind) in fields" :key="ind">
        <el-col :span="12" v-for="(item, index) in items" :key="index">
          <el-form-item :label="item.label" :prop="item.prop">
            <Input v-if="item.type=='text'" width="100%" v-model.trim="query[item.prop]" :readonly="!isAdd&&item.noEdit" :placeHolder="item.placeholder" />
            <Select v-else-if="item.type=='select'" width="100%" :enum="item.enum" :readonly="!isAdd&&item.noEdit" v-model="query[item.prop]"/>
            <Select v-else-if="item.type=='textarea'" width="100%" :readonly="!isAdd&&item.noEdit" v-model="query[item.prop]"/>
          </el-form-item>
        </el-col>
      </el-row>
    </el-form>
  </Modal>
</template>
<script>
/**
 * 操作记录详情
 * 
 * generated at 2021-1-13 9:37:32 AM
 */

import editPageMixin from "./../../../edit-page-mixin";
export default {
 mixins:[editPageMixin],
  data() {
    return {
      description:'操作记录详情',
      pkName:'detailId',
      apiPrefix:'',
      fields:[
	[
		{
			prop: "operateId",
			label: "操作记录号",
			type: "select",
			enum: "operateId"
		},
		{
			prop: "recordId",
			label: "记录编号",
			type: "text"
		}
	]
],
      rules: {
	operateId: [
		{
			required: true,
			message: "请选择操作记录号",
			trigger: "blur"
		}
	],
	recordId: [
		{
			required: true,
			message: "请输入记录编号",
			trigger: "blur"
		}
	]
},
      query:{
	operateId: null,
	recordId: null,
	detailId: null
},
    }
  },
}
</script>