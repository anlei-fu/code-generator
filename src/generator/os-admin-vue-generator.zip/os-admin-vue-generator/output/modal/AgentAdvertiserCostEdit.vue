<template>
  <Modal ref="modal" @onOk="submit" :onCancel="close" width="40%" :title="title">
    <el-form ref="form" :model="query" :rules="rules" label-position="right" label-width="120px">
      <el-row :gutter="5" v-for="(items,ind) in fields" :key="ind">
        <el-col :span="12" v-for="(item, index) in items" :key="index">
          <el-form-item :label="item.label" :prop="item.prop">
            <Input v-if="item.type=='text'" width="100%" v-model.trim="query[item.prop]" :readonly="!isAdd&&item.noEdit" :placeHolder="item.placeholder" />
            <Select v-else-if="item.type=='select'" width="100%" :enum="item.enum" :readonly="!isAdd&&item.noEdit" v-model="query[item.prop]"/>
            <Select v-else-if="item.type=='textarea'" width="100%" :readonly="!isAdd&&item.noEdit" v-model="query[item.prop]"/>
          </el-form-item>
        </el-col>
      </el-row>
    </el-form>
  </Modal>
</template>
<script>
/**
 * 代理商广告主消耗
 * 
 * generated at 2021-1-13 9:37:32 AM
 */
import { numberValidator } from "./../../../../../util/Validators";
import editPageMixin from "./../../../edit-page-mixin";
export default {
 mixins:[editPageMixin],
  data() {
    return {
      description:'代理商广告主消耗',
      pkName:'recordId',
      apiPrefix:'advertiser/advertiser-cost',
      fields:[
	[
		{
			prop: "advertiserUid",
			label: "广告主编号",
			type: "text"
		},
		{
			prop: "adGroupNo",
			label: "广告组编号",
			type: "text"
		},
		{
			prop: "adGroupName",
			label: "广告组名称",
			type: "text"
		}
	],
	[
		{
			prop: "adPlanNo",
			label: "计划编号",
			type: "text"
		},
		{
			prop: "adPlanName",
			label: "计划名称",
			type: "text"
		}
	],
	[
		{
			prop: "adCreativeNo",
			label: "创意编号",
			type: "text"
		},
		{
			prop: "totalConvert",
			label: "转化数",
			type: "text"
		}
	],
	[
		{
			prop: "totalCost",
			label: "总消耗",
			type: "text"
		},
		{
			prop: "realCost",
			label: "实际消耗",
			type: "text"
		}
	],
	[
		{
			prop: "totalShow",
			label: "展示数",
			type: "text"
		},
		{
			prop: "totalClick",
			label: "点击数",
			type: "text"
		}
	],
	[
		{
			prop: "totalPlay",
			label: "播放数",
			type: "text"
		},
		{
			prop: "validPlay",
			label: "有效播放数",
			type: "text"
		}
	],
	[
		{
			prop: "playOverRate",
			label: "完播率",
			type: "text"
		},
		{
			prop: "validPlayRate",
			label: "有效播放率",
			type: "text"
		}
	],
	[
		{
			prop: "syncStatus",
			label: "同步状态",
			type: "select",
			enum: "syncStatus"
		},
		{
			prop: "rebateRate",
			label: "返佣率",
			type: "text"
		}
	]
],
      rules: {
	advertiserUid: [
		{
			required: true,
			message: "请输入广告主编号",
			trigger: "blur"
		},
		{
			validator: numberValidator,
			message: "请输入合法数字",
			trigger: "blur"
		}
	],
	totalConvert: [
		{
			required: true,
			message: "请输入转化数",
			trigger: "blur"
		},
		{
			validator: numberValidator,
			message: "请输入合法数字",
			trigger: "blur"
		}
	],
	totalCost: [
		{
			required: true,
			message: "请输入总消耗",
			trigger: "blur"
		},
		{
			validator: numberValidator,
			message: "请输入合法数字",
			trigger: "blur"
		}
	],
	realCost: [
		{
			required: true,
			message: "请输入实际消耗",
			trigger: "blur"
		},
		{
			validator: numberValidator,
			message: "请输入合法数字",
			trigger: "blur"
		}
	],
	totalShow: [
		{
			required: true,
			message: "请输入展示数",
			trigger: "blur"
		},
		{
			validator: numberValidator,
			message: "请输入合法数字",
			trigger: "blur"
		}
	],
	totalClick: [
		{
			required: true,
			message: "请输入点击数",
			trigger: "blur"
		},
		{
			validator: numberValidator,
			message: "请输入合法数字",
			trigger: "blur"
		}
	],
	totalPlay: [
		{
			validator: numberValidator,
			message: "请输入合法数字",
			trigger: "blur"
		}
	],
	validPlay: [
		{
			validator: numberValidator,
			message: "请输入合法数字",
			trigger: "blur"
		}
	],
	playOverRate: [
		{
			validator: numberValidator,
			message: "请输入合法数字",
			trigger: "blur"
		}
	],
	validPlayRate: [
		{
			validator: numberValidator,
			message: "请输入合法数字",
			trigger: "blur"
		}
	],
	syncStatus: [
		{
			required: true,
			message: "请选择同步状态",
			trigger: "blur"
		}
	],
	rebateRate: [
		{
			required: true,
			message: "请输入返佣率",
			trigger: "blur"
		},
		{
			validator: numberValidator,
			message: "请输入合法数字",
			trigger: "blur"
		}
	]
},
      query:{
	advertiserUid: null,
	adGroupNo: null,
	adGroupName: null,
	adPlanNo: null,
	adPlanName: null,
	adCreativeNo: null,
	totalConvert: null,
	totalCost: null,
	realCost: null,
	totalShow: null,
	totalClick: null,
	totalPlay: null,
	validPlay: null,
	playOverRate: null,
	validPlayRate: null,
	syncStatus: null,
	rebateRate: null,
	recordId: null
},
    }
  },
}
</script>