<template>
  <Modal ref="modal" @onOk="submit" :onCancel="close" width="40%" :title="title">
    <el-form ref="form" :model="query" :rules="rules" label-position="right" label-width="120px">
      <el-row :gutter="5" v-for="(items,ind) in fields" :key="ind">
        <el-col :span="12" v-for="(item, index) in items" :key="index">
          <el-form-item :label="item.label" :prop="item.prop">
            <Input v-if="item.type=='text'" width="100%" v-model.trim="query[item.prop]" :readonly="!isAdd&&item.noEdit" :placeHolder="item.placeholder" />
            <Select v-else-if="item.type=='select'" width="100%" :enum="item.enum" :readonly="!isAdd&&item.noEdit" v-model="query[item.prop]"/>
            <Select v-else-if="item.type=='textarea'" width="100%" :readonly="!isAdd&&item.noEdit" v-model="query[item.prop]"/>
          </el-form-item>
        </el-col>
      </el-row>
    </el-form>
  </Modal>
</template>
<script>
/**
 * 上游产品信息
 * 
 * generated at 2021-1-13 9:37:32 AM
 */
import { numberValidator } from "./../../../../../util/Validators";
import editPageMixin from "./../../../edit-page-mixin";
export default {
 mixins:[editPageMixin],
  data() {
    return {
      description:'上游产品信息',
      pkName:'productNo',
      apiPrefix:'',
      fields:[
	[
		{
			prop: "productName",
			label: "产品名称",
			type: "text"
		},
		{
			prop: "channelNo",
			label: "渠道编码",
			type: "select",
			enum: "channelNo"
		},
		{
			prop: "upProductCode",
			label: "上游产品编码",
			type: "text"
		}
	],
	[
		{
			prop: "businessType",
			label: "业务类型",
			type: "select",
			enum: "businessType"
		},
		{
			prop: "productType",
			label: "产品类型",
			type: "select",
			enum: "productType"
		}
	],
	[
		{
			prop: "carrierNo",
			label: "运营商",
			type: "text"
		},
		{
			prop: "provinceNo",
			label: "省份",
			type: "text"
		}
	],
	[
		{
			prop: "cityNo",
			label: "地市",
			type: "text"
		},
		{
			prop: "faceFee",
			label: "面值",
			type: "text"
		}
	],
	[
		{
			prop: "normalPrice",
			label: "标准价格",
			type: "text"
		},
		{
			prop: "deductPrice",
			label: "扣款价格",
			type: "text"
		}
	],
	[
		{
			prop: "groupNo",
			label: "分组编码",
			type: "text"
		},
		{
			prop: "flowId",
			label: "流程编号",
			type: "select",
			enum: "flowId"
		}
	],
	[
		{
			prop: "status",
			label: "状态",
			type: "select",
			enum: "status"
		},
		{
			prop: "remark",
			label: "备注",
			type: "textarea"
		}
	],
	[
		{
			prop: "extend1",
			label: "扩展字段1",
			type: "text"
		},
		{
			prop: "extend2",
			label: "扩展字段2",
			type: "text"
		}
	],
	[
		{
			prop: "extend3",
			label: "扩展字段3",
			type: "text"
		}
	]
],
      rules: {
	productName: [
		{
			required: true,
			message: "请输入产品名称",
			trigger: "blur"
		}
	],
	channelNo: [
		{
			required: true,
			message: "请选择渠道编码",
			trigger: "blur"
		}
	],
	upProductCode: [
		{
			required: true,
			message: "请输入上游产品编码",
			trigger: "blur"
		}
	],
	businessType: [
		{
			required: true,
			message: "请选择业务类型",
			trigger: "blur"
		}
	],
	productType: [
		{
			required: true,
			message: "请选择产品类型",
			trigger: "blur"
		}
	],
	carrierNo: [
		{
			required: true,
			message: "请输入运营商",
			trigger: "blur"
		}
	],
	provinceNo: [
		{
			required: true,
			message: "请输入省份",
			trigger: "blur"
		}
	],
	cityNo: [
		{
			required: true,
			message: "请输入地市",
			trigger: "blur"
		}
	],
	faceFee: [
		{
			required: true,
			message: "请输入面值",
			trigger: "blur"
		},
		{
			validator: numberValidator,
			message: "请输入合法数字",
			trigger: "blur"
		}
	],
	normalPrice: [
		{
			required: true,
			message: "请输入标准价格",
			trigger: "blur"
		},
		{
			validator: numberValidator,
			message: "请输入合法数字",
			trigger: "blur"
		}
	],
	deductPrice: [
		{
			required: true,
			message: "请输入扣款价格",
			trigger: "blur"
		},
		{
			validator: numberValidator,
			message: "请输入合法数字",
			trigger: "blur"
		}
	],
	groupNo: [
		{
			required: true,
			message: "请输入分组编码",
			trigger: "blur"
		}
	],
	flowId: [
		{
			required: true,
			message: "请选择流程编号",
			trigger: "blur"
		}
	],
	status: [
		{
			required: true,
			message: "请选择状态",
			trigger: "blur"
		}
	]
},
      query:{
	productName: null,
	channelNo: null,
	upProductCode: null,
	businessType: null,
	productType: null,
	carrierNo: null,
	provinceNo: null,
	cityNo: null,
	faceFee: null,
	normalPrice: null,
	deductPrice: null,
	groupNo: null,
	flowId: null,
	status: null,
	remark: null,
	extend1: null,
	extend2: null,
	extend3: null,
	productNo: null
},
    }
  },
}
</script>