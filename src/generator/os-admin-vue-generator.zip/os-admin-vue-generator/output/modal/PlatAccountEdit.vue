<template>
  <Modal ref="modal" @onOk="submit" :onCancel="close" width="40%" :title="title">
    <el-form ref="form" :model="query" :rules="rules" label-position="right" label-width="120px">
      <el-row :gutter="5" v-for="(items,ind) in fields" :key="ind">
        <el-col :span="12" v-for="(item, index) in items" :key="index">
          <el-form-item :label="item.label" :prop="item.prop">
            <Input v-if="item.type=='text'" width="100%" v-model.trim="query[item.prop]" :readonly="!isAdd&&item.noEdit" :placeHolder="item.placeholder" />
            <Select v-else-if="item.type=='select'" width="100%" :enum="item.enum" :readonly="!isAdd&&item.noEdit" v-model="query[item.prop]"/>
            <Select v-else-if="item.type=='textarea'" width="100%" :readonly="!isAdd&&item.noEdit" v-model="query[item.prop]"/>
          </el-form-item>
        </el-col>
      </el-row>
    </el-form>
  </Modal>
</template>
<script>
/**
 * 开放平台账号
 * 
 * generated at 2021-1-13 9:37:32 AM
 */

import editPageMixin from "./../../../edit-page-mixin";
export default {
 mixins:[editPageMixin],
  data() {
    return {
      description:'开放平台账号',
      pkName:'accountId',
      apiPrefix:'plat-agent/plat-account',
      fields:[
	[
		{
			prop: "platNo",
			label: "平台编号",
			type: "select",
			enum: "platNo"
		},
		{
			prop: "loginUid",
			label: "登录账号",
			type: "text"
		},
		{
			prop: "loginPwd",
			label: "登录密码",
			type: "text"
		}
	]
],
      rules: {
	platNo: [
		{
			required: true,
			message: "请选择平台编号",
			trigger: "blur"
		}
	],
	loginUid: [
		{
			required: true,
			message: "请输入登录账号",
			trigger: "blur"
		}
	]
},
      query:{
	platNo: null,
	loginUid: null,
	loginPwd: null,
	accountId: null
},
    }
  },
}
</script>