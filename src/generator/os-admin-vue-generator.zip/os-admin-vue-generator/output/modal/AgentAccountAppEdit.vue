<template>
  <Modal ref="modal" @onOk="submit" :onCancel="close" width="40%" :title="title">
    <el-form ref="form" :model="query" :rules="rules" label-position="right" label-width="120px">
      <el-row :gutter="5" v-for="(items,ind) in fields" :key="ind">
        <el-col :span="12" v-for="(item, index) in items" :key="index">
          <el-form-item :label="item.label" :prop="item.prop">
            <Input v-if="item.type=='text'" v-model.trim="query[item.prop]" :readonly="!isAdd&&item.noEdit" :placeHolder="item.placeholder" />
            <Select v-else-if="item.type=='select'" :key="item.selectKey" :readonly="!isAdd&&item.noEdit" v-model="query[item.prop]"/>
            <Select v-else-if="item.type=='textarea'" :readonly="!isAdd&&item.noEdit" v-model="query[item.prop]"/>
          </el-form-item>
        </el-col>
      </el-row>
    </el-form>
  </Modal>
</template>
<script>
/**
 * 代理商账号应用
 * 
 * generated at 2021-1-8 9:36:49 AM
 */
import editPageMixin from "./../../../edit-page-mixin";
export default {
 mixins:[editPageMixin],
  data() {
    return {
      description:'代理商账号应用',
      pkName:'appUid',
      apiPrefix:'agent-account-app',
      fields:[
	[
		{
			prop: "accountId",
			label: "账号编号",
			type: "select",
			enum: "accountId"
		},
		{
			prop: "appId",
			label: "应用ID",
			type: "text"
		},
		{
			prop: "appName",
			label: "应用名称",
			type: "text"
		}
	],
	[
		{
			prop: "appSecret",
			label: "应用密钥",
			type: "text"
		},
		{
			prop: "callbackUrl",
			label: "回调地址",
			type: "text"
		}
	],
	[
		{
			prop: "accessToken",
			label: "访问令牌",
			type: "text"
		},
		{
			prop: "refreshToken",
			label: "刷新令牌",
			type: "text"
		}
	]
],
      rules: {
	accountId: [
		{
			required: true,
			message: "请选择账号编号",
			trigger: "blur"
		}
	],
	appId: [
		{
			required: true,
			message: "请输入应用ID",
			trigger: "blur"
		}
	],
	appName: [
		{
			required: true,
			message: "请输入应用名称",
			trigger: "blur"
		}
	],
	appSecret: [
		{
			required: true,
			message: "请输入应用密钥",
			trigger: "blur"
		}
	]
},
      query:{
	accountId: null,
	appId: null,
	appName: null,
	appSecret: null,
	callbackUrl: null,
	accessToken: null,
	refreshToken: null
},
    }
  },
}
</script>