<template>
  <Modal ref="modal" @onOk="submit" :onCancel="close" width="40%" :title="title">
    <el-form ref="form" :model="query" :rules="rules" label-position="right" label-width="120px">
      <el-row :gutter="5" v-for="(items,ind) in fields" :key="ind">
        <el-col :span="12" v-for="(item, index) in items" :key="index">
          <el-form-item :label="item.label" :prop="item.prop">
            <Input v-if="item.type=='text'" width="100%" v-model.trim="query[item.prop]" :readonly="!isAdd&&item.noEdit" :placeHolder="item.placeholder" />
            <Select v-else-if="item.type=='select'" width="100%" :enum="item.enum" :readonly="!isAdd&&item.noEdit" v-model="query[item.prop]"/>
            <Select v-else-if="item.type=='textarea'" width="100%" :readonly="!isAdd&&item.noEdit" v-model="query[item.prop]"/>
          </el-form-item>
        </el-col>
      </el-row>
    </el-form>
  </Modal>
</template>
<script>
/**
 * 订单扩展表
 * 
 * generated at 2021-1-13 9:37:32 AM
 */
import { numberValidator } from "./../../../../../util/Validators";
import editPageMixin from "./../../../edit-page-mixin";
export default {
 mixins:[editPageMixin],
  data() {
    return {
      description:'订单扩展表',
      pkName:'orderNo',
      apiPrefix:'',
      fields:[
	[
		{
			prop: "contact",
			label: "联系人姓名",
			type: "text"
		},
		{
			prop: "contactProv",
			label: "联系人省份编码",
			type: "text"
		},
		{
			prop: "contactCity",
			label: "联系人地市编码",
			type: "text"
		}
	],
	[
		{
			prop: "contactArea",
			label: "联系人区域编码",
			type: "text"
		},
		{
			prop: "contactAddr",
			label: "联系人详细地址",
			type: "text"
		}
	],
	[
		{
			prop: "idCard",
			label: "办理人身份证",
			type: "text"
		},
		{
			prop: "idCardName",
			label: "办理人姓名",
			type: "text"
		}
	],
	[
		{
			prop: "idCardPicFront",
			label: "身份证照",
			type: "text"
		},
		{
			prop: "idCardPicBack",
			label: "身份证照",
			type: "text"
		}
	],
	[
		{
			prop: "idCardPicHand",
			label: "身份证照",
			type: "text"
		},
		{
			prop: "mobile",
			label: "新手机号",
			type: "text"
		}
	],
	[
		{
			prop: "activateStatus",
			label: "激活状态",
			type: "select",
			enum: "activateStatus"
		},
		{
			prop: "rechargeStatus",
			label: "首充状态",
			type: "select",
			enum: "rechargeStatus"
		}
	],
	[
		{
			prop: "rechargeFace",
			label: "首充面值",
			type: "text"
		},
		{
			prop: "expressName",
			label: "物流名称",
			type: "text"
		}
	],
	[
		{
			prop: "expressNo",
			label: "物流单号",
			type: "text"
		},
		{
			prop: "netRange",
			label: "网络范围",
			type: "text"
		}
	]
],
      rules: {
	contact: [
		{
			required: true,
			message: "请输入联系人姓名",
			trigger: "blur"
		}
	],
	contactProv: [
		{
			required: true,
			message: "请输入联系人省份编码",
			trigger: "blur"
		}
	],
	idCard: [
		{
			required: true,
			message: "请输入办理人身份证",
			trigger: "blur"
		}
	],
	idCardName: [
		{
			required: true,
			message: "请输入办理人姓名",
			trigger: "blur"
		}
	],
	rechargeFace: [
		{
			validator: numberValidator,
			message: "请输入合法数字",
			trigger: "blur"
		}
	],
	netRange: [
		{
			validator: numberValidator,
			message: "请输入合法数字",
			trigger: "blur"
		}
	]
},
      query:{
	contact: null,
	contactProv: null,
	contactCity: null,
	contactArea: null,
	contactAddr: null,
	idCard: null,
	idCardName: null,
	idCardPicFront: null,
	idCardPicBack: null,
	idCardPicHand: null,
	mobile: null,
	activateStatus: null,
	rechargeStatus: null,
	rechargeFace: null,
	expressName: null,
	expressNo: null,
	netRange: null,
	orderNo: null
},
    }
  },
}
</script>