<template>
  <Modal ref="modal" @onOk="submit" :onCancel="close" width="40%" :title="title">
    <el-form ref="form" :model="query" :rules="rules" label-position="right" label-width="120px">
      <el-row :gutter="5" v-for="(items,ind) in fields" :key="ind">
        <el-col :span="12" v-for="(item, index) in items" :key="index">
          <el-form-item :label="item.label" :prop="item.prop">
            <Input v-if="item.type=='text'" width="100%" v-model.trim="query[item.prop]" :readonly="!isAdd&&item.noEdit" :placeHolder="item.placeholder" />
            <Select v-else-if="item.type=='select'" width="100%" :enum="item.enum" :readonly="!isAdd&&item.noEdit" v-model="query[item.prop]"/>
            <Select v-else-if="item.type=='textarea'" width="100%" :readonly="!isAdd&&item.noEdit" v-model="query[item.prop]"/>
          </el-form-item>
        </el-col>
      </el-row>
    </el-form>
  </Modal>
</template>
<script>
/**
 * 上游错误码对照
 * 
 * generated at 2021-1-13 9:37:32 AM
 */
import { numberValidator } from "./../../../../../util/Validators";
import editPageMixin from "./../../../edit-page-mixin";
export default {
 mixins:[editPageMixin],
  data() {
    return {
      description:'上游错误码对照',
      pkName:'recordId',
      apiPrefix:'',
      fields:[
	[
		{
			prop: "channelNo",
			label: "渠道编号",
			type: "select",
			enum: "channelNo"
		},
		{
			prop: "codeType",
			label: "错误码类型",
			type: "select",
			enum: "codeType"
		},
		{
			prop: "keyWord1",
			label: "关键字1",
			type: "text"
		}
	],
	[
		{
			prop: "keyWord2",
			label: "关键字2",
			type: "text"
		},
		{
			prop: "dealStatus",
			label: "处理状态",
			type: "select",
			enum: "dealStatus"
		}
	],
	[
		{
			prop: "dealMsg",
			label: "处理消息",
			type: "textarea"
		},
		{
			prop: "needWarn",
			label: "是否告警",
			type: "text"
		}
	],
	[
		{
			prop: "retryMax",
			label: "重试最大次数",
			type: "text"
		},
		{
			prop: "retryIntrv",
			label: "重试间隔（秒）",
			type: "text"
		}
	],
	[
		{
			prop: "delayTime",
			label: "延迟时间（分钟）",
			type: "text"
		},
		{
			prop: "status",
			label: "状态",
			type: "select",
			enum: "status"
		}
	]
],
      rules: {
	channelNo: [
		{
			required: true,
			message: "请选择渠道编号",
			trigger: "blur"
		}
	],
	codeType: [
		{
			required: true,
			message: "请选择错误码类型",
			trigger: "blur"
		}
	],
	keyWord1: [
		{
			required: true,
			message: "请输入关键字1",
			trigger: "blur"
		}
	],
	keyWord2: [
		{
			required: true,
			message: "请输入关键字2",
			trigger: "blur"
		}
	],
	dealStatus: [
		{
			required: true,
			message: "请选择处理状态",
			trigger: "blur"
		}
	],
	needWarn: [
		{
			required: true,
			message: "请输入是否告警",
			trigger: "blur"
		},
		{
			validator: numberValidator,
			message: "请输入合法数字",
			trigger: "blur"
		}
	],
	retryMax: [
		{
			validator: numberValidator,
			message: "请输入合法数字",
			trigger: "blur"
		}
	],
	retryIntrv: [
		{
			validator: numberValidator,
			message: "请输入合法数字",
			trigger: "blur"
		}
	],
	delayTime: [
		{
			validator: numberValidator,
			message: "请输入合法数字",
			trigger: "blur"
		}
	]
},
      query:{
	channelNo: null,
	codeType: null,
	keyWord1: null,
	keyWord2: null,
	dealStatus: null,
	dealMsg: null,
	needWarn: null,
	retryMax: null,
	retryIntrv: null,
	delayTime: null,
	status: null,
	recordId: null
},
    }
  },
}
</script>