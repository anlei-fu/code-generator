<template>
  <Modal ref="modal" @onOk="submit" :onCancel="close" width="40%" :title="title">
    <el-form ref="form" :model="query" :rules="rules" label-position="right" label-width="120px">
      <el-row :gutter="5" v-for="(items,ind) in fields" :key="ind">
        <el-col :span="12" v-for="(item, index) in items" :key="index">
          <el-form-item :label="item.label" :prop="item.prop">
            <Input v-if="item.type=='text'" width="100%" v-model.trim="query[item.prop]" :readonly="!isAdd&&item.noEdit" :placeHolder="item.placeholder" />
            <Select v-else-if="item.type=='select'" width="100%" :enum="item.enum" :readonly="!isAdd&&item.noEdit" v-model="query[item.prop]"/>
            <Select v-else-if="item.type=='textarea'" width="100%" :readonly="!isAdd&&item.noEdit" v-model="query[item.prop]"/>
          </el-form-item>
        </el-col>
      </el-row>
    </el-form>
  </Modal>
</template>
<script>
/**
 * 流程步骤
 * 
 * generated at 2021-1-13 9:37:32 AM
 */
import { numberValidator } from "./../../../../../util/Validators";
import editPageMixin from "./../../../edit-page-mixin";
export default {
 mixins:[editPageMixin],
  data() {
    return {
      description:'流程步骤',
      pkName:'stepId',
      apiPrefix:'',
      fields:[
	[
		{
			prop: "flowId",
			label: "流程编号",
			type: "select",
			enum: "flowId"
		},
		{
			prop: "stepName",
			label: "步骤名称",
			type: "text"
		},
		{
			prop: "stepIndex",
			label: "步骤索引",
			type: "text"
		}
	],
	[
		{
			prop: "stepType",
			label: "步骤类型",
			type: "select",
			enum: "stepType"
		},
		{
			prop: "stepMode",
			label: "步骤模式",
			type: "select",
			enum: "stepMode"
		}
	],
	[
		{
			prop: "serviceCode",
			label: "服务编码",
			type: "text"
		},
		{
			prop: "nextStep",
			label: "下一步骤",
			type: "text"
		}
	],
	[
		{
			prop: "nextType",
			label: "下一步骤类型",
			type: "select",
			enum: "nextType"
		},
		{
			prop: "cndArgs",
			label: "条件参数",
			type: "text"
		}
	],
	[
		{
			prop: "retryMaxTimes",
			label: "重试最大次数",
			type: "text"
		}
	]
],
      rules: {
	flowId: [
		{
			required: true,
			message: "请选择流程编号",
			trigger: "blur"
		}
	],
	stepName: [
		{
			required: true,
			message: "请输入步骤名称",
			trigger: "blur"
		}
	],
	stepIndex: [
		{
			required: true,
			message: "请输入步骤索引",
			trigger: "blur"
		},
		{
			validator: numberValidator,
			message: "请输入合法数字",
			trigger: "blur"
		}
	],
	stepType: [
		{
			required: true,
			message: "请选择步骤类型",
			trigger: "blur"
		}
	],
	stepMode: [
		{
			required: true,
			message: "请选择步骤模式",
			trigger: "blur"
		}
	],
	serviceCode: [
		{
			required: true,
			message: "请输入服务编码",
			trigger: "blur"
		}
	],
	nextStep: [
		{
			validator: numberValidator,
			message: "请输入合法数字",
			trigger: "blur"
		}
	],
	retryMaxTimes: [
		{
			validator: numberValidator,
			message: "请输入合法数字",
			trigger: "blur"
		}
	]
},
      query:{
	flowId: null,
	stepName: null,
	stepIndex: null,
	stepType: null,
	stepMode: null,
	serviceCode: null,
	nextStep: null,
	nextType: null,
	cndArgs: null,
	retryMaxTimes: null,
	stepId: null
},
    }
  },
}
</script>