<template>
  <Modal ref="modal" @onOk="submit" :onCancel="close" width="40%" :title="title">
    <el-form ref="form" :model="query" :rules="rules" label-position="right" label-width="120px">
      <el-row :gutter="5" v-for="(items,ind) in fields" :key="ind">
        <el-col :span="12" v-for="(item, index) in items" :key="index">
          <el-form-item :label="item.label" :prop="item.prop">
            <Input v-if="item.type=='text'" width="100%" v-model.trim="query[item.prop]" :readonly="!isAdd&&item.noEdit" :placeHolder="item.placeholder" />
            <Select v-else-if="item.type=='select'" width="100%" :enum="item.enum" :readonly="!isAdd&&item.noEdit" v-model="query[item.prop]"/>
            <Select v-else-if="item.type=='textarea'" width="100%" :readonly="!isAdd&&item.noEdit" v-model="query[item.prop]"/>
          </el-form-item>
        </el-col>
      </el-row>
    </el-form>
  </Modal>
</template>
<script>
/**
 * 订单流程步骤
 * 
 * generated at 2021-1-13 9:37:32 AM
 */

import editPageMixin from "./../../../edit-page-mixin";
export default {
 mixins:[editPageMixin],
  data() {
    return {
      description:'订单流程步骤',
      pkName:'recordId',
      apiPrefix:'',
      fields:[
	[
		{
			prop: "orderNo",
			label: "订单号",
			type: "text"
		},
		{
			prop: "flowId",
			label: "流程编号",
			type: "select",
			enum: "flowId"
		},
		{
			prop: "stepId",
			label: "步骤编号",
			type: "select",
			enum: "stepId"
		}
	],
	[
		{
			prop: "lastFlowId",
			label: "上一流程",
			type: "select",
			enum: "lastFlowId"
		},
		{
			prop: "lastStepId",
			label: "上一步骤",
			type: "select",
			enum: "lastStepId"
		}
	],
	[
		{
			prop: "upChannelNo",
			label: "上游渠道",
			type: "select",
			enum: "upChannelNo"
		},
		{
			prop: "upProductNo",
			label: "上游产品",
			type: "select",
			enum: "upProductNo"
		}
	],
	[
		{
			prop: "stepStatus",
			label: "步骤状态",
			type: "select",
			enum: "stepStatus"
		},
		{
			prop: "manualStatus",
			label: "人工状态",
			type: "select",
			enum: "manualStatus"
		}
	]
],
      rules: {
	orderNo: [
		{
			required: true,
			message: "请输入订单号",
			trigger: "blur"
		}
	],
	stepId: [
		{
			required: true,
			message: "请选择步骤编号",
			trigger: "blur"
		}
	]
},
      query:{
	orderNo: null,
	flowId: null,
	stepId: null,
	lastFlowId: null,
	lastStepId: null,
	upChannelNo: null,
	upProductNo: null,
	stepStatus: null,
	manualStatus: null,
	recordId: null
},
    }
  },
}
</script>