<template>
  <Modal ref="modal" @onOk="submit" :onCancel="close" width="40%" :title="title">
    <el-form ref="form" :model="query" :rules="rules" label-position="right" label-width="120px">
      <el-row :gutter="5" v-for="(items,ind) in fields" :key="ind">
        <el-col :span="12" v-for="(item, index) in items" :key="index">
          <el-form-item :label="item.label" :prop="item.prop">
            <Input v-if="item.type=='text'" width="100%" v-model.trim="query[item.prop]" :readonly="!isAdd&&item.noEdit" :placeHolder="item.placeholder" />
            <Select v-else-if="item.type=='select'" width="100%" :enum="item.enum" :readonly="!isAdd&&item.noEdit" v-model="query[item.prop]"/>
            <Select v-else-if="item.type=='textarea'" width="100%" :readonly="!isAdd&&item.noEdit" v-model="query[item.prop]"/>
          </el-form-item>
        </el-col>
      </el-row>
    </el-form>
  </Modal>
</template>
<script>
/**
 * 订单通知记录
 * 
 * generated at 2021-1-13 9:37:32 AM
 */
import { numberValidator } from "./../../../../../util/Validators";
import editPageMixin from "./../../../edit-page-mixin";
export default {
 mixins:[editPageMixin],
  data() {
    return {
      description:'订单通知记录',
      pkName:'recordId',
      apiPrefix:'',
      fields:[
	[
		{
			prop: "orderNo",
			label: "订单号",
			type: "text"
		},
		{
			prop: "notifyType",
			label: "通知类型",
			type: "select",
			enum: "notifyType"
		},
		{
			prop: "notifyStatus",
			label: "通知状态",
			type: "select",
			enum: "notifyStatus"
		}
	],
	[
		{
			prop: "resultMsg",
			label: "通知结果",
			type: "textarea"
		},
		{
			prop: "serviceCode",
			label: "服务编码",
			type: "text"
		}
	],
	[
		{
			prop: "notifyUrl",
			label: "通知地址",
			type: "text"
		},
		{
			prop: "serverIp",
			label: "服务器IP",
			type: "text"
		}
	],
	[
		{
			prop: "notifyTimes",
			label: "通知次数",
			type: "text"
		},
		{
			prop: "notifyMaxTimes",
			label: "通知最大次数",
			type: "text"
		}
	],
	[
		{
			prop: "notifyBatchId",
			label: "通知批次号",
			type: "select",
			enum: "notifyBatchId"
		}
	]
],
      rules: {
	orderNo: [
		{
			required: true,
			message: "请输入订单号",
			trigger: "blur"
		}
	],
	notifyType: [
		{
			required: true,
			message: "请选择通知类型",
			trigger: "blur"
		}
	],
	notifyStatus: [
		{
			required: true,
			message: "请选择通知状态",
			trigger: "blur"
		}
	],
	notifyTimes: [
		{
			validator: numberValidator,
			message: "请输入合法数字",
			trigger: "blur"
		}
	],
	notifyMaxTimes: [
		{
			validator: numberValidator,
			message: "请输入合法数字",
			trigger: "blur"
		}
	]
},
      query:{
	orderNo: null,
	notifyType: null,
	notifyStatus: null,
	resultMsg: null,
	serviceCode: null,
	notifyUrl: null,
	serverIp: null,
	notifyTimes: null,
	notifyMaxTimes: null,
	notifyBatchId: null,
	recordId: null
},
    }
  },
}
</script>