<template>
  <Modal ref="modal" @onOk="submit" :onCancel="close" width="40%" :title="title">
    <el-form ref="form" :model="query" :rules="rules" label-position="right" label-width="120px">
      <el-row :gutter="5" v-for="(items,ind) in fields" :key="ind">
        <el-col :span="12" v-for="(item, index) in items" :key="index">
          <el-form-item :label="item.label" :prop="item.prop">
            <Input v-if="item.type=='text'" width="100%" v-model.trim="query[item.prop]" :readonly="!isAdd&&item.noEdit" :placeHolder="item.placeholder" />
            <Select v-else-if="item.type=='select'" width="100%" :enum="item.enum" :readonly="!isAdd&&item.noEdit" v-model="query[item.prop]"/>
            <Select v-else-if="item.type=='textarea'" width="100%" :readonly="!isAdd&&item.noEdit" v-model="query[item.prop]"/>
          </el-form-item>
        </el-col>
      </el-row>
    </el-form>
  </Modal>
</template>
<script>
/**
 * 代理商登录账号信息
 * 
 * generated at 2021-1-13 9:37:32 AM
 */

import editPageMixin from "./../../../edit-page-mixin";
export default {
 mixins:[editPageMixin],
  data() {
    return {
      description:'代理商登录账号信息',
      pkName:'accountId',
      apiPrefix:'plat-agent/agent-account',
      fields:[
	[
		{
			prop: "platNo",
			label: "平台编号",
			type: "select",
			enum: "platNo"
		},
		{
			prop: "agentNo",
			label: "代理商编号",
			type: "select",
			enum: "agentNo"
		},
		{
			prop: "loginUid",
			label: "登录账号",
			type: "text"
		}
	],
	[
		{
			prop: "loginPwd",
			label: "登录密码",
			type: "text"
		},
		{
			prop: "operateMode",
			label: "运营模式",
			type: "select",
			enum: "operateMode"
		}
	],
	[
		{
			prop: "principal",
			label: "负责人",
			type: "text"
		},
		{
			prop: "status",
			label: "状态",
			type: "select",
			enum: "status"
		}
	],
	[
		{
			prop: "remark",
			label: "备注",
			type: "textarea"
		}
	]
],
      rules: {
	platNo: [
		{
			required: true,
			message: "请选择平台编号",
			trigger: "blur"
		}
	],
	agentNo: [
		{
			required: true,
			message: "请选择代理商编号",
			trigger: "blur"
		}
	],
	loginUid: [
		{
			required: true,
			message: "请输入登录账号",
			trigger: "blur"
		}
	],
	operateMode: [
		{
			required: true,
			message: "请选择运营模式",
			trigger: "blur"
		}
	],
	status: [
		{
			required: true,
			message: "请选择状态",
			trigger: "blur"
		}
	]
},
      query:{
	platNo: null,
	agentNo: null,
	loginUid: null,
	loginPwd: null,
	operateMode: null,
	principal: null,
	status: null,
	remark: null,
	accountId: null
},
    }
  },
}
</script>