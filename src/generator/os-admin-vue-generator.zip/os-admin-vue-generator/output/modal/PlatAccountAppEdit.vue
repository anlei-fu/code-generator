<template>
  <Modal ref="modal" @onOk="submit" :onCancel="close" width="40%" :title="title">
    <el-form ref="form" :model="query" :rules="rules" label-position="right" label-width="120px">
      <el-row :gutter="5" v-for="(items,ind) in fields" :key="ind">
        <el-col :span="12" v-for="(item, index) in items" :key="index">
          <el-form-item :label="item.label" :prop="item.prop">
            <Input v-if="item.type=='text'" width="100%" v-model.trim="query[item.prop]" :readonly="!isAdd&&item.noEdit" :placeHolder="item.placeholder" />
            <Select v-else-if="item.type=='select'" width="100%" :enum="item.enum" :readonly="!isAdd&&item.noEdit" v-model="query[item.prop]"/>
            <Select v-else-if="item.type=='textarea'" width="100%" :readonly="!isAdd&&item.noEdit" v-model="query[item.prop]"/>
          </el-form-item>
        </el-col>
      </el-row>
    </el-form>
  </Modal>
</template>
<script>
/**
 * 开放平台应用
 * 
 * generated at 2021-1-13 9:37:32 AM
 */
import { numberValidator } from "./../../../../../util/Validators";
import editPageMixin from "./../../../edit-page-mixin";
export default {
 mixins:[editPageMixin],
  data() {
    return {
      description:'开放平台应用',
      pkName:'appUid',
      apiPrefix:'plat-agent/plat-account-app',
      fields:[
	[
		{
			prop: "accountId",
			label: "开放平台账号",
			type: "text"
		},
		{
			prop: "authUrl",
			label: "授权地址",
			type: "text"
		},
		{
			prop: "appId",
			label: "应用ID",
			type: "text"
		}
	],
	[
		{
			prop: "appName",
			label: "应用名称",
			type: "text"
		},
		{
			prop: "appSecret",
			label: "应用密钥",
			type: "text"
		}
	],
	[
		{
			prop: "callbackUrl",
			label: "回调地址",
			type: "text"
		}
	]
],
      rules: {
	accountId: [
		{
			required: true,
			message: "请输入开放平台账号",
			trigger: "blur"
		},
		{
			validator: numberValidator,
			message: "请输入合法数字",
			trigger: "blur"
		}
	],
	appId: [
		{
			required: true,
			message: "请输入应用ID",
			trigger: "blur"
		}
	],
	appName: [
		{
			required: true,
			message: "请输入应用名称",
			trigger: "blur"
		}
	],
	appSecret: [
		{
			required: true,
			message: "请输入应用密钥",
			trigger: "blur"
		}
	]
},
      query:{
	accountId: null,
	authUrl: null,
	appId: null,
	appName: null,
	appSecret: null,
	callbackUrl: null,
	appUid: null
},
    }
  },
}
</script>