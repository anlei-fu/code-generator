<template>
  <Modal ref="modal" @onOk="submit" :onCancel="close" width="40%" :title="title">
    <el-form ref="form" :model="query" :rules="rules" label-position="right" label-width="120px">
      <el-row :gutter="5" v-for="(items,ind) in fields" :key="ind">
        <el-col :span="12" v-for="(item, index) in items" :key="index">
          <el-form-item :label="item.label" :prop="item.prop">
            <Input v-if="item.type=='text'" width="100%" v-model.trim="query[item.prop]" :readonly="!isAdd&&item.noEdit" :placeHolder="item.placeholder" />
            <Select v-else-if="item.type=='select'" width="100%" :enum="item.enum" :readonly="!isAdd&&item.noEdit" v-model="query[item.prop]"/>
            <Select v-else-if="item.type=='textarea'" width="100%" :readonly="!isAdd&&item.noEdit" v-model="query[item.prop]"/>
          </el-form-item>
        </el-col>
      </el-row>
    </el-form>
  </Modal>
</template>
<script>
/**
 * 订单退款记录表
 * 
 * generated at 2021-1-13 9:37:32 AM
 */
import { numberValidator } from "./../../../../../util/Validators";
import editPageMixin from "./../../../edit-page-mixin";
export default {
 mixins:[editPageMixin],
  data() {
    return {
      description:'订单退款记录表',
      pkName:'recordId',
      apiPrefix:'pay/refund',
      fields:[
	[
		{
			prop: "orderNo",
			label: "订单号",
			type: "text"
		},
		{
			prop: "refundFee",
			label: "退款金额",
			type: "text"
		},
		{
			prop: "refundReason",
			label: "退款原因",
			type: "text"
		}
	],
	[
		{
			prop: "serviceFee",
			label: "手续费",
			type: "text"
		},
		{
			prop: "serviceName",
			label: "服务名称",
			type: "text"
		}
	],
	[
		{
			prop: "refundStatus",
			label: "退款状态",
			type: "select",
			enum: "refundStatus"
		},
		{
			prop: "resultMsg",
			label: "退款结果",
			type: "textarea"
		}
	],
	[
		{
			prop: "serverIp",
			label: "服务器IP",
			type: "text"
		}
	]
],
      rules: {
	orderNo: [
		{
			required: true,
			message: "请输入订单号",
			trigger: "blur"
		}
	],
	refundFee: [
		{
			required: true,
			message: "请输入退款金额",
			trigger: "blur"
		},
		{
			validator: numberValidator,
			message: "请输入合法数字",
			trigger: "blur"
		}
	],
	refundReason: [
		{
			required: true,
			message: "请输入退款原因",
			trigger: "blur"
		}
	],
	serviceFee: [
		{
			required: true,
			message: "请输入手续费",
			trigger: "blur"
		},
		{
			validator: numberValidator,
			message: "请输入合法数字",
			trigger: "blur"
		}
	],
	serviceName: [
		{
			required: true,
			message: "请输入服务名称",
			trigger: "blur"
		}
	],
	refundStatus: [
		{
			required: true,
			message: "请选择退款状态",
			trigger: "blur"
		}
	]
},
      query:{
	orderNo: null,
	refundFee: null,
	refundReason: null,
	serviceFee: null,
	serviceName: null,
	refundStatus: null,
	resultMsg: null,
	serverIp: null,
	recordId: null
},
    }
  },
}
</script>