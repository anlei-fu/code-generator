<template>
  <Modal ref="modal" @onOk="submit" :onCancel="close" width="40%" :title="title">
    <el-form ref="form" :model="query" :rules="rules" label-position="right" label-width="120px">
      <el-row :gutter="5" v-for="(items,ind) in fields" :key="ind">
        <el-col :span="12" v-for="(item, index) in items" :key="index">
          <el-form-item :label="item.label" :prop="item.prop">
            <Input v-if="item.type=='text'" width="100%" v-model.trim="query[item.prop]" :readonly="!isAdd&&item.noEdit" :placeHolder="item.placeholder" />
            <Select v-else-if="item.type=='select'" width="100%" :enum="item.enum" :readonly="!isAdd&&item.noEdit" v-model="query[item.prop]"/>
            <Select v-else-if="item.type=='textarea'" width="100%" :readonly="!isAdd&&item.noEdit" v-model="query[item.prop]"/>
          </el-form-item>
        </el-col>
      </el-row>
    </el-form>
  </Modal>
</template>
<script>
/**
 * 定时任务表
 * 
 * generated at 2021-1-13 9:37:32 AM
 */
import { numberValidator } from "./../../../../../util/Validators";
import editPageMixin from "./../../../edit-page-mixin";
export default {
 mixins:[editPageMixin],
  data() {
    return {
      description:'定时任务表',
      pkName:'taskId',
      apiPrefix:'',
      fields:[
	[
		{
			prop: "taskName",
			label: "任务名称",
			type: "text"
		},
		{
			prop: "taskRoute",
			label: "任务路由",
			type: "text"
		},
		{
			prop: "taskArgs",
			label: "任务参数",
			type: "text"
		}
	],
	[
		{
			prop: "taskStatus",
			label: "任务状态",
			type: "select",
			enum: "taskStatus"
		},
		{
			prop: "retryTimes",
			label: "重试次数",
			type: "text"
		}
	],
	[
		{
			prop: "retryInterval",
			label: "重试间隔",
			type: "text"
		},
		{
			prop: "retryMax",
			label: "最大重试次数",
			type: "text"
		}
	],
	[
		{
			prop: "execCost",
			label: "执行耗时",
			type: "text"
		},
		{
			prop: "serverIp",
			label: "执行服务器IP",
			type: "text"
		}
	],
	[
		{
			prop: "resultMsg",
			label: "执行结果消息",
			type: "textarea"
		},
		{
			prop: "priority",
			label: "执行优先级",
			type: "text"
		}
	]
],
      rules: {
	taskName: [
		{
			required: true,
			message: "请输入任务名称",
			trigger: "blur"
		}
	],
	taskRoute: [
		{
			required: true,
			message: "请输入任务路由",
			trigger: "blur"
		}
	],
	taskArgs: [
		{
			required: true,
			message: "请输入任务参数",
			trigger: "blur"
		}
	],
	taskStatus: [
		{
			required: true,
			message: "请选择任务状态",
			trigger: "blur"
		}
	],
	retryTimes: [
		{
			validator: numberValidator,
			message: "请输入合法数字",
			trigger: "blur"
		}
	],
	retryInterval: [
		{
			required: true,
			message: "请输入重试间隔",
			trigger: "blur"
		},
		{
			validator: numberValidator,
			message: "请输入合法数字",
			trigger: "blur"
		}
	],
	retryMax: [
		{
			required: true,
			message: "请输入最大重试次数",
			trigger: "blur"
		},
		{
			validator: numberValidator,
			message: "请输入合法数字",
			trigger: "blur"
		}
	],
	execCost: [
		{
			validator: numberValidator,
			message: "请输入合法数字",
			trigger: "blur"
		}
	],
	priority: [
		{
			required: true,
			message: "请输入执行优先级",
			trigger: "blur"
		},
		{
			validator: numberValidator,
			message: "请输入合法数字",
			trigger: "blur"
		}
	]
},
      query:{
	taskName: null,
	taskRoute: null,
	taskArgs: null,
	taskStatus: null,
	retryTimes: null,
	retryInterval: null,
	retryMax: null,
	execCost: null,
	serverIp: null,
	resultMsg: null,
	priority: null,
	taskId: null
},
    }
  },
}
</script>