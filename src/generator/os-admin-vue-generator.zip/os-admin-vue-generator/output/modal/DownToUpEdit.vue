<template>
  <Modal ref="modal" @onOk="submit" :onCancel="close" width="40%" :title="title">
    <el-form ref="form" :model="query" :rules="rules" label-position="right" label-width="120px">
      <el-row :gutter="5" v-for="(items,ind) in fields" :key="ind">
        <el-col :span="12" v-for="(item, index) in items" :key="index">
          <el-form-item :label="item.label" :prop="item.prop">
            <Input v-if="item.type=='text'" width="100%" v-model.trim="query[item.prop]" :readonly="!isAdd&&item.noEdit" :placeHolder="item.placeholder" />
            <Select v-else-if="item.type=='select'" width="100%" :enum="item.enum" :readonly="!isAdd&&item.noEdit" v-model="query[item.prop]"/>
            <Select v-else-if="item.type=='textarea'" width="100%" :readonly="!isAdd&&item.noEdit" v-model="query[item.prop]"/>
          </el-form-item>
        </el-col>
      </el-row>
    </el-form>
  </Modal>
</template>
<script>
/**
 * 下游指定上游
 * 
 * generated at 2021-1-13 9:37:32 AM
 */
import { numberValidator } from "./../../../../../util/Validators";
import editPageMixin from "./../../../edit-page-mixin";
export default {
 mixins:[editPageMixin],
  data() {
    return {
      description:'下游指定上游',
      pkName:'recordId',
      apiPrefix:'',
      fields:[
	[
		{
			prop: "downChannelNo",
			label: "下游渠道编号",
			type: "select",
			enum: "downChannelNo"
		},
		{
			prop: "downGroupNo",
			label: "下游分组编号",
			type: "text"
		},
		{
			prop: "upChannelNo",
			label: "上游渠道编号",
			type: "select",
			enum: "upChannelNo"
		}
	],
	[
		{
			prop: "upGroupNo",
			label: "上游分组编号",
			type: "text"
		},
		{
			prop: "devisionMode",
			label: "分流模式",
			type: "select",
			enum: "devisionMode"
		}
	],
	[
		{
			prop: "devisionValue",
			label: "分流值",
			type: "text"
		},
		{
			prop: "status",
			label: "状态",
			type: "select",
			enum: "status"
		}
	],
	[
		{
			prop: "remark",
			label: "备注",
			type: "textarea"
		}
	]
],
      rules: {
	downChannelNo: [
		{
			required: true,
			message: "请选择下游渠道编号",
			trigger: "blur"
		}
	],
	downGroupNo: [
		{
			required: true,
			message: "请输入下游分组编号",
			trigger: "blur"
		}
	],
	upChannelNo: [
		{
			required: true,
			message: "请选择上游渠道编号",
			trigger: "blur"
		}
	],
	upGroupNo: [
		{
			required: true,
			message: "请输入上游分组编号",
			trigger: "blur"
		}
	],
	devisionMode: [
		{
			required: true,
			message: "请选择分流模式",
			trigger: "blur"
		}
	],
	devisionValue: [
		{
			validator: numberValidator,
			message: "请输入合法数字",
			trigger: "blur"
		}
	]
},
      query:{
	downChannelNo: null,
	downGroupNo: null,
	upChannelNo: null,
	upGroupNo: null,
	devisionMode: null,
	devisionValue: null,
	status: null,
	remark: null,
	recordId: null
},
    }
  },
}
</script>