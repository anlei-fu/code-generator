<template>
  <div>
    <Filters>
      <span v-for="(value,key,i) in selects" :key="i">
        <Select :title="value.title" :enum="value.enum" v-model="query[key]" :width="value.width"/>
      </span>
      <span>
        <RadioGroup v-model="radioKey" :options="radioOptions"/>
        <Input v-model.trim="radioValue" />
      </span>
      <QueryButton @click="queryData(true)"/>
      <CreateButton @click="showAdd"/>
    </Filters>
    <Table :data="model.list">
      <el-table-column v-for="item in model.columns" header-align="center" align="center" :key="item.field" :min-width="item.minWidth" :prop="item.field" :label="item.title" :sortable="item.isSort">
        <template slot-scope="scope">
          <PlainText :value="scope.row[item.field]" :filterType="item.filter" :format="item.format" :color="$ColorPicker(item, scope.row[item.field])" />
        </template>
      </el-table-column>
      <el-table-column header-align="center" align="center" label="操作">
        <template slot-scope="scope">
          <el-button type="text" size="small" @click="showEdit(scope.row)">编辑</el-button>
          <el-button type="text" size="small" @click="showDelete(scope.row)">删除</el-button>
        </template>
      </el-table-column>
    </Table>
    <Pager :total="model.total" :current="query.pageNum" @pi-change="onPageIndexChanged" @ps-change="onPageSizeChanged" />
    <Edit ref="edit" @updated="afterUpdated"/>
  </div>
</template>
<script>
/**
 * 订单退款记录表
 * 
 * generated at 2021-1-13 9:37:37 AM
 */
import listPageMixin from "./../../list-page-mixin";
import Edit from './modal/OrderRefundEdit'
export default {
  components: {
    Edit
  },
  mixins:[listPageMixin],
  data() {
    return {
      radioValue: "",
      radioKey: "orderNo",
      radioOptions: [
	{
		value: "orderNo",
		name: "订单号"
	},
	{
		value: "serviceName",
		name: "服务名称"
	}
],
      apiPrefix:"pay/refund",
      pkName:"recordId",
      title:"订单退款记录表",
      selects:{
	refundStatus: {
		title: "退款状态",
		enum: "refundStatus"
	}
},
      model: {
      columns:[
	{
		title: "记录编号",
		field: "recordId"
	},
	{
		title: "订单号",
		field: "orderNo"
	},
	{
		title: "退款金额",
		field: "refundFee"
	},
	{
		title: "退款原因",
		field: "refundReason"
	},
	{
		title: "手续费",
		field: "serviceFee"
	},
	{
		title: "服务名称",
		field: "serviceName"
	},
	{
		title: "退款状态",
		field: "refundStatus",
		format: {
			type: "enum",
			pattern: "refundStatus"
		}
	},
	{
		title: "退款结果",
		field: "resultMsg"
	},
	{
		title: "服务器IP",
		field: "serverIp"
	},
	{
		title: "创建时间",
		field: "createTime",
		format: {
			type: "date"
		}
	},
	{
		title: "完成时间",
		field: "finishTime",
		format: {
			type: "date"
		}
	}
]
      },
      query:{
	orderNo: null,
	serviceName: null,
	refundStatus: null
}
    }
  }
}
</script>