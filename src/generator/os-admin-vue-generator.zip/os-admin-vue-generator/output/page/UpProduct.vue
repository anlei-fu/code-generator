<template>
  <div>
    <Filters>
      <span v-for="(value,key,i) in selects" :key="i">
        <Select :title="value.title" :enum="value.enum" v-model="query[key]" :width="value.width"/>
      </span>
      <span>
        <RadioGroup v-model="radioKey" :options="radioOptions"/>
        <Input v-model.trim="radioValue" />
      </span>
      <QueryButton @click="queryData(true)"/>
      <CreateButton @click="showAdd"/>
    </Filters>
    <Table :data="model.list">
      <el-table-column v-for="item in model.columns" header-align="center" align="center" :key="item.field" :min-width="item.minWidth" :prop="item.field" :label="item.title" :sortable="item.isSort">
        <template slot-scope="scope">
          <PlainText :value="scope.row[item.field]" :filterType="item.filter" :format="item.format" :color="$ColorPicker(item, scope.row[item.field])" />
        </template>
      </el-table-column>
      <el-table-column header-align="center" align="center" label="操作">
        <template slot-scope="scope">
          <el-button type="text" size="small" @click="showEdit(scope.row)">编辑</el-button>
          <el-button type="text" size="small" @click="showDelete(scope.row)">删除</el-button>
        </template>
      </el-table-column>
    </Table>
    <Pager :total="model.total" :current="query.pageNum" @pi-change="onPageIndexChanged" @ps-change="onPageSizeChanged" />
    <Edit ref="edit" @updated="afterUpdated"/>
  </div>
</template>
<script>
/**
 * 上游产品信息
 * 
 * generated at 2021-1-13 9:37:37 AM
 */
import listPageMixin from "./../../list-page-mixin";
import Edit from './modal/UpProductEdit'
export default {
  components: {
    Edit
  },
  mixins:[listPageMixin],
  data() {
    return {
      radioValue: "",
      radioKey: "productName",
      radioOptions: [
	{
		value: "productName",
		name: "产品名称"
	},
	{
		value: "upProductCode",
		name: "上游产品编码"
	},
	{
		value: "carrierNo",
		name: "运营商"
	},
	{
		value: "provinceNo",
		name: "省份"
	},
	{
		value: "cityNo",
		name: "地市"
	},
	{
		value: "groupNo",
		name: "分组编码"
	}
],
      apiPrefix:"",
      pkName:"productNo",
      title:"上游产品信息",
      selects:{
	channelNo: {
		title: "渠道编码",
		enum: "channelNo"
	},
	businessType: {
		title: "业务类型",
		enum: "businessType"
	},
	productType: {
		title: "产品类型",
		enum: "productType"
	},
	flowId: {
		title: "流程编号",
		enum: "flowId"
	},
	status: {
		title: "状态",
		enum: "status"
	}
},
      model: {
      columns:[
	{
		title: "产品编码",
		field: "productNo"
	},
	{
		title: "产品名称",
		field: "productName"
	},
	{
		title: "渠道编码",
		field: "channelNo",
		format: {
			type: "enum",
			pattern: "channelNo"
		}
	},
	{
		title: "上游产品编码",
		field: "upProductCode"
	},
	{
		title: "业务类型",
		field: "businessType",
		format: {
			type: "enum",
			pattern: "businessType"
		}
	},
	{
		title: "产品类型",
		field: "productType",
		format: {
			type: "enum",
			pattern: "productType"
		}
	},
	{
		title: "运营商",
		field: "carrierNo"
	},
	{
		title: "省份",
		field: "provinceNo"
	},
	{
		title: "地市",
		field: "cityNo"
	},
	{
		title: "面值",
		field: "faceFee"
	},
	{
		title: "标准价格",
		field: "normalPrice",
		format: {
			type: "money"
		}
	},
	{
		title: "扣款价格",
		field: "deductPrice",
		format: {
			type: "money"
		}
	},
	{
		title: "分组编码",
		field: "groupNo"
	},
	{
		title: "流程编号",
		field: "flowId",
		format: {
			type: "enum",
			pattern: "flowId"
		}
	},
	{
		title: "状态",
		field: "status",
		format: {
			type: "enum",
			pattern: "status"
		}
	},
	{
		title: "备注",
		field: "remark"
	},
	{
		title: "扩展字段1",
		field: "extend1"
	},
	{
		title: "扩展字段2",
		field: "extend2"
	},
	{
		title: "扩展字段3",
		field: "extend3"
	},
	{
		title: "创建人",
		field: "createUser"
	},
	{
		title: "创建时间",
		field: "createTime",
		format: {
			type: "date"
		}
	},
	{
		title: "更新人",
		field: "updateUser"
	},
	{
		title: "更新时间",
		field: "updateTime",
		format: {
			type: "date"
		}
	}
]
      },
      query:{
	productName: null,
	channelNo: null,
	upProductCode: null,
	businessType: null,
	productType: null,
	carrierNo: null,
	provinceNo: null,
	cityNo: null,
	groupNo: null,
	flowId: null,
	status: null
}
    }
  }
}
</script>