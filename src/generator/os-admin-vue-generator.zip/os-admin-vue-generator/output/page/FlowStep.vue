<template>
  <div>
    <Filters>
      <span v-for="(value,key,i) in selects" :key="i">
        <Select :title="value.title" :enum="value.enum" v-model="query[key]" :width="value.width"/>
      </span>
      <span>
        <RadioGroup v-model="radioKey" :options="radioOptions"/>
        <Input v-model.trim="radioValue" />
      </span>
      <QueryButton @click="queryData(true)"/>
      <CreateButton @click="showAdd"/>
    </Filters>
    <Table :data="model.list">
      <el-table-column v-for="item in model.columns" header-align="center" align="center" :key="item.field" :min-width="item.minWidth" :prop="item.field" :label="item.title" :sortable="item.isSort">
        <template slot-scope="scope">
          <PlainText :value="scope.row[item.field]" :filterType="item.filter" :format="item.format" :color="$ColorPicker(item, scope.row[item.field])" />
        </template>
      </el-table-column>
      <el-table-column header-align="center" align="center" label="操作">
        <template slot-scope="scope">
          <el-button type="text" size="small" @click="showEdit(scope.row)">编辑</el-button>
          <el-button type="text" size="small" @click="showDelete(scope.row)">删除</el-button>
        </template>
      </el-table-column>
    </Table>
    <Pager :total="model.total" :current="query.pageNum" @pi-change="onPageIndexChanged" @ps-change="onPageSizeChanged" />
    <Edit ref="edit" @updated="afterUpdated"/>
  </div>
</template>
<script>
/**
 * 流程步骤
 * 
 * generated at 2021-1-13 9:37:37 AM
 */
import listPageMixin from "./../../list-page-mixin";
import Edit from './modal/FlowStepEdit'
export default {
  components: {
    Edit
  },
  mixins:[listPageMixin],
  data() {
    return {
      radioValue: "",
      radioKey: "stepName",
      radioOptions: [
	{
		value: "stepName",
		name: "步骤名称"
	},
	{
		value: "serviceCode",
		name: "服务编码"
	}
],
      apiPrefix:"",
      pkName:"stepId",
      title:"流程步骤",
      selects:{
	flowId: {
		title: "流程编号",
		enum: "flowId"
	},
	stepType: {
		title: "步骤类型",
		enum: "stepType"
	},
	stepMode: {
		title: "步骤模式",
		enum: "stepMode"
	},
	nextType: {
		title: "下一步骤类型",
		enum: "nextType"
	}
},
      model: {
      columns:[
	{
		title: "步骤编号",
		field: "stepId"
	},
	{
		title: "流程编号",
		field: "flowId",
		format: {
			type: "enum",
			pattern: "flowId"
		}
	},
	{
		title: "步骤名称",
		field: "stepName"
	},
	{
		title: "步骤索引",
		field: "stepIndex"
	},
	{
		title: "步骤类型",
		field: "stepType",
		format: {
			type: "enum",
			pattern: "stepType"
		}
	},
	{
		title: "步骤模式",
		field: "stepMode",
		format: {
			type: "enum",
			pattern: "stepMode"
		}
	},
	{
		title: "服务编码",
		field: "serviceCode"
	},
	{
		title: "下一步骤",
		field: "nextStep"
	},
	{
		title: "下一步骤类型",
		field: "nextType",
		format: {
			type: "enum",
			pattern: "nextType"
		}
	},
	{
		title: "条件参数",
		field: "cndArgs"
	},
	{
		title: "重试最大次数",
		field: "retryMaxTimes"
	},
	{
		title: "创建人",
		field: "createUser"
	},
	{
		title: "创建时间",
		field: "createTime",
		format: {
			type: "date"
		}
	},
	{
		title: "更新人",
		field: "updateUser"
	},
	{
		title: "更新时间",
		field: "updateTime",
		format: {
			type: "date"
		}
	}
]
      },
      query:{
	flowId: null,
	stepName: null,
	stepType: null,
	stepMode: null,
	serviceCode: null,
	nextType: null
}
    }
  }
}
</script>