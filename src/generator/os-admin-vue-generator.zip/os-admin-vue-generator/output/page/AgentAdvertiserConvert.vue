<template>
  <div>
    <Filters>
      <span v-for="(value,key,i) in selects" :key="i">
        <Select :title="value.title" :enum="value.enum" v-model="query[key]" :width="value.width"/>
      </span>
      <span>
        <RadioGroup v-model="radioKey" :options="radioOptions"/>
        <Input v-model.trim="radioValue" />
      </span>
      <QueryButton @click="queryData(true)"/>
      <CreateButton @click="showAdd"/>
    </Filters>
    <Table :data="model.list">
      <el-table-column v-for="item in model.columns" header-align="center" align="center" :key="item.field" :min-width="item.minWidth" :prop="item.field" :label="item.title" :sortable="item.isSort">
        <template slot-scope="scope">
          <PlainText :value="scope.row[item.field]" :filterType="item.filter" :format="item.format" :color="$ColorPicker(item, scope.row[item.field])" />
        </template>
      </el-table-column>
      <el-table-column header-align="center" align="center" label="操作">
        <template slot-scope="scope">
          <el-button type="text" size="small" @click="showEdit(scope.row)">编辑</el-button>
          <el-button type="text" size="small" @click="showDelete(scope.row)">删除</el-button>
        </template>
      </el-table-column>
    </Table>
    <Pager :total="model.total" :current="query.pageNum" @pi-change="onPageIndexChanged" @ps-change="onPageSizeChanged" />
    <Edit ref="edit" @updated="afterUpdated"/>
  </div>
</template>
<script>
/**
 * 广告主转化
 * 
 * generated at 2021-1-13 9:37:37 AM
 */
import listPageMixin from "./../../list-page-mixin";
import Edit from './modal/AgentAdvertiserConvertEdit'
export default {
  components: {
    Edit
  },
  mixins:[listPageMixin],
  data() {
    return {
      radioValue: "",
      radioKey: "convertName",
      radioOptions: [
	{
		value: "convertName",
		name: "转化名称"
	},
	{
		value: "convertId",
		name: "转化ID"
	}
],
      apiPrefix:"advertiser/advertiser-convert",
      pkName:"convertId",
      title:"广告主转化",
      selects:{
	convertUid: {
		title: "转化编号",
		enum: "convertUid"
	},
	pageId: {
		title: "落地页编号",
		enum: "pageId"
	},
	reportType: {
		title: "回码类型",
		enum: "reportType"
	},
	activeStatus: {
		title: "激活状态",
		enum: "activeStatus"
	}
},
      model: {
      columns:[
	{
		title: "转化编号",
		field: "convertUid",
		format: {
			type: "enum",
			pattern: "convertUid"
		}
	},
	{
		title: "广告主编号",
		field: "advertiserUid"
	},
	{
		title: "转化名称",
		field: "convertName"
	},
	{
		title: "转化ID",
		field: "convertId"
	},
	{
		title: "落地页编号",
		field: "pageId",
		format: {
			type: "enum",
			pattern: "pageId"
		}
	},
	{
		title: "回码类型",
		field: "reportType",
		format: {
			type: "enum",
			pattern: "reportType"
		}
	},
	{
		title: "回码点",
		field: "reportPoint"
	},
	{
		title: "激活状态",
		field: "activeStatus",
		format: {
			type: "enum",
			pattern: "activeStatus"
		}
	},
	{
		title: "激活参数",
		field: "activeArgs"
	},
	{
		title: "创建人",
		field: "createUser"
	},
	{
		title: "创建时间",
		field: "createTime",
		format: {
			type: "date"
		}
	},
	{
		title: "更新人",
		field: "updateUser"
	},
	{
		title: "更新时间",
		field: "updateTime",
		format: {
			type: "date"
		}
	}
]
      },
      query:{
	convertUid: null,
	convertName: null,
	pageId: null,
	reportType: null,
	activeStatus: null
}
    }
  }
}
</script>