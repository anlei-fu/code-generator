<template>
  <div>
    <Filters>
      <span v-for="(value,key,i) in selects" :key="i">
        <Select :title="value.title" :enum="value.enum" v-model="query[key]" :width="value.width"/>
      </span>
      <span>
        <RadioGroup v-model="radioKey" :options="radioOptions"/>
        <Input v-model.trim="radioValue" />
      </span>
      <QueryButton @click="queryData(true)"/>
      <CreateButton @click="showAdd"/>
    </Filters>
    <Table :data="model.list">
      <el-table-column v-for="item in model.columns" header-align="center" align="center" :key="item.field" :min-width="item.minWidth" :prop="item.field" :label="item.title" :sortable="item.isSort">
        <template slot-scope="scope">
          <PlainText :value="scope.row[item.field]" :filterType="item.filter" :format="item.format" :color="$ColorPicker(item, scope.row[item.field])" />
        </template>
      </el-table-column>
      <el-table-column header-align="center" align="center" label="操作">
        <template slot-scope="scope">
          <el-button type="text" size="small" @click="showEdit(scope.row)">编辑</el-button>
          <el-button type="text" size="small" @click="showDelete(scope.row)">删除</el-button>
        </template>
      </el-table-column>
    </Table>
    <Pager :total="model.total" :current="query.pageNum" @pi-change="onPageIndexChanged" @ps-change="onPageSizeChanged" />
    <Edit ref="edit" @updated="afterUpdated"/>
  </div>
</template>
<script>
/**
 * 系统乡镇街道表(乡级)
 * 
 * generated at 2021-1-13 9:37:37 AM
 */
import listPageMixin from "./../../list-page-mixin";
import Edit from './modal/SystemTownEdit'
export default {
  components: {
    Edit
  },
  mixins:[listPageMixin],
  data() {
    return {
      radioValue: "",
      radioKey: "townNo",
      radioOptions: [
	{
		value: "townNo",
		name: "乡镇街道编码"
	},
	{
		value: "townName",
		name: "乡镇街道名称"
	},
	{
		value: "townCode",
		name: "乡镇街道代码"
	},
	{
		value: "areaNo",
		name: "区县编码"
	},
	{
		value: "cityNo",
		name: "地市编码"
	},
	{
		value: "provinceNo",
		name: "省份编码"
	}
],
      apiPrefix:"",
      pkName:"townCode",
      title:"系统乡镇街道表(乡级)",
      selects:{},
      model: {
      columns:[
	{
		title: "乡镇街道编码",
		field: "townNo"
	},
	{
		title: "乡镇街道名称",
		field: "townName"
	},
	{
		title: "乡镇街道代码",
		field: "townCode"
	},
	{
		title: "区县编码",
		field: "areaNo"
	},
	{
		title: "地市编码",
		field: "cityNo"
	},
	{
		title: "省份编码",
		field: "provinceNo"
	}
]
      },
      query:{
	townNo: null,
	townName: null,
	areaNo: null,
	cityNo: null,
	provinceNo: null
}
    }
  }
}
</script>