<template>
  <div>
    <Filters>
      <span v-for="(value,key,i) in selects" :key="i">
        <Select :title="value.title" :enum="value.enum" v-model="query[key]" :width="value.width"/>
      </span>
      <span>
        <RadioGroup v-model="radioKey" :options="radioOptions"/>
        <Input v-model.trim="radioValue" />
      </span>
      <QueryButton @click="queryData(true)"/>
      <CreateButton @click="showAdd"/>
    </Filters>
    <Table :data="model.list">
      <el-table-column v-for="item in model.columns" header-align="center" align="center" :key="item.field" :min-width="item.minWidth" :prop="item.field" :label="item.title" :sortable="item.isSort">
        <template slot-scope="scope">
          <PlainText :value="scope.row[item.field]" :filterType="item.filter" :format="item.format" :color="$ColorPicker(item, scope.row[item.field])" />
        </template>
      </el-table-column>
      <el-table-column header-align="center" align="center" label="操作">
        <template slot-scope="scope">
          <el-button type="text" size="small" @click="showEdit(scope.row)">编辑</el-button>
          <el-button type="text" size="small" @click="showDelete(scope.row)">删除</el-button>
        </template>
      </el-table-column>
    </Table>
    <Pager :total="model.total" :current="query.pageNum" @pi-change="onPageIndexChanged" @ps-change="onPageSizeChanged" />
    <Edit ref="edit" @updated="afterUpdated"/>
  </div>
</template>
<script>
/**
 * 定时任务表
 * 
 * generated at 2021-1-13 9:37:37 AM
 */
import listPageMixin from "./../../list-page-mixin";
import Edit from './modal/TimedTaskEdit'
export default {
  components: {
    Edit
  },
  mixins:[listPageMixin],
  data() {
    return {
      radioValue: "",
      radioKey: "taskName",
      radioOptions: [
	{
		value: "taskName",
		name: "任务名称"
	}
],
      apiPrefix:"",
      pkName:"taskId",
      title:"定时任务表",
      selects:{
	taskStatus: {
		title: "任务状态",
		enum: "taskStatus"
	}
},
      model: {
      columns:[
	{
		title: "任务编号",
		field: "taskId"
	},
	{
		title: "任务名称",
		field: "taskName"
	},
	{
		title: "任务路由",
		field: "taskRoute"
	},
	{
		title: "任务参数",
		field: "taskArgs"
	},
	{
		title: "任务状态",
		field: "taskStatus",
		format: {
			type: "enum",
			pattern: "taskStatus"
		}
	},
	{
		title: "重试次数",
		field: "retryTimes"
	},
	{
		title: "重试间隔",
		field: "retryInterval"
	},
	{
		title: "最大重试次数",
		field: "retryMax"
	},
	{
		title: "执行开始时间",
		field: "startTime",
		format: {
			type: "date"
		}
	},
	{
		title: "执行完成时间",
		field: "finishTime",
		format: {
			type: "date"
		}
	},
	{
		title: "下次执行时间",
		field: "nextTime",
		format: {
			type: "date"
		}
	},
	{
		title: "执行耗时",
		field: "execCost",
		format: {
			type: "money"
		}
	},
	{
		title: "执行服务器IP",
		field: "serverIp"
	},
	{
		title: "执行结果消息",
		field: "resultMsg"
	},
	{
		title: "执行优先级",
		field: "priority"
	},
	{
		title: "创建时间",
		field: "createTime",
		format: {
			type: "date"
		}
	},
	{
		title: "更新时间",
		field: "updateTime",
		format: {
			type: "date"
		}
	},
	{
		title: "过期时间",
		field: "expireTime",
		format: {
			type: "date"
		}
	}
]
      },
      query:{
	taskName: null,
	taskStatus: null
}
    }
  }
}
</script>