<template>
  <div>
    <Filters>
      <span v-for="(value,key,i) in selects" :key="i">
        <Select :title="value.title" :enum="value.enum" v-model="query[key]" :width="value.width"/>
      </span>
      <span>
        <RadioGroup v-model="radioKey" :options="radioOptions"/>
        <Input v-model.trim="radioValue" />
      </span>
      <QueryButton @click="queryData(true)"/>
      <CreateButton @click="showAdd"/>
    </Filters>
    <Table :data="model.list">
      <el-table-column v-for="item in model.columns" header-align="center" align="center" :key="item.field" :min-width="item.minWidth" :prop="item.field" :label="item.title" :sortable="item.isSort">
        <template slot-scope="scope">
          <PlainText :value="scope.row[item.field]" :filterType="item.filter" :format="item.format" :color="$ColorPicker(item, scope.row[item.field])" />
        </template>
      </el-table-column>
      <el-table-column header-align="center" align="center" label="操作">
        <template slot-scope="scope">
          <el-button type="text" size="small" @click="showEdit(scope.row)">编辑</el-button>
          <el-button type="text" size="small" @click="showDelete(scope.row)">删除</el-button>
        </template>
      </el-table-column>
    </Table>
    <Pager :total="model.total" :current="query.pageNum" @pi-change="onPageIndexChanged" @ps-change="onPageSizeChanged" />
    <Edit ref="edit" @updated="afterUpdated"/>
  </div>
</template>
<script>
/**
 * 订单主表
 * 
 * generated at 2021-1-13 9:37:37 AM
 */
import listPageMixin from "./../../list-page-mixin";
import Edit from './modal/OrderMainEdit'
export default {
  components: {
    Edit
  },
  mixins:[listPageMixin],
  data() {
    return {
      radioValue: "",
      radioKey: "orderNo",
      radioOptions: [
	{
		value: "orderNo",
		name: "订单号"
	},
	{
		value: "carrierNo",
		name: "运营商编码"
	},
	{
		value: "provinceNo",
		name: "省份编码"
	},
	{
		value: "cityNo",
		name: "地市编码"
	},
	{
		value: "accountNo",
		name: "办理账号"
	}
],
      apiPrefix:"",
      pkName:"orderNo",
      title:"订单主表",
      selects:{
	termNo: {
		title: "终端编号",
		enum: "termNo"
	},
	termProductNo: {
		title: "终端产品编号",
		enum: "termProductNo"
	},
	platNo: {
		title: "平台编号",
		enum: "platNo"
	},
	agentNo: {
		title: "代理商编号",
		enum: "agentNo"
	},
	pageId: {
		title: "落地页编号",
		enum: "pageId"
	},
	convertUid: {
		title: "转化编号",
		enum: "convertUid"
	},
	businessType: {
		title: "业务类型",
		enum: "businessType"
	},
	productType: {
		title: "产品类型",
		enum: "productType"
	},
	orderStatus: {
		title: "订单状态",
		enum: "orderStatus"
	},
	manualStatus: {
		title: "人工状态",
		enum: "manualStatus"
	}
},
      model: {
      columns:[
	{
		title: "订单号",
		field: "orderNo"
	},
	{
		title: "终端编号",
		field: "termNo",
		format: {
			type: "enum",
			pattern: "termNo"
		}
	},
	{
		title: "终端产品编号",
		field: "termProductNo",
		format: {
			type: "enum",
			pattern: "termProductNo"
		}
	},
	{
		title: "平台编号",
		field: "platNo",
		format: {
			type: "enum",
			pattern: "platNo"
		}
	},
	{
		title: "代理商编号",
		field: "agentNo",
		format: {
			type: "enum",
			pattern: "agentNo"
		}
	},
	{
		title: "投放账户编号",
		field: "accountId"
	},
	{
		title: "广告主编号",
		field: "advertiserUid"
	},
	{
		title: "落地页编号",
		field: "pageId",
		format: {
			type: "enum",
			pattern: "pageId"
		}
	},
	{
		title: "转化编号",
		field: "convertUid",
		format: {
			type: "enum",
			pattern: "convertUid"
		}
	},
	{
		title: "业务类型",
		field: "businessType",
		format: {
			type: "enum",
			pattern: "businessType"
		}
	},
	{
		title: "产品类型",
		field: "productType",
		format: {
			type: "enum",
			pattern: "productType"
		}
	},
	{
		title: "运营商编码",
		field: "carrierNo"
	},
	{
		title: "省份编码",
		field: "provinceNo"
	},
	{
		title: "地市编码",
		field: "cityNo"
	},
	{
		title: "办理账号",
		field: "accountNo"
	},
	{
		title: "订单面值",
		field: "faceFee"
	},
	{
		title: "订单成本",
		field: "costPrice",
		format: {
			type: "money"
		}
	},
	{
		title: "订单状态",
		field: "orderStatus",
		format: {
			type: "enum",
			pattern: "orderStatus"
		}
	},
	{
		title: "订单结果",
		field: "resultMsg"
	},
	{
		title: "人工状态",
		field: "manualStatus",
		format: {
			type: "enum",
			pattern: "manualStatus"
		}
	},
	{
		title: "用户IP",
		field: "userIp"
	},
	{
		title: "服务器IP",
		field: "serverIp"
	},
	{
		title: "下次执行时间",
		field: "execNextTime",
		format: {
			type: "date"
		}
	},
	{
		title: "下次执行批次",
		field: "execBatchNo"
	},
	{
		title: "执行次数",
		field: "execTimes"
	},
	{
		title: "用户参数",
		field: "userParams"
	},
	{
		title: "扩展字段1",
		field: "extend1"
	},
	{
		title: "扩展字段2",
		field: "extend2"
	},
	{
		title: "扩展字段3",
		field: "extend3"
	},
	{
		title: "扩展字段4",
		field: "extend4"
	},
	{
		title: "扩展字段5",
		field: "extend5"
	},
	{
		title: "平台参数",
		field: "platParams"
	},
	{
		title: "创建时间",
		field: "createTime",
		format: {
			type: "date"
		}
	},
	{
		title: "完成时间",
		field: "finishTime",
		format: {
			type: "date"
		}
	}
]
      },
      query:{
	termNo: null,
	termProductNo: null,
	platNo: null,
	agentNo: null,
	pageId: null,
	convertUid: null,
	businessType: null,
	productType: null,
	carrierNo: null,
	provinceNo: null,
	cityNo: null,
	accountNo: null,
	orderStatus: null,
	manualStatus: null
}
    }
  }
}
</script>