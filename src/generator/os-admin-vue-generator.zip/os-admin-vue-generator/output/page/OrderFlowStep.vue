<template>
  <div>
    <Filters>
      <span v-for="(value,key,i) in selects" :key="i">
        <Select :title="value.title" :enum="value.enum" v-model="query[key]" :width="value.width"/>
      </span>
      <span>
        <RadioGroup v-model="radioKey" :options="radioOptions"/>
        <Input v-model.trim="radioValue" />
      </span>
      <QueryButton @click="queryData(true)"/>
      <CreateButton @click="showAdd"/>
    </Filters>
    <Table :data="model.list">
      <el-table-column v-for="item in model.columns" header-align="center" align="center" :key="item.field" :min-width="item.minWidth" :prop="item.field" :label="item.title" :sortable="item.isSort">
        <template slot-scope="scope">
          <PlainText :value="scope.row[item.field]" :filterType="item.filter" :format="item.format" :color="$ColorPicker(item, scope.row[item.field])" />
        </template>
      </el-table-column>
      <el-table-column header-align="center" align="center" label="操作">
        <template slot-scope="scope">
          <el-button type="text" size="small" @click="showEdit(scope.row)">编辑</el-button>
          <el-button type="text" size="small" @click="showDelete(scope.row)">删除</el-button>
        </template>
      </el-table-column>
    </Table>
    <Pager :total="model.total" :current="query.pageNum" @pi-change="onPageIndexChanged" @ps-change="onPageSizeChanged" />
    <Edit ref="edit" @updated="afterUpdated"/>
  </div>
</template>
<script>
/**
 * 订单流程步骤
 * 
 * generated at 2021-1-13 9:37:37 AM
 */
import listPageMixin from "./../../list-page-mixin";
import Edit from './modal/OrderFlowStepEdit'
export default {
  components: {
    Edit
  },
  mixins:[listPageMixin],
  data() {
    return {
      radioValue: "",
      radioKey: "orderNo",
      radioOptions: [
	{
		value: "orderNo",
		name: "订单号"
	}
],
      apiPrefix:"",
      pkName:"recordId",
      title:"订单流程步骤",
      selects:{
	flowId: {
		title: "流程编号",
		enum: "flowId"
	},
	stepId: {
		title: "步骤编号",
		enum: "stepId"
	},
	lastFlowId: {
		title: "上一流程",
		enum: "lastFlowId"
	},
	lastStepId: {
		title: "上一步骤",
		enum: "lastStepId"
	},
	upChannelNo: {
		title: "上游渠道",
		enum: "upChannelNo"
	},
	upProductNo: {
		title: "上游产品",
		enum: "upProductNo"
	},
	stepStatus: {
		title: "步骤状态",
		enum: "stepStatus"
	},
	manualStatus: {
		title: "人工状态",
		enum: "manualStatus"
	}
},
      model: {
      columns:[
	{
		title: "记录编号",
		field: "recordId"
	},
	{
		title: "订单号",
		field: "orderNo"
	},
	{
		title: "流程编号",
		field: "flowId",
		format: {
			type: "enum",
			pattern: "flowId"
		}
	},
	{
		title: "步骤编号",
		field: "stepId",
		format: {
			type: "enum",
			pattern: "stepId"
		}
	},
	{
		title: "上一流程",
		field: "lastFlowId",
		format: {
			type: "enum",
			pattern: "lastFlowId"
		}
	},
	{
		title: "上一步骤",
		field: "lastStepId",
		format: {
			type: "enum",
			pattern: "lastStepId"
		}
	},
	{
		title: "上游渠道",
		field: "upChannelNo",
		format: {
			type: "enum",
			pattern: "upChannelNo"
		}
	},
	{
		title: "上游产品",
		field: "upProductNo",
		format: {
			type: "enum",
			pattern: "upProductNo"
		}
	},
	{
		title: "步骤状态",
		field: "stepStatus",
		format: {
			type: "enum",
			pattern: "stepStatus"
		}
	},
	{
		title: "人工状态",
		field: "manualStatus",
		format: {
			type: "enum",
			pattern: "manualStatus"
		}
	},
	{
		title: "创建时间",
		field: "createTime",
		format: {
			type: "date"
		}
	},
	{
		title: "完成时间",
		field: "finishTime",
		format: {
			type: "date"
		}
	}
]
      },
      query:{
	orderNo: null,
	flowId: null,
	stepId: null,
	lastFlowId: null,
	lastStepId: null,
	upChannelNo: null,
	upProductNo: null,
	stepStatus: null,
	manualStatus: null
}
    }
  }
}
</script>