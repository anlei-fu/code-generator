<template>
  <div>
    <Filters>
      <span v-for="(value,key,i) in selects" :key="i">
        <Select :title="value.title" :enum="value.enum" v-model="query[key]" :width="value.width"/>
      </span>
      <span>
        <RadioGroup v-model="radioKey" :options="radioOptions"/>
        <Input v-model.trim="radioValue" />
      </span>
      <QueryButton @click="queryData(true)"/>
      <CreateButton @click="showAdd"/>
    </Filters>
    <Table :data="model.list">
      <el-table-column v-for="item in model.columns" header-align="center" align="center" :key="item.field" :min-width="item.minWidth" :prop="item.field" :label="item.title" :sortable="item.isSort">
        <template slot-scope="scope">
          <PlainText :value="scope.row[item.field]" :filterType="item.filter" :format="item.format" :color="$ColorPicker(item, scope.row[item.field])" />
        </template>
      </el-table-column>
      <el-table-column header-align="center" align="center" label="操作">
        <template slot-scope="scope">
          <el-button type="text" size="small" @click="showEdit(scope.row)">编辑</el-button>
          <el-button type="text" size="small" @click="showDelete(scope.row)">删除</el-button>
        </template>
      </el-table-column>
    </Table>
    <Pager :total="model.total" :current="query.pageNum" @pi-change="onPageIndexChanged" @ps-change="onPageSizeChanged" />
    <Edit ref="edit" @updated="afterUpdated"/>
  </div>
</template>
<script>
/**
 * 订单验证码表
 * 
 * generated at 2021-1-13 9:37:37 AM
 */
import listPageMixin from "./../../list-page-mixin";
import Edit from './modal/OrderCaptchaEdit'
export default {
  components: {
    Edit
  },
  mixins:[listPageMixin],
  data() {
    return {
      radioValue: "",
      radioKey: "orderNo",
      radioOptions: [
	{
		value: "orderNo",
		name: "订单号"
	},
	{
		value: "carrierNo",
		name: "运营商编码"
	},
	{
		value: "provinceNo",
		name: "省份编码"
	},
	{
		value: "cityNo",
		name: "地市编码"
	},
	{
		value: "upSeqNo",
		name: "上游流水号"
	}
],
      apiPrefix:"",
      pkName:"recordId",
      title:"订单验证码表",
      selects:{
	termNo: {
		title: "终端编号",
		enum: "termNo"
	},
	termProductNo: {
		title: "产品编号",
		enum: "termProductNo"
	},
	platNo: {
		title: "平台编号",
		enum: "platNo"
	},
	agentNo: {
		title: "代理商编号",
		enum: "agentNo"
	},
	pageId: {
		title: "落地页编号",
		enum: "pageId"
	},
	businessType: {
		title: "业务类型",
		enum: "businessType"
	},
	productType: {
		title: "产品类型",
		enum: "productType"
	},
	upChannelNo: {
		title: "上游渠道编号",
		enum: "upChannelNo"
	},
	upProductNo: {
		title: "上游产品编号",
		enum: "upProductNo"
	},
	captchaType: {
		title: "验证码类型",
		enum: "captchaType"
	},
	sendStatus: {
		title: "发送状态",
		enum: "sendStatus"
	},
	convertUid: {
		title: "转化编号",
		enum: "convertUid"
	}
},
      model: {
      columns:[
	{
		title: "记录编号",
		field: "recordId"
	},
	{
		title: "订单号",
		field: "orderNo"
	},
	{
		title: "终端编号",
		field: "termNo",
		format: {
			type: "enum",
			pattern: "termNo"
		}
	},
	{
		title: "产品编号",
		field: "termProductNo",
		format: {
			type: "enum",
			pattern: "termProductNo"
		}
	},
	{
		title: "平台编号",
		field: "platNo",
		format: {
			type: "enum",
			pattern: "platNo"
		}
	},
	{
		title: "代理商编号",
		field: "agentNo",
		format: {
			type: "enum",
			pattern: "agentNo"
		}
	},
	{
		title: "投放账户编号",
		field: "accountId"
	},
	{
		title: "落地页编号",
		field: "pageId",
		format: {
			type: "enum",
			pattern: "pageId"
		}
	},
	{
		title: "业务类型",
		field: "businessType",
		format: {
			type: "enum",
			pattern: "businessType"
		}
	},
	{
		title: "产品类型",
		field: "productType",
		format: {
			type: "enum",
			pattern: "productType"
		}
	},
	{
		title: "运营商编码",
		field: "carrierNo"
	},
	{
		title: "省份编码",
		field: "provinceNo"
	},
	{
		title: "地市编码",
		field: "cityNo"
	},
	{
		title: "手机号",
		field: "mobile"
	},
	{
		title: "订单面值",
		field: "faceFee"
	},
	{
		title: "订单成本",
		field: "costPrice",
		format: {
			type: "money"
		}
	},
	{
		title: "上游渠道编号",
		field: "upChannelNo",
		format: {
			type: "enum",
			pattern: "upChannelNo"
		}
	},
	{
		title: "上游产品编号",
		field: "upProductNo",
		format: {
			type: "enum",
			pattern: "upProductNo"
		}
	},
	{
		title: "验证码类型",
		field: "captchaType",
		format: {
			type: "enum",
			pattern: "captchaType"
		}
	},
	{
		title: "发送状态",
		field: "sendStatus",
		format: {
			type: "enum",
			pattern: "sendStatus"
		}
	},
	{
		title: "发送时间",
		field: "sendTime",
		format: {
			type: "date"
		}
	},
	{
		title: "发送结果",
		field: "resultMsg"
	},
	{
		title: "上游流水号",
		field: "upSeqNo"
	},
	{
		title: "扩展字段1",
		field: "extend1"
	},
	{
		title: "扩展字段2",
		field: "extend2"
	},
	{
		title: "扩展字段3",
		field: "extend3"
	},
	{
		title: "API服务器IP",
		field: "apiServerIp"
	},
	{
		title: "用户IP",
		field: "userIp"
	},
	{
		title: "创建时间",
		field: "createTime",
		format: {
			type: "date"
		}
	},
	{
		title: "完成时间",
		field: "finishTime",
		format: {
			type: "date"
		}
	},
	{
		title: "广告主编号",
		field: "advertiserUid"
	},
	{
		title: "转化编号",
		field: "convertUid",
		format: {
			type: "enum",
			pattern: "convertUid"
		}
	}
]
      },
      query:{
	orderNo: null,
	termNo: null,
	termProductNo: null,
	platNo: null,
	agentNo: null,
	pageId: null,
	businessType: null,
	productType: null,
	carrierNo: null,
	provinceNo: null,
	cityNo: null,
	upChannelNo: null,
	upProductNo: null,
	captchaType: null,
	sendStatus: null,
	upSeqNo: null,
	convertUid: null
}
    }
  }
}
</script>