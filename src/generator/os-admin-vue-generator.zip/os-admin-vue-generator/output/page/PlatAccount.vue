<template>
  <div>
    <Filters>
      <span v-for="(value,key,i) in selects" :key="i">
        <Select :title="value.title" :enum="value.enum" v-model="query[key]" :width="value.width"/>
      </span>
      <span>
        <RadioGroup v-model="radioKey" :options="radioOptions"/>
        <Input v-model.trim="radioValue" />
      </span>
      <QueryButton @click="queryData(true)"/>
      <CreateButton @click="showAdd"/>
    </Filters>
    <Table :data="model.list">
      <el-table-column v-for="item in model.columns" header-align="center" align="center" :key="item.field" :min-width="item.minWidth" :prop="item.field" :label="item.title" :sortable="item.isSort">
        <template slot-scope="scope">
          <PlainText :value="scope.row[item.field]" :filterType="item.filter" :format="item.format" :color="$ColorPicker(item, scope.row[item.field])" />
        </template>
      </el-table-column>
      <el-table-column header-align="center" align="center" label="操作">
        <template slot-scope="scope">
          <el-button type="text" size="small" @click="showEdit(scope.row)">编辑</el-button>
          <el-button type="text" size="small" @click="showDelete(scope.row)">删除</el-button>
        </template>
      </el-table-column>
    </Table>
    <Pager :total="model.total" :current="query.pageNum" @pi-change="onPageIndexChanged" @ps-change="onPageSizeChanged" />
    <Edit ref="edit" @updated="afterUpdated"/>
  </div>
</template>
<script>
/**
 * 开放平台账号
 * 
 * generated at 2021-1-13 9:37:37 AM
 */
import listPageMixin from "./../../list-page-mixin";
import Edit from './modal/PlatAccountEdit'
export default {
  components: {
    Edit
  },
  mixins:[listPageMixin],
  data() {
    return {
      radioValue: "",
      radioKey: "loginUid",
      radioOptions: [
	{
		value: "loginUid",
		name: "登录账号"
	}
],
      apiPrefix:"plat-agent/plat-account",
      pkName:"accountId",
      title:"开放平台账号",
      selects:{
	platNo: {
		title: "平台编号",
		enum: "platNo"
	}
},
      model: {
      columns:[
	{
		title: "账号编号",
		field: "accountId"
	},
	{
		title: "平台编号",
		field: "platNo",
		format: {
			type: "enum",
			pattern: "platNo"
		}
	},
	{
		title: "登录账号",
		field: "loginUid"
	},
	{
		title: "登录密码",
		field: "loginPwd"
	},
	{
		title: "创建人",
		field: "createUser"
	},
	{
		title: "创建时间",
		field: "createTime",
		format: {
			type: "date"
		}
	}
]
      },
      query:{
	platNo: null,
	loginUid: null
}
    }
  }
}
</script>