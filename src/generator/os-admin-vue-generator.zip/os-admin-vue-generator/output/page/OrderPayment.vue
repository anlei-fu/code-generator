<template>
  <div>
    <Filters>
      <span v-for="(value,key,i) in selects" :key="i">
        <Select :title="value.title" :enum="value.enum" v-model="query[key]" :width="value.width"/>
      </span>
      <span>
        <RadioGroup v-model="radioKey" :options="radioOptions"/>
        <Input v-model.trim="radioValue" />
      </span>
      <QueryButton @click="queryData(true)"/>
      <CreateButton @click="showAdd"/>
    </Filters>
    <Table :data="model.list">
      <el-table-column v-for="item in model.columns" header-align="center" align="center" :key="item.field" :min-width="item.minWidth" :prop="item.field" :label="item.title" :sortable="item.isSort">
        <template slot-scope="scope">
          <PlainText :value="scope.row[item.field]" :filterType="item.filter" :format="item.format" :color="$ColorPicker(item, scope.row[item.field])" />
        </template>
      </el-table-column>
      <el-table-column header-align="center" align="center" label="操作">
        <template slot-scope="scope">
          <el-button type="text" size="small" @click="showEdit(scope.row)">编辑</el-button>
          <el-button type="text" size="small" @click="showDelete(scope.row)">删除</el-button>
        </template>
      </el-table-column>
    </Table>
    <Pager :total="model.total" :current="query.pageNum" @pi-change="onPageIndexChanged" @ps-change="onPageSizeChanged" />
    <Edit ref="edit" @updated="afterUpdated"/>
  </div>
</template>
<script>
/**
 * 订单支付记录表
 * 
 * generated at 2021-1-13 9:37:37 AM
 */
import listPageMixin from "./../../list-page-mixin";
import Edit from './modal/OrderPaymentEdit'
export default {
  components: {
    Edit
  },
  mixins:[listPageMixin],
  data() {
    return {
      radioValue: "",
      radioKey: "orderNo",
      radioOptions: [
	{
		value: "orderNo",
		name: "订单号"
	}
],
      apiPrefix:"",
      pkName:"orderNo",
      title:"订单支付记录表",
      selects:{
	payStatus: {
		title: "支付状态",
		enum: "payStatus"
	}
},
      model: {
      columns:[
	{
		title: "订单号",
		field: "orderNo"
	},
	{
		title: "支付账号编号",
		field: "accountId"
	},
	{
		title: "支付价格",
		field: "payPrice",
		format: {
			type: "money"
		}
	},
	{
		title: "手续费率",
		field: "serviceRate"
	},
	{
		title: "手续费",
		field: "serviceFee"
	},
	{
		title: "支付状态",
		field: "payStatus",
		format: {
			type: "enum",
			pattern: "payStatus"
		}
	},
	{
		title: "支付平台流水",
		field: "tradeSeq"
	},
	{
		title: "支付平台消息",
		field: "tradeMsg"
	},
	{
		title: "支付创建时间",
		field: "createTime",
		format: {
			type: "date"
		}
	},
	{
		title: "支付完成时间",
		field: "finishTime",
		format: {
			type: "date"
		}
	}
]
      },
      query:{
	payStatus: null
}
    }
  }
}
</script>