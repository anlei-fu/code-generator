<template>
  <div>
    <Filters>
      <span v-for="(value,key,i) in selects" :key="i">
        <Select :title="value.title" :enum="value.enum" v-model="query[key]" :width="value.width"/>
      </span>
      <span>
        <RadioGroup v-model="radioKey" :options="radioOptions"/>
        <Input v-model.trim="radioValue" />
      </span>
      <QueryButton @click="queryData(true)"/>
      <CreateButton @click="showAdd"/>
    </Filters>
    <Table :data="model.list">
      <el-table-column v-for="item in model.columns" header-align="center" align="center" :key="item.field" :min-width="item.minWidth" :prop="item.field" :label="item.title" :sortable="item.isSort">
        <template slot-scope="scope">
          <PlainText :value="scope.row[item.field]" :filterType="item.filter" :format="item.format" :color="$ColorPicker(item, scope.row[item.field])" />
        </template>
      </el-table-column>
      <el-table-column header-align="center" align="center" label="操作">
        <template slot-scope="scope">
          <el-button type="text" size="small" @click="showEdit(scope.row)">编辑</el-button>
          <el-button type="text" size="small" @click="showDelete(scope.row)">删除</el-button>
        </template>
      </el-table-column>
    </Table>
    <Pager :total="model.total" :current="query.pageNum" @pi-change="onPageIndexChanged" @ps-change="onPageSizeChanged" />
    <Edit ref="edit" @updated="afterUpdated"/>
  </div>
</template>
<script>
/**
 * 发货记录表
 * 
 * generated at 2021-1-13 9:37:37 AM
 */
import listPageMixin from "./../../list-page-mixin";
import Edit from './modal/OrderDeliveryEdit'
export default {
  components: {
    Edit
  },
  mixins:[listPageMixin],
  data() {
    return {
      radioValue: "",
      radioKey: "orderNo",
      radioOptions: [
	{
		value: "orderNo",
		name: "订单号"
	},
	{
		value: "accountNo",
		name: "办理账号"
	},
	{
		value: "upOrderNo",
		name: "上游订单号"
	},
	{
		value: "serviceCode",
		name: "服务编码"
	}
],
      apiPrefix:"",
      pkName:"deliveryId",
      title:"发货记录表",
      selects:{
	termNo: {
		title: "终端编号",
		enum: "termNo"
	},
	termProductNo: {
		title: "终端产品",
		enum: "termProductNo"
	},
	upChannelNo: {
		title: "上游渠道",
		enum: "upChannelNo"
	},
	upProductNo: {
		title: "上游产品",
		enum: "upProductNo"
	},
	deliveryStatus: {
		title: "发货状态",
		enum: "deliveryStatus"
	},
	manualStatus: {
		title: "人工状态",
		enum: "manualStatus"
	}
},
      model: {
      columns:[
	{
		title: "发货编号",
		field: "deliveryId"
	},
	{
		title: "订单号",
		field: "orderNo"
	},
	{
		title: "终端编号",
		field: "termNo",
		format: {
			type: "enum",
			pattern: "termNo"
		}
	},
	{
		title: "终端产品",
		field: "termProductNo",
		format: {
			type: "enum",
			pattern: "termProductNo"
		}
	},
	{
		title: "终端价格",
		field: "termPrice",
		format: {
			type: "money"
		}
	},
	{
		title: "办理账号",
		field: "accountNo"
	},
	{
		title: "上游渠道",
		field: "upChannelNo",
		format: {
			type: "enum",
			pattern: "upChannelNo"
		}
	},
	{
		title: "上游产品",
		field: "upProductNo",
		format: {
			type: "enum",
			pattern: "upProductNo"
		}
	},
	{
		title: "上游价格",
		field: "upPrice",
		format: {
			type: "money"
		}
	},
	{
		title: "上游订单号",
		field: "upOrderNo"
	},
	{
		title: "发货状态",
		field: "deliveryStatus",
		format: {
			type: "enum",
			pattern: "deliveryStatus"
		}
	},
	{
		title: "人工状态",
		field: "manualStatus",
		format: {
			type: "enum",
			pattern: "manualStatus"
		}
	},
	{
		title: "上游结果",
		field: "resultMsg"
	},
	{
		title: "下次执行时间",
		field: "execNextTime",
		format: {
			type: "date"
		}
	},
	{
		title: "下次执行批次",
		field: "execBatchNo"
	},
	{
		title: "执行次数",
		field: "execTimes"
	},
	{
		title: "服务编码",
		field: "serviceCode"
	},
	{
		title: "服务器IP",
		field: "serverIp"
	},
	{
		title: "创建时间",
		field: "createTime",
		format: {
			type: "date"
		}
	},
	{
		title: "完成时间",
		field: "finishTime",
		format: {
			type: "date"
		}
	}
]
      },
      query:{
	orderNo: null,
	termNo: null,
	termProductNo: null,
	accountNo: null,
	upChannelNo: null,
	upProductNo: null,
	upOrderNo: null,
	deliveryStatus: null,
	manualStatus: null,
	serviceCode: null
}
    }
  }
}
</script>