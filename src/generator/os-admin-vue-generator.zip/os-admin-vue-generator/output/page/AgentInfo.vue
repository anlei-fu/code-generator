<template>
  <div>
    <Filters>
      <span v-for="(value,key,i) in selects" :key="i">
        <Select :title="value.title" :enum="value.enum" v-model="query[key]" :width="value.width"/>
      </span>
      <span>
        <RadioGroup v-model="radioKey" :options="radioOptions"/>
        <Input v-model.trim="radioValue" />
      </span>
      <QueryButton @click="queryData(true)"/>
      <CreateButton @click="showAdd"/>
    </Filters>
    <Table :data="model.list">
      <el-table-column v-for="item in model.columns" header-align="center" align="center" :key="item.field" :min-width="item.minWidth" :prop="item.field" :label="item.title" :sortable="item.isSort">
        <template slot-scope="scope">
          <PlainText :value="scope.row[item.field]" :filterType="item.filter" :format="item.format" :color="$ColorPicker(item, scope.row[item.field])" />
        </template>
      </el-table-column>
      <el-table-column header-align="center" align="center" label="操作">
        <template slot-scope="scope">
          <el-button type="text" size="small" @click="showEdit(scope.row)">编辑</el-button>
          <el-button type="text" size="small" @click="showDelete(scope.row)">删除</el-button>
        </template>
      </el-table-column>
    </Table>
    <Pager :total="model.total" :current="query.pageNum" @pi-change="onPageIndexChanged" @ps-change="onPageSizeChanged" />
    <Edit ref="edit" @updated="afterUpdated"/>
  </div>
</template>
<script>
/**
 * 代理商信息表
 * 
 * generated at 2021-1-13 9:37:37 AM
 */
import listPageMixin from "./../../list-page-mixin";
import Edit from './modal/AgentInfoEdit'
export default {
  components: {
    Edit
  },
  mixins:[listPageMixin],
  data() {
    return {
      radioValue: "",
      radioKey: "agentName",
      radioOptions: [
	{
		value: "agentName",
		name: "代理商名称"
	}
],
      apiPrefix:"plat-agent/agent",
      pkName:"agentNo",
      title:"代理商信息表",
      selects:{
	agentType: {
		title: "代理商类型",
		enum: "agentType"
	},
	carrierLicense: {
		title: "运营商资质",
		enum: "carrierLicense"
	},
	syncFlag: {
		title: "记账同步",
		enum: "syncFlag"
	},
	status: {
		title: "状态",
		enum: "status"
	}
},
      model: {
      columns:[
	{
		title: "代理商编号",
		field: "agentNo"
	},
	{
		title: "代理商名称",
		field: "agentName"
	},
	{
		title: "代理商类型",
		field: "agentType",
		format: {
			type: "enum",
			pattern: "agentType"
		}
	},
	{
		title: "运营商资质",
		field: "carrierLicense",
		format: {
			type: "enum",
			pattern: "carrierLicense"
		}
	},
	{
		title: "代理商余额",
		field: "agentBalanc"
	},
	{
		title: "记账余额",
		field: "fcBalance",
		format: {
			type: "money"
		}
	},
	{
		title: "现金余额",
		field: "cashBalance",
		format: {
			type: "money"
		}
	},
	{
		title: "账面余额",
		field: "validBalance",
		format: {
			type: "money"
		}
	},
	{
		title: "记账同步",
		field: "syncFlag",
		format: {
			type: "enum",
			pattern: "syncFlag"
		}
	},
	{
		title: "状态",
		field: "status",
		format: {
			type: "enum",
			pattern: "status"
		}
	},
	{
		title: "备注",
		field: "remark"
	}
]
      },
      query:{
	agentName: null,
	agentType: null,
	carrierLicense: null,
	syncFlag: null,
	status: null
}
    }
  }
}
</script>