<template>
  <div>
    <Filters>
      <span v-for="(value,key,i) in selects" :key="i">
        <Select :title="value.title" :enum="value.enum" v-model="query[key]" :width="value.width"/>
      </span>
      <span>
        <RadioGroup v-model="radioKey" :options="radioOptions"/>
        <Input v-model.trim="radioValue" />
      </span>
      <QueryButton @click="queryData(true)"/>
      <CreateButton @click="showAdd"/>
    </Filters>
    <Table :data="model.list">
      <el-table-column v-for="item in model.columns" header-align="center" align="center" :key="item.field" :min-width="item.minWidth" :prop="item.field" :label="item.title" :sortable="item.isSort">
        <template slot-scope="scope">
          <PlainText :value="scope.row[item.field]" :filterType="item.filter" :format="item.format" :color="$ColorPicker(item, scope.row[item.field])" />
        </template>
      </el-table-column>
      <el-table-column header-align="center" align="center" label="操作">
        <template slot-scope="scope">
          <el-button type="text" size="small" @click="showEdit(scope.row)">编辑</el-button>
          <el-button type="text" size="small" @click="showDelete(scope.row)">删除</el-button>
        </template>
      </el-table-column>
    </Table>
    <Pager :total="model.total" :current="query.pageNum" @pi-change="onPageIndexChanged" @ps-change="onPageSizeChanged" />
    <Edit ref="edit" @updated="afterUpdated"/>
  </div>
</template>
<script>
/**
 * 上游渠道信息
 * 
 * generated at 2021-1-13 9:37:37 AM
 */
import listPageMixin from "./../../list-page-mixin";
import Edit from './modal/UpChannelEdit'
export default {
  components: {
    Edit
  },
  mixins:[listPageMixin],
  data() {
    return {
      radioValue: "",
      radioKey: "channelName",
      radioOptions: [
	{
		value: "channelName",
		name: "渠道名称"
	},
	{
		value: "apiUid",
		name: "接口UID"
	},
	{
		value: "loginUid",
		name: "后台账号"
	},
	{
		value: "channelCode",
		name: "渠道编码"
	}
],
      apiPrefix:"",
      pkName:"channelNo",
      title:"上游渠道信息",
      selects:{
	syncFlag: {
		title: "同步记账",
		enum: "syncFlag"
	},
	status: {
		title: "状态",
		enum: "status"
	}
},
      model: {
      columns:[
	{
		title: "渠道编号",
		field: "channelNo"
	},
	{
		title: "渠道名称",
		field: "channelName"
	},
	{
		title: "接口UID",
		field: "apiUid"
	},
	{
		title: "接口SECRET",
		field: "apiSecret"
	},
	{
		title: "通知地址",
		field: "notifyUrl"
	},
	{
		title: "后台账号",
		field: "loginUid"
	},
	{
		title: "后台密码",
		field: "loginPwd"
	},
	{
		title: "渠道余额",
		field: "balance",
		format: {
			type: "money"
		}
	},
	{
		title: "支持查询",
		field: "canQuery"
	},
	{
		title: "首次查询延迟",
		field: "queryDelay"
	},
	{
		title: "查询间隔",
		field: "queryIntvl"
	},
	{
		title: "最大查询次数",
		field: "queryMaxTimes"
	},
	{
		title: "同步记账",
		field: "syncFlag",
		format: {
			type: "enum",
			pattern: "syncFlag"
		}
	},
	{
		title: "负责人",
		field: "principal"
	},
	{
		title: "状态",
		field: "status",
		format: {
			type: "enum",
			pattern: "status"
		}
	},
	{
		title: "备注",
		field: "remark"
	},
	{
		title: "渠道编码",
		field: "channelCode"
	}
]
      },
      query:{
	channelName: null,
	apiUid: null,
	loginUid: null,
	syncFlag: null,
	status: null,
	channelCode: null
}
    }
  }
}
</script>