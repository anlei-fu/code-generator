<template>
  <div>
    <Filters>
      <span v-for="(value,key,i) in selects" :key="i">
        <Select :title="value.title" :enum="value.enum" v-model="query[key]" :width="value.width"/>
      </span>
      <span>
        <RadioGroup v-model="radioKey" :options="radioOptions"/>
        <Input v-model.trim="radioValue" />
      </span>
      <QueryButton @click="queryData(true)"/>
      <CreateButton @click="showAdd"/>
    </Filters>
    <Table :data="model.list">
      <el-table-column v-for="item in model.columns" header-align="center" align="center" :key="item.field" :min-width="item.minWidth" :prop="item.field" :label="item.title" :sortable="item.isSort">
        <template slot-scope="scope">
          <PlainText :value="scope.row[item.field]" :filterType="item.filter" :format="item.format" :color="$ColorPicker(item, scope.row[item.field])" />
        </template>
      </el-table-column>
      <el-table-column header-align="center" align="center" label="操作">
        <template slot-scope="scope">
          <el-button type="text" size="small" @click="showEdit(scope.row)">编辑</el-button>
          <el-button type="text" size="small" @click="showDelete(scope.row)">删除</el-button>
        </template>
      </el-table-column>
    </Table>
    <Pager :total="model.total" :current="query.pageNum" @pi-change="onPageIndexChanged" @ps-change="onPageSizeChanged" />
    <Edit ref="edit" @updated="afterUpdated"/>
  </div>
</template>
<script>
/**
 * 订单通知记录
 * 
 * generated at 2021-1-13 9:37:37 AM
 */
import listPageMixin from "./../../list-page-mixin";
import Edit from './modal/OrderNotifyEdit'
export default {
  components: {
    Edit
  },
  mixins:[listPageMixin],
  data() {
    return {
      radioValue: "",
      radioKey: "orderNo",
      radioOptions: [
	{
		value: "orderNo",
		name: "订单号"
	},
	{
		value: "serviceCode",
		name: "服务编码"
	}
],
      apiPrefix:"",
      pkName:"recordId",
      title:"订单通知记录",
      selects:{
	notifyType: {
		title: "通知类型",
		enum: "notifyType"
	},
	notifyStatus: {
		title: "通知状态",
		enum: "notifyStatus"
	},
	notifyBatchId: {
		title: "通知批次号",
		enum: "notifyBatchId"
	}
},
      model: {
      columns:[
	{
		title: "记录编号",
		field: "recordId"
	},
	{
		title: "订单号",
		field: "orderNo"
	},
	{
		title: "通知类型",
		field: "notifyType",
		format: {
			type: "enum",
			pattern: "notifyType"
		}
	},
	{
		title: "通知状态",
		field: "notifyStatus",
		format: {
			type: "enum",
			pattern: "notifyStatus"
		}
	},
	{
		title: "通知结果",
		field: "resultMsg"
	},
	{
		title: "服务编码",
		field: "serviceCode"
	},
	{
		title: "通知地址",
		field: "notifyUrl"
	},
	{
		title: "服务器IP",
		field: "serverIp"
	},
	{
		title: "通知次数",
		field: "notifyTimes"
	},
	{
		title: "通知最大次数",
		field: "notifyMaxTimes"
	},
	{
		title: "通知批次号",
		field: "notifyBatchId",
		format: {
			type: "enum",
			pattern: "notifyBatchId"
		}
	},
	{
		title: "下次通知时间",
		field: "notifyNextTime",
		format: {
			type: "date"
		}
	},
	{
		title: "创建时间",
		field: "createTime",
		format: {
			type: "date"
		}
	},
	{
		title: "上次通知时间",
		field: "lastNotifyTime",
		format: {
			type: "date"
		}
	}
]
      },
      query:{
	orderNo: null,
	notifyType: null,
	notifyStatus: null,
	serviceCode: null,
	notifyBatchId: null
}
    }
  }
}
</script>