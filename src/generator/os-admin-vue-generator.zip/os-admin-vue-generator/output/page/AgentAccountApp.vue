<template>
  <div>
    <Filters>
      <span v-for="(value,key,i) in selects" :key="i">
        <Select :title="value.title" :enum="value.enum" v-model="query[key]" :width="value.width"/>
      </span>
      <span>
        <RadioGroup v-model="radioKey" :options="radioOptions"/>
        <Input v-model.trim="radioValue" />
      </span>
      <QueryButton @click="queryData(true)"/>
      <CreateButton @click="showAdd"/>
    </Filters>
    <Table :data="model.list">
      <el-table-column v-for="item in model.columns" header-align="center" align="center" :key="item.field" :min-width="item.minWidth" :prop="item.field" :label="item.title" :sortable="item.isSort">
        <template slot-scope="scope">
          <PlainText :value="scope.row[item.field]" :filterType="item.filter" :format="item.format" :color="$ColorPicker(item, scope.row[item.field])" />
        </template>
      </el-table-column>
      <el-table-column header-align="center" align="center" label="操作">
        <template slot-scope="scope">
          <el-button type="text" size="small" @click="showEdit(scope.row)">编辑</el-button>
          <el-button type="text" size="small" @click="showDelete(scope.row)">删除</el-button>
        </template>
      </el-table-column>
    </Table>
    <Pager :total="model.total" :current="query.pageNum" @pi-change="onPageIndexChanged" @ps-change="onPageSizeChanged" />
    <Edit ref="edit" @updated="afterUpdated"/>
  </div>
</template>
<script>
/**
 * 代理商账号应用
 * 
 * generated at 2021-1-8 9:16:08 AM
 */
import listPageMixin from "./../../list-page-mixin";
import Edit from './modal/AgentAccountAppEdit'
export default {
  components: {
    Edit
  },
  mixins:[listPageMixin],
  data() {
    return {
      radioValue: "",
      radioKey: "",
      radioOptions: [
	{
		value: "appId",
		name: "应用ID"
	},
	{
		value: "appName",
		name: "应用名称"
	}
],
      apiPrefix:"agent-account-app",
      pkField:"appUid",
      title:"代理商账号应用",
      selects:{
	accountId: {
		title: "账号编号",
		enum: "accountId"
	}
},
      model: {
      columns:[
	{
		title: "APP编号",
		field: "appUid"
	},
	{
		title: "账号编号",
		field: "accountId",
		format: {
			type: "enum",
			pattern: "Account"
		}
	},
	{
		title: "应用ID",
		field: "appId"
	},
	{
		title: "应用名称",
		field: "appName"
	},
	{
		title: "应用密钥",
		field: "appSecret"
	},
	{
		title: "回调地址",
		field: "callbackUrl"
	},
	{
		title: "访问令牌",
		field: "accessToken"
	},
	{
		title: "访问令牌过期",
		field: "accessTokenExpire",
		format: {
			type: "date"
		}
	},
	{
		title: "刷新令牌",
		field: "refreshToken"
	},
	{
		title: "下次刷新时间",
		field: "nextRefreshTime",
		format: {
			type: "date"
		}
	}
]
      },
      query:{
	accountId: null,
	appId: null,
	appName: null
}
    }
  }
}
</script>