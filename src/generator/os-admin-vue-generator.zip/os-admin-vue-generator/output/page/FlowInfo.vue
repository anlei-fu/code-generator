<template>
  <div>
    <Filters>
      <span v-for="(value,key,i) in selects" :key="i">
        <Select :title="value.title" :enum="value.enum" v-model="query[key]" :width="value.width"/>
      </span>
      <span>
        <RadioGroup v-model="radioKey" :options="radioOptions"/>
        <Input v-model.trim="radioValue" />
      </span>
      <QueryButton @click="queryData(true)"/>
      <CreateButton @click="showAdd"/>
    </Filters>
    <Table :data="model.list">
      <el-table-column v-for="item in model.columns" header-align="center" align="center" :key="item.field" :min-width="item.minWidth" :prop="item.field" :label="item.title" :sortable="item.isSort">
        <template slot-scope="scope">
          <PlainText :value="scope.row[item.field]" :filterType="item.filter" :format="item.format" :color="$ColorPicker(item, scope.row[item.field])" />
        </template>
      </el-table-column>
      <el-table-column header-align="center" align="center" label="操作">
        <template slot-scope="scope">
          <el-button type="text" size="small" @click="showEdit(scope.row)">编辑</el-button>
          <el-button type="text" size="small" @click="showDelete(scope.row)">删除</el-button>
        </template>
      </el-table-column>
    </Table>
    <Pager :total="model.total" :current="query.pageNum" @pi-change="onPageIndexChanged" @ps-change="onPageSizeChanged" />
    <Edit ref="edit" @updated="afterUpdated"/>
  </div>
</template>
<script>
/**
 * 流程信息
 * 
 * generated at 2021-1-13 9:37:37 AM
 */
import listPageMixin from "./../../list-page-mixin";
import Edit from './modal/FlowInfoEdit'
export default {
  components: {
    Edit
  },
  mixins:[listPageMixin],
  data() {
    return {
      radioValue: "",
      radioKey: "flowName",
      radioOptions: [
	{
		value: "flowName",
		name: "流程名称"
	}
],
      apiPrefix:"",
      pkName:"flowId",
      title:"流程信息",
      selects:{
	flowType: {
		title: "流程类型",
		enum: "flowType"
	},
	status: {
		title: "状态",
		enum: "status"
	}
},
      model: {
      columns:[
	{
		title: "流程编号",
		field: "flowId"
	},
	{
		title: "流程名称",
		field: "flowName"
	},
	{
		title: "流程类型",
		field: "flowType",
		format: {
			type: "enum",
			pattern: "flowType"
		}
	},
	{
		title: "状态",
		field: "status",
		format: {
			type: "enum",
			pattern: "status"
		}
	},
	{
		title: "备注",
		field: "remark"
	},
	{
		title: "创建人",
		field: "createUser"
	},
	{
		title: "创建时间",
		field: "createTime",
		format: {
			type: "date"
		}
	},
	{
		title: "更新人",
		field: "updateUser"
	},
	{
		title: "更新时间",
		field: "updateTime",
		format: {
			type: "date"
		}
	}
]
      },
      query:{
	flowName: null,
	flowType: null,
	status: null
}
    }
  }
}
</script>