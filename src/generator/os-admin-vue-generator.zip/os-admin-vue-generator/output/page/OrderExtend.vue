<template>
  <div>
    <Filters>
      <span v-for="(value,key,i) in selects" :key="i">
        <Select :title="value.title" :enum="value.enum" v-model="query[key]" :width="value.width"/>
      </span>
      <span>
        <RadioGroup v-model="radioKey" :options="radioOptions"/>
        <Input v-model.trim="radioValue" />
      </span>
      <QueryButton @click="queryData(true)"/>
      <CreateButton @click="showAdd"/>
    </Filters>
    <Table :data="model.list">
      <el-table-column v-for="item in model.columns" header-align="center" align="center" :key="item.field" :min-width="item.minWidth" :prop="item.field" :label="item.title" :sortable="item.isSort">
        <template slot-scope="scope">
          <PlainText :value="scope.row[item.field]" :filterType="item.filter" :format="item.format" :color="$ColorPicker(item, scope.row[item.field])" />
        </template>
      </el-table-column>
      <el-table-column header-align="center" align="center" label="操作">
        <template slot-scope="scope">
          <el-button type="text" size="small" @click="showEdit(scope.row)">编辑</el-button>
          <el-button type="text" size="small" @click="showDelete(scope.row)">删除</el-button>
        </template>
      </el-table-column>
    </Table>
    <Pager :total="model.total" :current="query.pageNum" @pi-change="onPageIndexChanged" @ps-change="onPageSizeChanged" />
    <Edit ref="edit" @updated="afterUpdated"/>
  </div>
</template>
<script>
/**
 * 订单扩展表
 * 
 * generated at 2021-1-13 9:37:37 AM
 */
import listPageMixin from "./../../list-page-mixin";
import Edit from './modal/OrderExtendEdit'
export default {
  components: {
    Edit
  },
  mixins:[listPageMixin],
  data() {
    return {
      radioValue: "",
      radioKey: "orderNo",
      radioOptions: [
	{
		value: "orderNo",
		name: "订单号"
	},
	{
		value: "idCardName",
		name: "办理人姓名"
	},
	{
		value: "expressName",
		name: "物流名称"
	},
	{
		value: "expressNo",
		name: "物流单号"
	}
],
      apiPrefix:"",
      pkName:"orderNo",
      title:"订单扩展表",
      selects:{
	activateStatus: {
		title: "激活状态",
		enum: "activateStatus"
	},
	rechargeStatus: {
		title: "首充状态",
		enum: "rechargeStatus"
	}
},
      model: {
      columns:[
	{
		title: "订单号",
		field: "orderNo"
	},
	{
		title: "联系人姓名",
		field: "contact"
	},
	{
		title: "联系人省份编码",
		field: "contactProv"
	},
	{
		title: "联系人地市编码",
		field: "contactCity"
	},
	{
		title: "联系人区域编码",
		field: "contactArea"
	},
	{
		title: "联系人详细地址",
		field: "contactAddr"
	},
	{
		title: "办理人身份证",
		field: "idCard"
	},
	{
		title: "办理人姓名",
		field: "idCardName"
	},
	{
		title: "身份证照",
		field: "idCardPicFront"
	},
	{
		title: "身份证照",
		field: "idCardPicBack"
	},
	{
		title: "身份证照",
		field: "idCardPicHand"
	},
	{
		title: "新手机号",
		field: "mobile"
	},
	{
		title: "激活状态",
		field: "activateStatus",
		format: {
			type: "enum",
			pattern: "activateStatus"
		}
	},
	{
		title: "激活时间",
		field: "activateTime",
		format: {
			type: "date"
		}
	},
	{
		title: "首充状态",
		field: "rechargeStatus",
		format: {
			type: "enum",
			pattern: "rechargeStatus"
		}
	},
	{
		title: "首充时间",
		field: "rechargeTime",
		format: {
			type: "date"
		}
	},
	{
		title: "首充面值",
		field: "rechargeFace",
		format: {
			type: "money"
		}
	},
	{
		title: "物流名称",
		field: "expressName"
	},
	{
		title: "物流单号",
		field: "expressNo"
	},
	{
		title: "网络范围",
		field: "netRange"
	},
	{
		title: "创建时间",
		field: "createTime",
		format: {
			type: "date"
		}
	},
	{
		title: "更新时间",
		field: "updateTime",
		format: {
			type: "date"
		}
	}
]
      },
      query:{
	idCardName: null,
	activateStatus: null,
	rechargeStatus: null,
	expressName: null,
	expressNo: null
}
    }
  }
}
</script>