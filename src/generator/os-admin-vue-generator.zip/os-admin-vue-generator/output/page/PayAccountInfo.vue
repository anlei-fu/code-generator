<template>
  <div>
    <Filters>
      <span v-for="(value,key,i) in selects" :key="i">
        <Select :title="value.title" :enum="value.enum" v-model="query[key]" :width="value.width"/>
      </span>
      <span>
        <RadioGroup v-model="radioKey" :options="radioOptions"/>
        <Input v-model.trim="radioValue" />
      </span>
      <QueryButton @click="queryData(true)"/>
      <CreateButton @click="showAdd"/>
    </Filters>
    <Table :data="model.list">
      <el-table-column v-for="item in model.columns" header-align="center" align="center" :key="item.field" :min-width="item.minWidth" :prop="item.field" :label="item.title" :sortable="item.isSort">
        <template slot-scope="scope">
          <PlainText :value="scope.row[item.field]" :filterType="item.filter" :format="item.format" :color="$ColorPicker(item, scope.row[item.field])" />
        </template>
      </el-table-column>
      <el-table-column header-align="center" align="center" label="操作">
        <template slot-scope="scope">
          <el-button type="text" size="small" @click="showEdit(scope.row)">编辑</el-button>
          <el-button type="text" size="small" @click="showDelete(scope.row)">删除</el-button>
        </template>
      </el-table-column>
    </Table>
    <Pager :total="model.total" :current="query.pageNum" @pi-change="onPageIndexChanged" @ps-change="onPageSizeChanged" />
    <Edit ref="edit" @updated="afterUpdated"/>
  </div>
</template>
<script>
/**
 * 支付账号表
 * 
 * generated at 2021-1-13 9:37:37 AM
 */
import listPageMixin from "./../../list-page-mixin";
import Edit from './modal/PayAccountInfoEdit'
export default {
  components: {
    Edit
  },
  mixins:[listPageMixin],
  data() {
    return {
      radioValue: "",
      radioKey: "accountName",
      radioOptions: [
	{
		value: "accountName",
		name: "账号名称"
	},
	{
		value: "merchantId",
		name: "商户编号"
	},
	{
		value: "appId",
		name: ""
	}
],
      apiPrefix:"pay/account",
      pkName:"accountId",
      title:"支付账号表",
      selects:{
	status: {
		title: "状态",
		enum: "status"
	}
},
      model: {
      columns:[
	{
		title: "账号编号",
		field: "accountId"
	},
	{
		title: "账号名称",
		field: "accountName"
	},
	{
		title: "账号类型",
		field: "accountType"
	},
	{
		title: "商户编号",
		field: "merchantId"
	},
	{
		title: "签名KEY",
		field: "signKey"
	},
	{
		title: "证书路径",
		field: "certPath"
	},
	{
		title: "证书密钥",
		field: "certPwd"
	},
	{
		title: "加密公钥",
		field: "publicKey"
	},
	{
		title: "解密/验签私钥",
		field: "privateKey"
	},
	{
		title: "账户余额",
		field: "balance",
		format: {
			type: "money"
		}
	},
	{
		title: "API授权跳转地址",
		field: "authRedirectUrl"
	},
	{
		title: "支付完成跳转地址",
		field: "payRedirectUrl"
	},
	{
		title: "支付结果回调地址",
		field: "payCallbackUrl"
	},
	{
		title: "退款回调地址",
		field: "refundCallbackUrl"
	},
	{
		title: "状态",
		field: "status",
		format: {
			type: "enum",
			pattern: "status"
		}
	},
	{
		title: "备注",
		field: "remark"
	},
	{
		title: "创建人",
		field: "crateUser"
	},
	{
		title: "创建时间",
		field: "createTime",
		format: {
			type: "date"
		}
	},
	{
		title: "修改人",
		field: "updateUser"
	},
	{
		title: "修改时间",
		field: "updateTime",
		format: {
			type: "date"
		}
	},
	{
		title: "",
		field: "appId"
	},
	{
		title: "",
		field: "appSecret"
	}
]
      },
      query:{
	accountName: null,
	merchantId: null,
	status: null,
	appId: null
}
    }
  }
}
</script>