exports.ArgTypeError = class ArgTypeError extends Error {
        constructor (msg) {
                super(msg);
        }
}