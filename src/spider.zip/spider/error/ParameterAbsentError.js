exports.ParameterAbsentError = class ParameterAbsentError extends Error {
        constructor (msg) {
                super(msg);
        }
}