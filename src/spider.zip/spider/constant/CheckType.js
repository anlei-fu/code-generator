exports.CheckType = {

	// Html includes any
	INCLUDES_ANY: 1,

	// Html includes all
	INCLUDES_ALL: 2,

	// Html not includes any
	NOT_INCLUDES_ANY: 3,

	// Html not includes all
	NOT_INCLUDES_ALL: 4,

	// Match http status code
	STATUS_CHECK: 5
};

