exports.HttpStatusCode={
        CONNECT_REFUSE:44
}