exports.CrawlType={
        STATIC:1,
        BROWSER:2,
        API:3
}