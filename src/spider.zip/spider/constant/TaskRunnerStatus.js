exports.TaskRunnerStatus = {
	
	UNSTARTED:0,

	/**
	 * Task is ok
	 */
	OK: 1,

	/**
	 * Task has been blocked
	 */
	BLOCKED: 2
};

