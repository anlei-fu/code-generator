exports.TaskStatus = {
	WAIT: 1,
	EXCUTING: 2,
	SUCCESS: 3,
	BLOCKED: 4
};

