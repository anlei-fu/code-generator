exports.CrawlTaskResultCode = {
	SUCCESS: 1,
	BLOCKED: 2,
	FAILED:3,
};

