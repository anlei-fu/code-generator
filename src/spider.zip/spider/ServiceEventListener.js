
exports.ServiceEventListener = class {
        onServiceStarted(serviceName) {
        }

        onServicePaused(serviceName) {
        }

        onServiceStopped(serviceName) {
        }

        onServiceResumed(serviceName) {
        }
}