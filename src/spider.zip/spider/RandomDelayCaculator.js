class RandomDelayCaculator{
        constructor(minuteLimit){

        }
}